<!DOCTYPE html>
<html>
<?php $title = "Cutting";
  $nav_page = 590;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
 <?php include 'admin_assets/include/navbar.php'; ?>

  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Cutting</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Cutting</li>
            </ol>
          </div>
        </div>  
      </div><!-- /.container-fluid -->
    </section>

    <div class="card">
      <div class="card-header">
        <button type="button" class="btn btn-info float-right" data-toggle="modal" data-target="#modal-lg">Add Roll</button>
      </div>
      <div class="card-body">
        <div class="table-responsive">
           <table id="example1" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>#</th>
                <th>Roll Name</th>
                <th>Roll Weight (in Kgs)</th>
                <th>Roll Length (in meter)</th>
                <th>Cutting</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($cutroll as $ke => $ro): ?>
              <tr>
                <td><?= ++$ke ?></td>
                <td><?= $ro->cutting_roll_name ?></td>
                <td><?= $ro->cutting_roll_weight ?></td>
                <td><?= $ro->cutting_roll_length ?></td>
                <td class="text-center"><a href="<?= base_url('admin/cutting-roll/'.$ro->cutting_id)?>"><i class="fa fa-plus text-success"></i></a></td>
                <td><?= date('d-m-Y',strtotime($ro->cutting_created)) ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
           </table>
        </div>
      </div>
    </div>

    <!-- Add Roll for Cutting  -->
<div class="modal fade" id="modal-lg">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add Roll</h4>
        <div id="msg"></div>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- form start -->
        <form action="" id="add_roll_cutting" method="post">
          <div class="card-body">
            <div class="form-group">
              <label class="form-label">Select Roll</label>
              <select class="form-control" name="rollid" id="rollid">
                <option value="">---Select Roll---</option>
                <?php foreach($roll as $key => $val): ?>
                  <option value="<?= $val->coating_id ?>"><?= $val->coating_roll_name ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group row">
              <div class="col-md-6">
                <label>Roll Weight</label>
                <input type="number" class="form-control" name="rweight" id="rweight" step="any">
              </div>
              <div class="col-md-6">
                <label>Roll Length</label>
                <input type="number" class="form-control" name="rlength" id="rlength" step="any">
                <input type="hidden" name="rname" id="rname">
              </div>
              
            </div>
          </div>
      <!-- /.card-body -->
      <div class="card-footer">
        <button type="submit" class="btn btn-primary float-right">Submit</button>
      </div>
    </form>
  </div>

</div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>


    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
  <script type="text/javascript">
    
    $( "#rollid" ).change(function(){

      let rollid = $(this).val();

      $.ajax({

       type       : 'POST',
       url        : '<?php echo base_url() ?>admin/get-coating-roll-detail',
       dataType   : 'json',
       data       : {'rid' : rollid},
       success    : function(result) {
         
         
         var rlength = result.coating_roll_length
         var rweight = result.coating_roll_weight_after_coating
         var rname = result.coating_roll_name

         $('#rlength').val(rlength);
         $('#rweight').val(rweight);
         $('#rname').val(rname);

       },error: function(jqXHR, exception) {

         console.log(jqXHR.responseText);
       }

     });
  })
  

  $('#add_roll_cutting').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/add-cutting-roll", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })  

  

  </script>
</body>
</html>
