<!DOCTYPE html>
<html>
<?php $title = "Beam";
$nav_page = 9992;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }

  .sw_hd{
    display: none;
  }

}
</style>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Beam</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Beam</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h5>Add beam</h5>
              </div>
              <form action="<?php echo base_url();?>Admin/Add_New_Beam" method="POST">
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-12 text-center" id="max-weight">
                      
                    </div>
                    <div class="col-md-6">
                      
                      <div class="form-group">
                        <label for="">Select Machine</label>
                        <select name="select_machines" id="select_machines" class="form-control" required="${parseFloat(result.Present_weight)}">
                          <option value="" style="display: none;">Select machines</option>
                          <?php foreach ($machines_where_inward_added as $key => $value): ?>

                          <option value="<?php echo $value->mac_id; ?>"><?php echo $value->mac_name; ?></option>

                          <?php endforeach ?>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Select Date</label>
                        <input type="text" class="form-control selectDate" name="selectDate">
                      </div>
                    </div>
                    <div class="col-md-6 sw_hd">
                      <div class="form-group">
                        <label for="">Beam Name</label>
                        <input type="text" name="Beam Name" class="form-control" required="${parseFloat(result.Present_weight)}">
                      </div>
                    </div>
                    <div class="col-md-6 sw_hd">
                      <div class="form-group">
                        <label for="">Weight (Kg)</label>
                        <input type="number" name="beam_weight" id="beam_weight" class="form-control" required="${parseFloat(result.Present_weight)}">
                      </div>
                    </div>
                    <div class="col-md-6 sw_hd">
                      <div class="form-group">
                        <label for="">Length (m)</label>
                        <input type="number" name="length" class="form-control" required="${parseFloat(result.Present_weight)}">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="card-footer">
                  <button class="btn btn-success btn-sm" type="submit">Submit</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php'; ?>



</body>
</html>

<script>
  $(function(){
    $('#select_machines').unbind().change(function(event) {
      event.preventDefault()
      let value = $(this).val()
      $.ajax({
        url: '<?php echo base_url();?>Admin/get_weight_of_machine_where_inward_is_assigned',
        type: 'POST',
        dataType: 'json',
        data: {param1: value},
      })
      .done(function(result) {
        console.log(result);
        $('#beam_weight').removeAttr('max');
        $('#beam_weight').attr('max', parseFloat(result.Present_weight)+1)
        $('.sw_hd').show('slow/400/fast');
        $('#max-weight').html(`<div class="bedge bedge-success">
                        <h4>Inward weight present in machines: <span class="text-success">${parseFloat(result.Present_weight)} (KG)</span></h4>
                      </div>`)
      })
      .fail(function(jqXHR,exception) {
        console.log(jqXHR.responseText);
      })
    });

    $('.selectDate').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxYear: parseInt(moment().format('YYYY'),10)
    });
  })
</script>
