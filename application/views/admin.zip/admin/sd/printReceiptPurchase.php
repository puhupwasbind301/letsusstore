<!DOCTYPE html>
<html>
<?php $title = "Purchase Order Receipt";
$nav_page = 8;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg, .modal-lg{
    max-width: 900px;
  }

}

@media (min-width: 640px) {
  .modaledit-lg, .modalview-lg, .modal-lg{
    max-width: 900px;
  }

}
</style>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Purchase Order Receipt</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url()?>">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Inventory</a></li>
              <li class="breadcrumb-item"><a href="<?= base_url()?>admin/purchase-receive">Purchase Received</a></li>
              <li class="breadcrumb-item active">Purchase Order Receipt</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row d-print">
          <div class="col-md-12">

            <div class="card">
              <div class="card-header">
                  <h3 class="text-center"><b>Purchase Receipt</b></h3>
              </div>

              <div class="card-body">
                <div class="row">
                  <div class="col-md-8">
                    <div class="row p-2">
                    <label>Vendor:</label>&emsp;<?= $data->vendor_name?>
                  </div>
                  <div class="row p-2">
                    <label>Invoice Number:</label>&emsp;<?= "INV".$data->pr_invoice_no?>
                  </div>
                  <div class="row p-2">
                    <label>Pay Amount:</label>&emsp;<?= $data->pr_paid_amount?>
                  </div>
                  </div>
                  <div class="col-md-4">
                    <div class="row p-2">
                    <label>Receipt:</label>&emsp;<?= "RPE-".$data->pr_id?>
                  </div>
                  <div class="row p-2">
                    <label>Date:</label>&emsp;<?= date('d M, Y  h:i a',strtotime($data->pr_timestamp))?>
                  </div>
                  <div class="row p-2">
                    <label>Total:</label>&emsp;<?= $data->pr_invtotalamount?>
                  </div>
                  </div>
                </div>
                <div class="row p-2">
                  <?php $item = $this->name->fetchItemById($data->pr_purchaseorder_id); ?>
                  <div class="table-responsive">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Item Name</th>
                          <th>Rate</th>
                          <th>MRP</th>
                          <th>Quantity</th>
                          <th>Discount</th>
                          <th>Free</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach($item as $key => $v): ?>
                        <tr>
                          <td><?= ++$key?></td>
                          <td><?= $v->item_inventory?></td>
                          <td><?= $v->item_rate?></td>
                          <td><?= $v->item_mrp?></td>
                          <td><?= $v->item_quantity?></td>
                          <td><?= $v->item_discount?></td>
                          <td><?= $v->item_free?></td>

                        </tr>
                      <?php endforeach; ?>
                      </tbody>

                    </table>
                    <div>
                      <a href="#" id="lnkPrint" class="float-right d-print-none"><button class="btn btn-primary">Print</button></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
    

    

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
  <script type="text/javascript">
    $( document ).ready(function() {
    $('#lnkPrint').click(function()
     {
         window.print();
     });
});
  </script>
</body>
</html>
