<!DOCTYPE html>
<html>
<?php $title = "Coating Add Machine";
  $nav_page = 10014;
  include 'admin_assets/include/header.php';
 ?>

<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php include 'admin_assets/include/navbar.php'; ?>
  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Coating Add  Machine</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Coating Add Machine</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item">Inward</li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">

                  <form class="px-xl-5" action="<?php echo base_url(); ?>admin/coating-add-machine"  method="POST">
                    <div class="row px-xl-5">
                      <div class="col-12">
                        <div class="row">
                          <div class="col-md-12">
                            <div class="row">
                              <div class="col-md-12">
                                <div class="form-group">
                                  <label for="">Name</label>
                                <input type="text" name="couting_machine_name" id="machi" class="form-control" placeholder="Enter machine name">
                                  <!-- <em><?php echo form_error('raw_material_type'); ?></em> -->
                                </div>
                              </div>
                              <div class="col-md-12">
                                <div class="form-group">
                                  <label for="">Description</label>
                                   <textarea class="form-control" name="couting_machine_description" rows="3" placeholder="Coating Machine Description.."></textarea>
                                </div>
                              </div>
                              <div class="row" id="append-here">
                                
                              </div>
                            </div>
                          </div>
                          
                          <div class="col-md-12">
                            <button class="btn btn-outline-success" name="submit" type="submit">Submit</button>
                          </div>
                          <div class="col-md-12">
                             <?php echo $this->session->flashdata('val_error'); ?>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
</body>
</html>


