<!DOCTYPE html>
<html>
<?php $title = "Inventory Issue";
  $nav_page = 9;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
 <?php include 'admin_assets/include/navbar.php'; ?>

  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Inventory Issue</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url()?>admin">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Inventory</a></li>
              <li class="breadcrumb-item active">Inventory Issue</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <?php $rec = $this->name->getMaxReceipt(); 
            if($rec === ""){
              $rec = 0;
            }
            else{

              $rec += 1;
            };?>
            <form id="ajaxform1" method="post">
            <div class="card">
              <div class="card-header">
                  
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="stfid">Issue to</label>
                          <select class="form-control" name="stfid" id="stfid">
                            <option value="">---Select Staff Member---</option>
                            <?php foreach($staff as $key => $v): ?>
                              <option value="<?= $v->staff_id?>"><?= $v->staff_name?></option>
                            <?php endforeach; ?>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="invcat">Inventory Category</label>
                          <select class="form-control" name="invcat" id="invcat">
                            <option value="">---Select Inventory Category---</option>
                            <?php foreach($cat as $key1 => $vl): ?>
                              <option value="<?= $vl->inventory_cat_id?>"><?= $vl->inventory_category?></option>
                            <?php endforeach; ?>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label for="item">Item</label>
                          <select id="item" class="form-control" name="item">

                            </select>
                        </div>
                      </div>
                   
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <button class="btn btn-primary float-right" type="button" id="addItem">Add</button>
                      </div>
                    </div>
              </div>
              <div class="card-body">
                 <div class="row p-2">
                      <div class="col-md-12 table-responsive">
                        <table class="table table-bordered">
                          <thead>
                            <tr>
                              <th>Item</th>
                              <th>Available Quantity</th>
                              <!-- <th>MRP</th> -->
                              <th>Quantity</th>
                              <!-- <th>Discount</th> -->
                              <th>Manage</th>
                            </tr>
                          </thead>
                          <tbody id="itemde">
                            
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div class="row p-2">
                      <div class="col-md-8">
                        <label for="remarks">Remarks</label>
                        <input type="text" name="remarks" id="remarks" class="form-control">
                      </div>
                      <!-- <div class="col-md-4">
                        <label>Total</label>
                        <input type="text" name="totalamt" step="any" class="form-control" readonly="" id="total" >
                      </div>
                      <div class="col-md-4">
                        <label>Receipt No.</label>
                        <input type="text" name="receiptno" value="<?= $rec?>" readonly="" class="form-control">
                      </div> -->
                    </div>
                  <div class="row p-2">
                    <div class="col-md-12">
                      <button class="btn btn-primary float-right" type="submit">Save</button>
                    </div>
                  </div>
        </div>
   
      </div>
         </form>
    </div>
    
</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>

  <script type="text/javascript">
    $( function() {
      $( "#invcat" ).change(function(){


        var id = $(this).val();

        $.ajax({

         type       : 'POST',
         url        : '<?php echo base_url() ?>Machineajax/getItem',
         dataType   : 'json',
         data       : {'id': id},
         success    : function(result) {
          
          var select = '';
          select += '<option value="">---Select Item---</option>';
          $.each(result, function(result, val) {

           select += '<option value="'+val['item_id']+'">'+val['item_inventory']+'</option>';
         });

          $('#item').html(select);

          


        },error: function(jqXHR, exception) {
          console.log('bye');
          console.log(jqXHR.responseText);
        }

      });

      })


    });
    
  </script>

  <script>
    function checkAvailble(str , str1 , evnt){

        if(parseInt(str) > parseInt(str1)){

            alert('Quantity not availabel !');
             $(evnt).val("0");
        }
    }

    function checkDiscount(str , str1 , evnt){

        if(parseInt(str) > parseInt(str1)){

            alert('Discount Not Available !');
            $(evnt).val("0");
        }

    }

    function amountTotal(amount) {
        var total = 0;
        for (i = 0; i < amount.length; ++i) {
            total += amount[i]; // add each element in an array to total
        }
        return total;// return sum of elements in array
    }
  $(document).ready(function(){
    $('#addItem').click(function(){
       
        var staff = $('#stfid').val();
        var inventorycat = $('#invcat').val();
        var item = $('#item').val();

        if(staff === ""){

          alert("Staff is not selected!");
          return false;
        }
        else if(inventorycat === ""){

          alert("Inventory Category not Selected!");
          return false;
        }
        else if(item === ""){

          alert("Item is not selected!");
          return false;
        }
        else{

          $.ajax({

         type       : 'POST',
         url        : '<?php echo base_url() ?>Machineajax/getItemAvailable',
         dataType   : 'json',
         data       : {'inventorycat' : inventorycat, 'item': item},
         success    : function(data) {
                        $('#itemde').append('<tr><td><input type="hidden" name="itemid[]" value="' + data.item_id + '">' + data.item_inventory + '</td><td>' + data.item_quantity + '</td><td><input type="number" class="form-control quantity" name="quantityneed[]" id="quantityneed"  onkeyup="checkAvailble(value ,  '+ data.item_quantity + ' , this)" value="0"></td><td class="text-center"><input type="hidden" value="'+data.item_id+'" name="itemId[]"><a href="#" class="remove_field"><i class="fas fa-times-circle"></i></a></td></tr>');


                        

                        $('.remove_field').on('click', function (e) {
                            e.preventDefault();
                            $(this).parent('td').parent('tr').remove();
                        });
                        checkAvailble();
                        checkDiscount();

                    },error: function(jqXHR, exception) {
          console.log('bye');
          console.log(jqXHR.responseText);
        }

      });

        }
       
    });

  
  });
</script>

<script type="text/javascript">
  $(function() {
    $('#ajaxform1').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/insert-inventory-issue", data).then(function(result) {

      
        if(result.result){
          window.location.reload()
        }
        else{
          $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>

</body>
</html>
