<!DOCTYPE html>
<html>
<?php $title = "Add Sales";
  $nav_page = 10005;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php include 'admin_assets/include/navbar.php'; ?>
  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Add Sales</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Add Sales</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item">Add Sales</li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">

                  <form class="px-5" action="<?php echo base_url();?>Admin/Add_sales_fn" method="POST">
                    <div class="row px-5">
                      <div class="col-12">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="">Roll Type</label>
                              <select name="roll_type" id="roll_type" class="form-control" required="">
                                <option selected="" style="display: none;">Select Roll Type</option>
                                <option value="all">All Rolls</option>
                                <option value="coat_all">Coating completed rolls</option>
                                <option value="cut_all">Cutting completed rolls</option>
                              </select>
                            </div>
                          </div>
                          <div class="col-md-6 roll-hide" style="display: none;">
                            <div class="form-group">
                              <label for="">Roll</label>
                              <select name="roll" id="roll" class="form-control appendHere" required="">
                                <option selected="" style="display: none;">Select Roll</option>
                              </select>
                            </div>
                          </div>
                          <div class="col-md-12">
                            <label for="">Company Name</label>
                            <select name="com_name" id="com_name" class="form-control" required="">
                              <option selected="" style="display: none;">Select Company</option>
                              <?php foreach ($all_companys as $key => $value): ?>
                                <option value="<?php echo $value->customer_id; ?>"><?php echo $value->customer_name; ?></option>
                              <?php endforeach ?>
                            </select>
                          </div>
                          <div class="col-md-6">
                            <label for="Price">Price</label>
                            <input type="number" name="price" class="form-control" required="">
                          </div>
                          <div class="col-md-6">
                            <label for="Quantity">Quantity</label>
                            <input type="number" name="Quantity" class="form-control" required="">
                          </div>
                          <div class="col-md-12 text-center my-5">
                            <button class="btn btn-outline-success" type="submit">Submit</button>
                          </div>
                          <div class="col-md-12">
                            <?php echo $this->session->flashdata('val_error'); ?>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
</body>
</html>
<script>
  $(function(){
    $('#roll_type').change(function(event) {
      event.preventDefault()
      var value = $(this).val()
      $.ajax({
        url: '<?php echo base_url();?>Admin/Gett_rolls',
        type: 'POST',
        dataType: 'json',
        data: {param1: value},
      })
      .done((result)=>{
        // console.log(result.data);
        $('.roll-hide').show('slow/400/fast');
        $('.appendHere').html('')
        if (value === 'cut_all') {
          if (result.status === 'false') {
            $('.appendHere').html(`<option>No roll found</option>`)
          }else{
            $.map(result.data, function(elem, index) {
              // console.log(elem)
              if (elem.cutting_roll_weight === elem.cutting_weight_deduct || elem.cutting_roll_length === elem.cutting_length_deduct) {
              $('.appendHere').append(`<option value="${elem.roll_id}">${elem.roll_name}</option>`)
              }
            })
          }
        }else{
          if (result.status === 'false') {
            $('.appendHere').html(`<option>No roll found</option>`)
          }else{
            $.map(result.data, function(elem, index) {
              // console.log(elem)
              $('.appendHere').append(`<option value="${elem.roll_id}">${elem.roll_name}</option>`)
            })
          }
        }
      })
      .fail(function(jqXHR,exception) {
        console.log(jqXHR.responseText);
      })
    });
  })
</script>