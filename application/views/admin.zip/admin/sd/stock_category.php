<!DOCTYPE html>
<html>
<?php $title = "Inventory Category";
  $nav_page = 6;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
 <?php include 'admin_assets/include/navbar.php'; ?>

  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Inventory Category</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Inventory Category</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

     <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <div class="card">
              <div class="card-header">

                <button type="button" class="btn btn-info float-right" data-toggle="modal" data-target="#modal-lg">Add <i class="fa fa-plus"></i></button>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>Inventory Category</th>
                        <th>Inventory Description</th>
                        <th>Manage</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach($data as $key => $val): ?>
                      <tr>
                        <td><?= ++$key?></td>
                        <td><?= $val->inventory_category?></td>
                        <td><?= $val->inventory_cat_desc?></td>
                        <td class="text-center"><a href="#" data-toggle="modal" data-target="#modaledit-lg<?= $val->inventory_cat_id?>"><i class="fa fa-edit text-success"></i></a>&emsp;|&emsp;<a href="#" data-toggle="modal" data-target="#modal-sm<?= $val->inventory_cat_id?>"><i class="fa fa-trash text-danger" title="Delete"></i></a></td>
                      </tr>
                      
                      <!-- Edit Inventory Category -->
                      <div class="modal fade" id="modaledit-lg<?= $val->inventory_cat_id?>">
                          <div class="modal-dialog modaledit-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h4 class="modal-title">Edit Inventory Category</h4>
                                <div id="messageForm1"></div>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                               <!-- form start -->
                               <form action="" class="eidtinv" method="post">
                  <div class="card-body">
                    <div id="msgwork1"></div>
                    
                  <div class="row">
                    <div class="col-md-12">
                      <input type="hidden" name="invid" value="<?= $val->inventory_cat_id?>">
                      <div class="form-group">
                        <label for="scategorye">Inventory Category</label>
                        <input type="text" name="scategory" id="scategorye" value="<?= $val->inventory_category?>" class="form-control" required="">
                      </div>
                    </div>

                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label for="sdesce">Description</label>
                        <input type="text" value="<?= $val->inventory_cat_desc?>" name="sdesc" id="sdesce" class="form-control" required="">
                      </div>
                    </div>

                  </div>
          


              </div>
              

              <!-- /.card-body -->

              <div class="card-footer">
                <button type="submit" class="btn btn-primary float-right">Submit</button>
              </div>
            </form>
                              </div>

                      </div>
                      <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                  </div>

                <!-- Delete Inventory Catgeory -->
                  <div class="modal fade" id="modal-sm<?= $val->inventory_cat_id?>">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">Delete Inventory Category</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <form action="<?= base_url()?>admin/delete-inventory-category" method="post"> 
                          <div class="modal-body">
                            <input type="hidden" name="invent_id" value="<?= $val->inventory_cat_id?>">
                            <p>Are you sure, you want to delete this?</p>
                          </div>
                          <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Yes</button>
                          </div>
                        </form>
                      </div>
                      <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                  </div>
                  <!-- /.modal -->

                    <?php endforeach; ?>
                    </tbody>
                    

            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Add Staff -->
    <div class="modal fade" id="modal-lg">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Add Inventory Category</h4>

            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <!-- form start -->
            <form  id="ajaxform1" method="post">
              <div class="card-body">
                <div id="messageForm"></div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="scategory">Inventory Category</label>
                      <input type="text" class="form-control" id="scategory" name="scategory" placeholder="Inventory Category" required="" >

                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="sdesc">Description</label>
                      <textarea class="form-control" name="sdesc" placeholder="Description" id="sdesc"></textarea>
                    </div>
                  </div>
                </div>
        <!-- /.card-body -->

        <div class="card-footer">
          <button type="submit" class="btn btn-primary float-right">Submit</button>
        </div>
      </form>
    </div>

  </div>
  <!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>

  <script type="text/javascript">
  $(function() {
    $('#ajaxform1').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/insert-inventory-category", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>

<script type="text/javascript">
  $(function() {
    $('.eidtinv').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/update-inventory-category", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          window.location.reload()
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>
</body>
</html>
