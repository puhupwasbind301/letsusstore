<!DOCTYPE html>
<html>
<?php $title = "Purchase Receive";
$nav_page = 8;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg, .modal-lg{
    max-width: 900px;
  }

}

@media (min-width: 640px) {
  .modaledit-lg, .modalview-lg, .modal-lg{
    max-width: 900px;
  }

}
</style>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Purchase Received</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url()?>">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Inventory</a></li>
              <li class="breadcrumb-item active">Purchase Received</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <div class="card">
              <div class="card-header">
                <button type="button" class="btn btn-info float-right" data-toggle="modal" data-target="#modal-lg"><i class="fa fa-plus"></i></button>
              </div>

              <div class="card-body">
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>Vendor Name</th>
                        <th>Invoice No.</th>
                        <th>Paid Amount</th>
                        <th>Manage</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach($data as $key => $v): ?>
                      <tr>
                        <td><?= ++$key?></td>
                        <td><?= $v->vendor_name?></td>
                        <td><?= "INV".$v->pr_invoice_no?></td>
                        <td><?= $v->pr_paid_amount?></td>
                        <td class="text-center"><a href="<?= base_url()?>admin/print-purchase-order-receipt/<?= $v->pr_id?>"><i class="fas fa-print text-info" title="Print"></i></a></td>
                      </tr>
                    <?php endforeach; ?>
                    </tbody>
                    
                  </table>

                </div>
              </div>
            </div>
          </div>
          <!-- Purchase Received -->
          <div class="modal fade" id="modal-lg">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">Purchase Received</h4>

                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <?php $inv = $this->name->getMaxInvoiceNo(); 

                  if($inv == ''){

                      $inv = 10000;
                  }
                  else{

                     $inv += 1;
                  }?>
                  <!-- form start -->
                  <form  id="ajaxform1" method="post">
                    <div class="card-body">
                      <div id="messageForm"></div>
                      <input type="hidden" name="vendorid" value="<?= $this->uri->segment(3);?>">
                      <div class="row">
                        <div class="col-md-4">
                          <div class="form-group">
                            <label for="invoice">Invoice Number</label>
                            <input type="text" class="form-control" id="invoice" name="invoice" placeholder="Invoice Number" value="<?= $inv?>" readonly="">

                          </div>

                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label for="model">Vendors</label>
                            <select class="form-control" name="vendorid" id="vid">
                              <option value="">---Select Vendor---</option>
                              <?php foreach($vend as $ke => $vl): ?>
                                <option value="<?= $vl->vendor_id?>"><?= $vl->vendor_name?></option>
                              <?php endforeach; ?>
                            </select>

                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label for="prorder">Purchase Order</label>
                            <select id="prorder" class="form-control" name="purordid">

                            </select>

                          </div>
                        </div>

                      </div><br>
                      <div class="row">
                        <div class="offset-md-2 col-md-8 table-responsive" >
                          <table class="table table-bordered">
                            <tr>
                              <th>Item</th>
                              <th>Quantity</th>
                              <th>MRP</th>
                              <th>Rate</th>
                              <th>Discount</th>
                              <th>Free</th>
                            </tr>
                            <tbody id="itembody">
                           
                            </tbody>
                          </table>
                        </div>
                      </div><br>
                      <div class="row">
                        <div class="col-md-4">
                          <div class="form-group">
                            <label for="invoice">Payment Mode</label>
                            <select class="form-control" name="payment" required="">
                              <option value="">---Select Payment Mode---</option>
                              <option value="Online">Online</option>
                              <option value="Cash">Cash</option>
                            </select>
                          </div>
                        </div>

                        <div class="col-md-4">
                          <div class="form-group">
                            <label>Invoice Total Amount</label>
                            <input type="text" name="intamt" class="form-control" readonly="" step="any" value="" id="tamount">
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group">
                            <label>Paid Amount</label>
                            <input type="number" name="pamount"  class="form-control" step="any">
                          </div>
                        </div>

                      </div>

                    </div>

                    <!-- /.card-body -->

                    <div class="card-footer">
                      <div id="messageForm"></div>
                      <button type="submit" class="btn btn-primary float-right">Submit</button>
                    </div>
                  </form>
                </div>

              </div>
              <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>

  <script type="text/javascript">
  $(function() {
    $('#ajaxform1').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/insert-purchase-received", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>
  <script type="text/javascript">
    $( function() {
      $( "#vid" ).change(function(){


        var vid = $(this).val();

        $.ajax({

         type       : 'POST',
         url        : '<?php echo base_url() ?>Machineajax/getPurchaseOrder',
         dataType   : 'json',
         data       : {'vid': vid},
         success    : function(result) {

          var select = '';
          select += '<option value="">Select Purchase Order</option>';
          $.each(result, function(result, val) {

           select += '<option value="'+val['vpo_id']+'">'+val['vpo_category']+'</option>';
         });

          $('#prorder').html(select);

          // console.log(select);


        },error: function(jqXHR, exception) {
          console.log('bye');
          console.log(jqXHR.responseText);
        }

      });

      })


    });
    
  </script>

  <script type="text/javascript">
    $( function() {
      $( "#prorder" ).change(function(){


        var pro = $(this).val();
        

        $.ajax({

         type       : 'POST',
         url        : '<?php echo base_url() ?>Machineajax/getItemByPurchaseOid',
         dataType   : 'json',
         data       : {'pro': pro},
         beforeSend : function() {

          $('#itembody').html('');
         },
         success    : function(result) {
 
          $.each(result, function(key,val) {   
         
                  $('#itembody').append('<tr>'+
                   '<td>'+ val.item_inventory +'</td>'+
                   '<td>'+ val.item_quantity +' </td>'+
                   '<td>'+ val.item_mrp +' </td>'+
                   '<td>'+ val.item_rate +' </td>'+
                   '<td>'+ val.item_discount +' </td>'+
                   '<td>'+ val.item_free +' </td>'+
                   '</tr>'); 
         
                });

          

          // console.log(select);


        },error: function(jqXHR, exception) {
          console.log('bye');
          console.log(jqXHR.responseText);
        }

      });

      })


    });
    
  </script>

  <script type="text/javascript">
    $( function() {
      $( "#prorder" ).change(function(){


        var pro = $(this).val();

        $.ajax({

         type       : 'POST',
         url        : '<?php echo base_url() ?>Machineajax/getTotalAmount',
         dataType   : 'json',
         data       : {'pro': pro},
         success    : function(result) {
 
                  $('#tamount').val(result); 

          

          // console.log(select);


        },error: function(jqXHR, exception) {
          console.log('bye');
          console.log(jqXHR.responseText);
        }

      });

      })


    });
    
  </script>
</body>
</html>
