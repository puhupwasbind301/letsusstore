<!DOCTYPE html>
<html>
<?php $title = "Coating Report";
  $nav_page = 10016;
  include 'admin_assets/include/header.php';
 ?>
 <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
 <style type="text/css">
   .select2-container--default .select2-selection--single .select2-selection__rendered {
       color: #444;
       line-height: 24px;
   }
   .select2-container .select2-selection--single {
       height: 38px;
   }
   .select2-container--default .select2-selection--single .select2-selection__arrow {
       height: 35px;
   }
  @media (min-width: 992px) {
   .modaledit-lg, .modalview-lg{
     max-width: 800px;
   }

 }
 </style>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php include 'admin_assets/include/navbar.php'; ?>
  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Coating Report</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Coating Report</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->

      <!--  new -->

<div class="content">
 <div class="container-fluid">
  
  <form action="" novalidate="novalidate" id="coating_report" method="POST">
    <div class="row">

                      <div class="col-md-3">
                        <div class="form-group">
                           <label for="">Select Start Date</label>
                           <input type="text" class="form-control date" name="start_date">
                        </div>
                      </div>

                      <div class="col-md-3">
                        <div class="form-group">
                           <label for="">Select End Date</label>
                           <input type="text" class="form-control date" name="end_date">
                        </div>
                      </div>
                  
                      <div class="col-md-3">
                        <div class="form-group">
                              <label for="">Worker</label>
                            <select name="staff" id="staff" class="form-control " >
                              <option value="" style="display: none;"></option>
                              <?php foreach ($staff_availability_list as $key => $value) { ?>
                                  <option value="<?= $value->staff_id ?>"><?= $value->staff_name ?></option>
                              <?php } ?>
                            </select> 
                        </div>
                      </div>

  <!--       <div class="col-md-4">
          <div class="form-group">
              <label for="shift">Select Shift</label> <br>
            <div class="custom-control custom-checkbox custom-control-inline">
               <input type="checkbox" id="customRadioInline1" name="customRadioInline" class="custom-control-input">
               <label class="custom-control-label" for="customRadioInline1">Day</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline">
              <input type="checkbox" id="customRadioInline2" name="customRadioInline" class="custom-control-input">
              <label class="custom-control-label" for="customRadioInline2">Night</label>
            </div>
          </div>
        </div> -->
                <div class="col-md-3">
                  <div class="form-group ">
                    <label for="">  </label>
                    <button class="btn btn-success form-control " type="submit" >Submit</button>
                  </div>
                </div>
                        
        
    </div>
  </form>
  </div>
  </div>

    <!-- & new -->

    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">  

              <!-- /.card-header -->
              
<div class="card-body d-none" id="coating_report_body">
    
     
        <div class="row pb-3">    
            <div class="col-xl-9 col-md-7 col-lg-7">
              <span class="mr-2">Show</span>
                   <select class="custom-select" style="width: 70px;height: 40px;">
                      <option selected>10</option>
                      <option value="1">20</option>
                      <option value="2">30</option>
                      <option value="3">40</option>
                  </select>
              <span class="ml-1">entries</span>
            </div>
                   <div class="ml-md-4 ml-xl-2 pl-md-3 pl-xl-0 pl-2 mt-3 mt-xl-0 mt-md-0">
                 <form class="form-inline">
                   <span class="text-right mr-md-2 mr-2 mr-xl-1">Search</span>
                  <input type="text" class="form-control w-75">
                 </form>
                   </div>      
              <!--  <span style="display: flex; align-items: center;" class="pl-2"> Show</span>
          <div class="col-4 col-md-2 col-xl-1">
              <select class="custom-select">
                <option selected>10</option>
                <option value="1">20</option>
                <option value="2">30</option>
                <option value="3">40</option>
              </select>
          </div>
              <span style="display: flex; align-items: center;" class=""> entires</span> -->
      </div>
                  

   <div class="table-responsive pr-xl-2">
     <table class="table table-bordered">
  <thead>
    <tr class="bg-light text-center">
      <th>Sno.</th>
      <th>Staff Name</th>
      <th>Date</th>
      <th colspan="2"><span class="text-center">Roll Used</span></th>
      <th colspan="2">Output</th>
      <th colspan="3">Raw Material Consumed</th>
    </tr>
    <tr>
      <th></th>
      <th></th>
      <th></th>
      <th class="font-weight-bold">Roll Type</th>
      <th class="font-weight-bold">Roll Name</th>
      <th class="font-weight-bold">Finished</th>
      <th class="font-weight-bold">Unfinished</th>
      <th class="font-weight-bold">Raw Material Type</th>
      <th class="font-weight-bold">Raw Material Type of Type</th>
      <th class="font-weight-bold">Weight</th>
    </tr>
  </thead>
  <tbody id="coating_report_data">
    


  </tbody>
</table>
   </div>



 </div>











              <!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
</body>
</html>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>


<script>
  $(function(){

      $('.addcutfinishedrow').click(function(event) {
      event.preventDefault();
      getCut()
    });

    $('.addcutunfinishedrow').click(function(event) {
      event.preventDefault();
      getcutUnFinishedCode()
    });

    $('#cutfinishedCheckbox').on('change', function() {
        if($(this).prop('checked') === true){
            getCut()
         }else{
            $('.fow').remove()
            $('.addcutfinishedrow').hide();
         }
    });

    $('#uncutfinishedCheckbox').on('change', function() {
        if($(this).prop('checked') === true){
            getcutUnFinishedCode()()
         }else{
            $('.furow').remove()
            $('.addcutunfinishedrow').hide();
         }
    });

});

function getCut() {
  $('#getcutfinishedrows').append(`<div class="row fow" style="border: 2px solid #E0E0E0;padding: 20px 10px 30px 10px;margin:2% 0%">
                        <div class="col-md-6">
                          <label for="">Roll type</label>
                          <select name="roll_type[]" class="form-control" required="">
                            <option value="" style="display: none;"></option>
                            <?php foreach ($all_rolls as $key => $value): ?>
                              <option value="<?php echo $value->roll_types_id; ?>"><?php echo $value->roll_types_name; ?></option>
                            <?php endforeach ?>
                          </select>
                        </div>

                        <div class="col-md-6 mt-3 mt-md-0">
                          <label for="">Roll Length ( <sub>sq</sub><sup>2</sup><sub>m</sub> )</label>
                          <input type="number" name="no_of_rolls[]" class="form-control" required="" placeholder="Enter length">
                        </div>

                        <div class="col-md-6 mt-3">
                          <label for="">Roll weight (kg)</label> 
                          <input type="number" name="roll_weight[]" class="form-control" required="" step="any" placeholder="Enter roll weight">
                        </div>

                         <div class="col-md-6 mt-3">
                          <label for="">Roll Name</label> 
                          <input type="input" name="roll_weight[]" class="form-control" required="" step="any" placeholder="Enter roll name">
                        </div>

                      </div>`)
  $('.addcutfinishedrow').show();
}


function getcutUnFinishedCode() {
  $('#getcutunfinishedrows').append(`<div class="row furow" style="border: 2px solid #E0E0E0;padding: 20px 10px 20px 10px;margin:2% 0%">
                        <div class="col-md-4">
                          <label for="">Roll type</label>
                          <select name="roll_type" class="form-control" required="">
                            <option value="" style="display: none;"></option>
                            <?php foreach ($all_rolls as $key => $value): ?>
                              <option value="<?php echo $value->roll_types_id; ?>"><?php echo $value->roll_types_name; ?></option>
                            <?php endforeach ?>
                          </select>
                        </div>

                        <div class="col-md-4 my-3 my-md-0">
                          <label for="">Roll weight</label> 
                          <input type="number" name="roll_weight[]" class="form-control" required="" step="any" placeholder="Enter roll weight">
                        </div>

                         <div class="col-md-4">
                          <label for="">Roll Name</label> 
                          <input type="input" name="roll_weight[]" class="form-control" required="" step="any" placeholder="Enter roll name">
                        </div>

                      </div>`)
  $('.addcutunfinishedrow').show();
};







  $(document).ready(function () { 

    $("input[name=outputType]").change(function(){
        var radioValue = $("input[name=outputType]:checked").val();
        if(radioValue === "Finished"){
            $('#roll-type-output').show()
            $('#Finished-area').show();
            $('#Unfinished-area').hide();
        }else if(radioValue === "Unfinished"){
            $('#roll-type-output').show()
            $('#Finished-area').hide();
            $('#Unfinished-area').show();
        }
    });

    select2p()

    $('#add-more-rolls').click(function(event){
      event.preventDefault()
      $('#append-more-rolls').append(
        `<div class="col-md-6 mb-4">
              <label class="card-text">Roll Type</label>
                <select name="cars" id="cars" class="form-control"> 
                    <option value="volvo">Roll Type</option>
                    <option value="saab">Saab</option>
                    <option value="mercedes">Mercedes</option>
                    <option value="audi">Audi</option>
                 </select>
          </div>

          <div class="col-md-6">
            <label class="card-text">Roll Name</label>
             <select name="c" id="c" class="form-control"> 
               <option value="volvo">Roll Name</option>
               <option value="saab">Saab</option>
               <option value="mercedes">Mercedes</option>
               <option value="audi">Audi</option>
             </select>
          </div>`)

      select2p()
    });

    $('#addssd-more-rolls').click(function(event){
      event.preventDefault()
      $('#appendssd-more-rolls').append(
        ` <div class="col-md-4 mb-4">
            <label class="card-text">Raw Material Type</label>
            <select name="raw" id="raw" class="form-control"> 
                <option value="volvo">Raw Material Type</option>
                <option value="saab">Saab</option>
                <option value="mercedes">Mercedes</option>
                <option value="audi">Audi</option>
             </select>
      </div>

      <div class="col-md-4">
        <label class="card-text">Chemicals</label>
         <select name="Chemicals" id="chemicals" class="form-control"> 
           <option value="volvo">Chemicals</option>
           <option value="saab">Saab</option>
           <option value="mercedes">Mercedes</option>
           <option value="audi">Audi</option>
         </select>
      </div>

      <div class="col-md-4">
        <label class="card-text">Weight</label>
         <select name="weight" id="weight" class="form-control"> 
           <option value="volvo">Weight</option>
           <option value="saab">Saab</option>
           <option value="mercedes">Mercedes</option>
           <option value="audi">Audi</option>
         </select>
      </div>`)
      select2p()
    })

     $('input[name="Datee"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });



    $('.date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });

    


  




    $('#raw_material_type').unbind().change(function(event) {
      event.preventDefault()
      let value = $(this).val()
      if (value === 'Yarn') {
        $('#append-here').html(`<div class="col-md-6">
                            <div class="form-group">
                              <label for="">Yarn type</label>
                              <input type="text" name="raw_custom_type" class="form-control" id="raw_custom_type" required="">
                            </div>
                          </div>
                            <div class="col-md-6">
                            <div class="form-group">
                              <label for="">No of cartons</label>
                              <input type="number" min="1" name="no_of_cartons" class="form-control" required="">
                            </div>
                          </div>
                          <!--<div class="col-md-6">
                            <div class="form-group">
                              <label for="">Average weight per cartons (KG)</label>
                              <input type="number" min="1" name="avg_weight_of_cartons" class="form-control" required="">
                            </div>
                          </div>
                          --!>
                          
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="">Total Weight (KG)</label>
                              <input type="number" min="1" name="weight" class="form-control" required="">
                            </div>
                          </div>`)
      }else if(value === 'Roing') {
        $('#append-here').html(`<div class="col-md-6">
                            <div class="form-group">
                              <label for="">Roing type</label>
                              <input type="text" name="raw_custom_type" class="form-control" id="raw_custom_type" required="">
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="">Total Weight (KG)</label>
                              <input type="number" min="1" name="weight" class="form-control" required="">
                            </div>
                          </div>`)

      }else if(value === 'Chemicals') {
        $('#append-here').html(`<div class="col-md-6">
                            <div class="form-group">
                              <label for="">Chemicals type</label>
                              <input type="text" name="raw_custom_type" class="form-control" id="raw_custom_type" required="">
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="">Total Weight (KG)</label>
                              <input type="number" name="weight" min="1" class="form-control" required="">
                            </div>
                          </div>`)
      }
    });
  })

function select2p() {
     $('#staff').select2({
         placeholder: "Select Operator",
     });

      $('#cars').select2({
         placeholder: "Select Operator",
     });

     $('#carrs').select2({
              placeholder: "Select Operator",
     }); 
  
  $('#carrrs').select2({
              placeholder: "Select Operator",
     }); 

  $('#raw').select2({
         placeholder: "Select Operator",
     });

  $('#chemicals').select2({
              placeholder: "Select Operator",
     }); 
  $('#weight').select2({
              placeholder: "Select Operator",
     }); 
}


$('#coating_report').submit(function(e){
  e.preventDefault()
  var coatingReportDetail = $(this).serializeArray();
  // console.log(coatingReportDetail);
  // return false;

  $.ajax({
    url: '<?php echo base_url();?>Admin/coatingReportDetail',
    type: 'POST',
    dataType: 'json',
    data: coatingReportDetail,
  })
  .done(function(result) {

    $('#coating_report_body').removeClass('d-none');
      console.log(result)
      // console.log(result.status)
      if(result.status === 'true'){
    var coating_allocate                     = result.data.coating_allocate_specific_data;  
    var coating_rolls                        = result.data.coating_rolls_specific_data;
    var coating_OutputRolls                  = result.data.coating_OutputRolls_specific_data;  
    var coating_raw_material_consume         = result.data.coating_raw_material_consumed_specific_data;  

    var html = '';

    $.map(coating_allocate, function(elem, index) {

      html += `<tr>
                  <td>${elem.coating_allocate_id}</td>
                  <td>${elem.staff_name}</td>
                  <td>${elem.coating_allocate_date}</td>`;
      
      html += `<th class="font-weight-bold"><table class="table table-bordered">`           
      $.map(coating_rolls[index], function(elem2, index2) {
        if(elem.coating_allocate_id === elem2.coating_rolls_allocate_id){
          html += `<tr><td>${elem2.roll_types_name}</td></tr>`
        }
      })
      html += `</table></th>`

      html += `<th class="font-weight-bold"><table class="table table-bordered">`           
      $.map(coating_rolls[index], function(elem3, index3) {
        if(elem.coating_allocate_id === elem3.coating_rolls_allocate_id){
          html += `<tr><td>${elem3.new_roll_name}</td></tr>`
        }
      })
      html += `</table></th>`

      html = html + `<th><table class="table-bordered table"><tr>
                                              
                                              <td>Roll Type</td>
                                              <td>Length</td>
                                              <td>Roll Name</td>
                                              <td>Weight</td>
                                              
                                            </tr>`  

                                  $.map(coating_OutputRolls[index], function(elem4, index4){ 
                                    
                                    if(elem.coating_allocate_id == elem4.coating_OutputRolls_allocate_id){

                                            if(elem4.coating_OutputRolls_output_type_f_u == "finish"){
                                                      html = html + `<tr>
                                                                                      <td>${elem4.roll_types_name}</td>
                                                                                      <td>${elem4.coating_OutputRolls_roll_length}</td>
                                                                                      <td>${elem4.coating_OutputRolls_roll_name}</td>
                                                                                      <td>${elem4.coating_OutputRolls_roll_weight}</td>
                                                                                    </tr>`;
                                                         }
                                                    
                                          } else {

                                          html = html +  `<tr>
                                                         <td colspan="4" align="center">Not Available</td>
                                                         </tr>`;       
                                            }   

                                    }); 

                              html = html +  `</table></th>`              
                              

                              // <td>Weight</td>
                              // <td>${elem5.coating_OutputRolls_roll_weight}</td>
    html = html + `<td><table class="table-bordered table"><tr>
                                              <td>Roll Type</td>
                                              <td>Length</td>
                                              <td>Roll Name</td>
                                              
                                            </tr>`  


                                      $.map(coating_OutputRolls[index], function(elem5, index5){        
                                            // console.log(elem.coating_allocate_id);
                                        if(elem.coating_allocate_id == elem5.coating_OutputRolls_allocate_id){
                                        
                                                if(elem5.coating_OutputRolls_output_type_f_u == "unfinish"){
                                                          html = html + `<tr>
                                                                                          <td>${elem5.roll_types_name}</td>
                                                                                          <td>${elem5.coating_OutputRolls_roll_length}</td>
                                                                                          <td>${elem5.coating_OutputRolls_roll_name}</td>
                                                                                          
                                                                                        </tr>`;
                                                             }
                               
                                                       
                                              } else {
                                         html = html +  `<tr>
                                                         <td colspan="4" align="center">Not Available</td></tr>`;       
                                                }   

                                        }); 

                                       html = html +  `</table></td>`                               


      html = html + `<td><table class="table-bordered table">`

                                $.map(coating_raw_material_consume[index], function(elem6, index6) {        
                                  if(elem.coating_allocate_id == elem6.coating_rmc_allocate_id){
                                   html = html + `<tr>
                                     <td>${elem6.coating_rmc_raw_material_type}</td>
                                   </tr></tr>`;
                                        } else {
                                   html = html +  `<td>Not Available</td>`;       
                                          }   
                                  }); 

                              
                              html = html + `</table></td>`      


      html = html + `<td><table class="table-bordered table">`

                                $.map(coating_raw_material_consume[index], function(elem7, index7) {        
                                  if(elem.coating_allocate_id == elem7.coating_rmc_allocate_id){
                                   html = html + `<tr>
                                     <td>${elem7.inward_type_of_type}</td>
                                   </tr></tr>`;
                                        } else {
                                   html = html +  `<td>Not Available</td>`;       
                                          }   
                                  });           

                                html = html + `</table></td>`

       html = html + `<td><table class="table-bordered table">`

                                $.map(coating_raw_material_consume[index], function(elem8, index8) {        
                                  if(elem.coating_allocate_id == elem8.coating_rmc_allocate_id){
                                   html = html + `<tr>
                                     <td>${elem8.coating_rmc_weight}</td>
                                   </tr></tr>`;
                                        } else {
                                   html = html +  `<td>Not Available</td>`;       
                                          }   
                                  }); 

                              
                              html = html + `</table></td>`                                                                               

      html += `</tr>`

    }); 

    $('#coating_report_data').html(html);
    } else {
      // alert('els')
    $('#coating_report_data').html('<tr><td colspan="10" class="text-center" style="align:center;color:red"> No Data Available </td></tr>');  
    }
    
  })
  .fail(function(jqXHR,exception) {
      console.log(jqXHR.responseText);
  })

});



</script>

