  <!DOCTYPE html>
<html>
<?php $title = "Coating Allocate";
  $nav_page = 10015;
  include 'admin_assets/include/header.php';
 ?>
 <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
 <style type="text/css">
   .select2-container--default .select2-selection--single .select2-selection__rendered {
       color: #444;
       line-height: 24px;
   }
   .select2-container .select2-selection--single {
       height: 38px;
   }
   .select2-container--default .select2-selection--single .select2-selection__arrow {
       height: 35px;
   }
  @media (min-width: 992px) {
   .modaledit-lg, .modalview-lg{
     max-width: 800px;
   }

 }
 </style>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php include 'admin_assets/include/navbar.php'; ?>
  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Coating Allocate</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Coating Allocate</li>
            </ol>
          </div><!-- /.col -->
          
          <div class="col-sm-12" id="sumit_alert" style="display:none">
                     <div class="alert alert-success " id="coating_success" role="alert" style="display: none;z-index: 2000;position:fixed;right:0;
            top:0;">
                    </div>
                      
                    
                    <div class="alert alert-danger " id="coating_danger" role="alert"  style="display: none;z-index: 2000;position:fixed;
          top:0;right:0;">
                    </div>
          </div>

        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">  

              <!-- /.card-header -->
              
<div class="card-body">
  <form action="" novalidate="novalidate" id="coating_allocate_data_insert" method="POST">
    <div class="row">

      <div class="col-md-6 mb-4">
          <div class="card-text lead font-weight-lighter py-2">Select Shift</div>
            <div class="custom-control custom-radio custom-control-inline">
                <input type="radio" id="customRadioInline1" name="customRadioInline1" class="custom-control-input">
                <label class="custom-control-label" for="customRadioInline1">Day Shift</label>
            </div>
          <div class="custom-control custom-radio custom-control-inline">
                <input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input">
                <label class="custom-control-label" for="customRadioInline2">Night Shift</label>
          </div>
      </div>
        
      <div class="col-md-6">
          <label class="card-text">Select Staff Operater</label>   
            <select name="staff" id="staff" class="form-control " >
              <option value="" style="display: none;"></option>
              <?php foreach ($staff_availability_list as $key => $value) { ?>
                  <option value="<?= $value->staff_id ?>"><?= $value->staff_name ?></option>
              <?php } ?>
            </select> 
      </div>

      <div class="col-md-6 mb-4">
          <label class="card-text">Select Machines</label>   
            <select name="machine" id="couting_machine" class="form-control">
              <option value="" style="display: none;"></option>
              <?php foreach ($couting_machine_data as $key => $value) { ?>
                  <option value="<?= $value->id ?>"><?= $value->couting_machine_name ?></option>
              <?php } ?>
            </select> 
      </div>
 
        <div class="col-md-6">
            <label class="card-text">Select Date</label>   
            <input type="text" name="Datee" value="" class="form-control ">
        </div>
    

       <!-- <div class="col-md-12">
=======
            <label class="card-text">Select Date</label>
            <input type="text" name="Datee" value="02/05/2021" class="form-control ">
        </div>

       <div class="col-md-12">
>>>>>>> cb8b740622be7c57947f44cd44ac816f2479c3c5
        <h4>Roll</h4>
       </div> -->
 <!--    <div class="col-md-12">
       <div class="custom-control custom-checkbox d-inline">
            <input type="checkbox" class="custom-control-input" id="rollfinishedCheckbox" name="dcallocate" value="finish">
            <label class="custom-control-label" for="rollfinishedCheckbox">Finished</label>
      </div> 
       <div class="custom-control custom-checkbox d-inline">
             <input type="checkbox" class="custom-control-input" id="unrollfinishedCheckbox" name="dcallocate" value="unfinish">
             <label class="custom-control-label" for="unrollfinishedCheckbox">Unfinished</label>
      </div>
    </div>
 -->


      <div class="col-md-6 mb-4">
            <label class="card-text">Roll Type</label>
            <select name="roll_type[]" id="roll_type" class="form-control roll_type"> 
              <option value="" style="display: none;"></option>
               <?php foreach ($all_rolls as $key => $value) { ?>
                   <option value="<?= $value->roll_types_id ?>"><?= $value->roll_types_name ?></option>
               <?php } ?>
            </select>
      </div>

      <div class="col-md-6">
        <label class="card-text">Roll Name</label>
         <select name="roll_name[]" id="roll_name" class="form-control roll_name" value=""> 
         </select>
      </div>


      <div class="col-md-12">
        <div class="row" id="append-more-rolls">

        </div>
      </div>

      <div class="col-md-12">
        <button class="btn btn-primary float-right btn-sm" id="add-more-rolls">Add more</button>
      </div>

          
    <!--  <div class="col-md-12 mb-4">
        <h4>Output</h4>
         
            <div class="custom-control custom-radio custom-control-inline">
                <input type="radio" id="customRadioInline" name="outputType" class="custom-control-input" value="Finished">
                <label class="custom-control-label" for="customRadioInline">Finished</label>
            </div>
          <div class="custom-control custom-radio custom-control-inline">
                <input type="radio" id="customRadioInline22" name="outputType" class="custom-control-input" value="Unfinished">
                <label class="custom-control-label" for="customRadioInline22">Unfinished</label>
          </div>
      </div>  -->  

       <div class="col-md-12">
                <h4>Output</h4>
                  <div class="custom-control custom-checkbox d-inline">
                      <input type="checkbox" class="custom-control-input" id="allocfinishedCheckbox" name="dcallocateF" value="finish">
                      <label class="custom-control-label" for="allocfinishedCheckbox">Finished</label>
                  </div> 
        </div>

        <div class="col-md-12" id="getallocfinishedrows">
                <div class="row "> 
                   <div class="col-md-12">
                      <button class="btn btn-sm btn-primary mt-3 addallocfinishedrow" style="display: none;">Add more</button>
                   </div>
                </div>
        </div>

        <div class="col-md-12">
                  <div class="custom-control custom-checkbox d-inline">
                     <input type="checkbox" class="custom-control-input" id="unallocfinishedCheckbox" name="dcallocateU" value="unfinish">
                     <label class="custom-control-label" for="unallocfinishedCheckbox">Unfinished</label>
                  </div>
         </div> 


          <div class="col-md-12" id="getallocunfinishedrows">
              <div class="row"> 
                  <div class="col-md-12">
                       <button class="btn btn-sm btn-primary mt-3 addallocunfinishedrow" style="display: none;">Add more</button>
                  </div>
              </div>
          </div>




                    <!-- & new output -->
   
<!--       <div class="col-md-12" id="roll-type-output" style="display: none;">
        <h4>Roll Type</h4>
      </div>

      <div class="col-md-12 mb-4">
        <div class="row" id="Finished-area" style="display: none;">
          <div class="col-md-6 ">
               <label for="usr">Quantity</label>
               <input type="text" class="form-control" id="usr" name="username">
           </div>
           <div class="col-md-6">
                   <label for="pwd">Length</label>
                   <input type="text" class="form-control" id="pwd" name="password">
           </div>
        </div>
      </div>


      <div class="col-md-12 mb-4">
        <div class="row" id="Unfinished-area" style="display: none;">
          <div class="col-md-4">
               <label for="usr">Name</label>
               <input type="text" class="form-control" id="usr" name="username">
           </div>
           <div class="col-md-4">
                <label for="pwd">Quantity</label>
                <input type="text" class="form-control" id="pwd" name="password">
           </div>
           <div class="col-md-4">
                <label for="pwd">Length</label>
                <input type="text" class="form-control" id="pwd" name="password">
           </div>
        </div>
      </div> -->
  


<div class="col-md-12">
        <h4>Raw Material Consumed</h4>
       </div>

    <div class="col-md-3 mb-4">
                
                <label class="card-text">Raw Material Type</label>
                <select name="raw_material_type[]" id="raw_material_type" class="form-control raw_material_type"> 
                    <option selected="" style="display: none;">Select Raw Material Type</option>
                    <option value="Yarn">Yarn</option>
                    <option value="Roing">Roving</option>
                    <option value="Chemicals">Chemicals</option>
                    <option value="Cylinder">Gas Cylinder</option>
                </select>
    </div>

          <div class="col-md-3">
              <label class="card-text">Raw Material Type of Type</label>
               <select name="raw_material_type_of_type[]" id="raw_material_type_of_type" class="form-control raw_material_type_of_type"> 
                 
               </select>
          </div>

            <div class="col-md-3">
              <label class="card-text">Raw Material Weight</label>
               <input type="text" name="weight[]" id="weight" class="form-control" value="" readonly >
            </div>

            <div class="col-md-3">
              <label class="card-text">Raw Material Weight Substraction</label>
               <input type="text" name="weight_substraction[]" id="weight_substraction" class="form-control" value=""  >
            </div>

            <div class="col-md-12">
              <div class="row" id="appendssd-more-rolls">
              </div>
            </div>
            
            <div class="col-md-12">
              <button class="btn btn-primary float-right btn-sm" id="addssd-more-rolls">Add more</button>
            </div>

     </div>                                                                                                   


     <div class="col-md-12">
        <button class="btn btn-success" type="submit" >Submit</button>
     </div>
  </form>
 </div>











              <!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
</body>
</html>

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>


<script>
  $(function(){

    getRollName();
    getRawMaterialType();

    $('.addallocfinishedrow').click(function(event) {
      event.preventDefault();
      getCCode()
    });

    $('.addallocunfinishedrow').click(function(event) {
      event.preventDefault();
      getallocUnFinishedCode()
    });


    

    $('#unrollfinishedCheckbox').on('change', function() {
        if($(this).prop('checked') === true){
            getallocUnFinishedCode()()
         }
         // else{
         //    $('.funrrow').remove()
         //    $('.addallocunfinishedrow').hide();
         // }
    });


    $('#allocfinishedCheckbox').on('change', function() {
        if($(this).prop('checked') === true){
            getCCode()
         }else{
            $('.frrow').remove()
            $('.addallocfinishedrow').hide();
         }
    });

    $('#unallocfinishedCheckbox').on('change', function() {
        if($(this).prop('checked') === true){
            getallocUnFinishedCode()()
         }else{
            $('.funrrow').remove()
            $('.addallocunfinishedrow').hide();
         }
    });

});

function getCCode() {
  $('#getallocfinishedrows').append(`<div class="row frrow" style="border: 2px solid #E0E0E0;padding: 20px 10px 30px 10px;margin:2% 0%">
                        <div class="col-md-6">
                          <label for="">Roll type</label>
                          <select name="roll_type_f[]" class="form-control roll_type_f" required="" >
                            
                            <?php foreach ($all_rolls as $key => $value): ?>
                              <option value="<?php echo $value->roll_types_id; ?>"><?php echo $value->roll_types_name; ?></option>
                            <?php endforeach ?>
                          </select>
                        </div>

                        <div class="col-md-6 mt-3 mt-md-0">
                          <label for="">Roll Length ( <sub>sq</sub><sup>2</sup><sub>m</sub> )</label>
                          <input type="number" name="no_of_rolls_f[]" class="form-control " required="" placeholder="Enter length">
                        </div>

                        <div class="col-md-6 mt-3">
                          <label for="">Roll weight (kg)</label> 
                          <input type="number" name="roll_weight_f[]" class="form-control" required="" step="any" placeholder="Enter roll weight">
                        </div>

                         <div class="col-md-6 mt-3">
                          <label for="">Roll Name</label> 
                          <input type="input" name="roll_name_f[]" class="form-control" required="" step="any" placeholder="Enter roll name">
                        </div>

                      </div>`)
  $('.addallocfinishedrow').show();
}


function getallocUnFinishedCode() {
  $('#getallocunfinishedrows').append(`<div class="row funrrow" style="border: 2px solid #E0E0E0;padding: 20px 10px 20px 10px;margin:2% 0%">
                        <div class="col-md-4">
                          <label for="">Roll type</label>
                          <select name="roll_type_u[]" class="form-control roll_type_u" required="">
                            
                            <?php foreach ($all_rolls as $key => $value): ?>
                              <option value="<?php echo $value->roll_types_id; ?>"><?php echo $value->roll_types_name; ?></option>
                            <?php endforeach ?>
                          </select>
                        </div>

                        <div class="col-md-4 my-3 my-md-0">
                          <label for="">Roll weight</label> 
                          <input type="number" name="roll_weight_u[]" class="form-control" required="" step="any" placeholder="Enter roll weight">
                        </div>

                         <div class="col-md-4">
                          <label for="">Roll Name</label> 
                          <input type="input" name="roll_name_u[]" class="form-control" required="" step="any" placeholder="Enter roll name">
                        </div>

                      </div>`)
  $('.addallocunfinishedrow').show();
};







  $(document).ready(function () { 

    $("input[name=outputType]").change(function(){
        var radioValue = $("input[name=outputType]:checked").val();
        if(radioValue === "Finished"){
            $('#roll-type-output').show()
            $('#Finished-area').show();
            $('#Unfinished-area').hide();
        } else if(radioValue === "Unfinished") {
            $('#roll-type-output').show()
            $('#Finished-area').hide();
            $('#Unfinished-area').show();
        }
    });

    select2p()

    $('#add-more-rolls').click(function(event){
      event.preventDefault()
      $('#append-more-rolls').append(
         `<div class="col-md-6 mb-4">
              <label class="card-text">Roll Type</label>
                <select name="roll_type[]"  class="form-control roll_type"> 
                    <?php foreach ($all_rolls as $key => $value) { ?>
                        <option value="<?= $value->roll_types_id ?>"><?= $value->roll_types_name ?></option>
                    <?php } ?>
                 </select>
          </div>

          <div class="col-md-6">
            <label class="card-text">Roll Name</label>
             <select name="roll_name[]" id="roll_name" class="form-control roll_name" value=""> 
               
             </select>
          </div>`)

      getRollName()
      select2p()
    });


    $('#addssd-more-rolls').click(function(event){
      event.preventDefault()
      $('#appendssd-more-rolls').append(
      `<div class="col-md-3 mb-4">
            <label class="card-text">Raw Material Type</label>
            <select name="raw_material_type[]" class="form-control raw_material_type"> 
                <option value="Yarn">Yarn</option>
                <option value="Roing">Roving</option>
                <option value="Chemicals">Chemicals</option>
                <option value="Cylinder">Gas Cylinder</option>
             </select>
      </div>

      <div class="col-md-3">
        <label class="card-text">Raw Material Type of Type</label>
         <select name="raw_material_type_of_type[]" id="raw_material_type_of_type" class="form-control raw_material_type_of_type"> 
           
         </select>
      </div>

      <div class="col-md-3">
        <label class="card-text">Raw Material Weight</label>
         <input type="text" name="weight[]" id="weight" class="form-control" value="" readonly>
      </div>

      <div class="col-md-3">
        <label class="card-text">Raw Material Weight Substraction</label>
         <input type="text" name="weight_substraction[]" id="weight_substraction" class="form-control" value=""  >
      </div>`)
      getRawMaterialType()
      select2p()
    })

     $('input[name="Datee"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });



    $('.date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });

    

  })

function select2p() {
     $('#staff').select2({
         placeholder: "Select Staff Operator",
     });

      $('#couting_machine').select2({
         placeholder: "Select Machine",
     });

     $('.roll_type').select2({
              placeholder: "Select Roll Type",
     });

     $('.roll_name').select2({
              placeholder: "Select Roll Name",
     }); 

    $('.roll_type_f').select2({
                placeholder: "Select Finished Roll Type",
       }); 

    $('.roll_type_u').select2({
                placeholder: "Select Unfinished Roll Type",
       }); 

    $('.raw_material_type').select2({
           placeholder: "Select Raw Material Type",
       });

     $('.raw_material_type_of_type').select2({
              placeholder: "Select Raw Material Type of Type",
     }); 

    // $('#weight').select2({
    //             placeholder: "Select Operator",
    //    }); 
}

function getRollName() {
  $('.roll_type').on('change', function() {


          $.ajax({
            url: '<?php echo base_url();?>Admin/newRollCreated',
            type: 'POST',
            dataType: 'json',
            data: {rolltype: this.value},
          })
          .done((result) => {
            // console.log('hiisafasdfs');
            // console.log(result);
            var html = '';
             // html = html + `<option value="" style="display: none;"></option>`;
            
            result.forEach( function(element, index) {
               html = html + `<option value="${element.new_roll_id}">${element.new_roll_name}(${element.new_roll_typef})</option>`;  
            });
            $(this).parent().next().children('select').html(html)
            select2p()
          })
          .fail(function(jqXHR,exception) {
            console.log(jqXHR.responseText);
          })
  });
}


function getRawMaterialType(){
  $('.raw_material_type').on('change', function() {
          $.ajax({
            url: '<?php echo base_url();?>Admin/getInwardByInwardType',
            type: 'POST',
            dataType: 'json',
            data: {inwardtype: this.value},
          })
          .done((result) => {
            console.log(result);
            var inward_type_of_type = '<option value="">Select type</option>';
            // var inward_weight = '';
            result.forEach( function(element, index) {
             inward_type_of_type = inward_type_of_type + `<option value="${element.inward_id}">${element.inward_type_of_type}</option>`;  
             // inward_weight = inward_weight + `<option value="${element.inward_id}">${element.inward_weight}</option>`;  
            });
            $(this).parent().next().children('select').html(inward_type_of_type)
            
            // $(this).parent().next().next().children('input').html(inward_weight)
            select2p()
          })
          .fail(function(jqXHR,exception) {
            console.log(jqXHR.responseText);
          })
  });

  $('.raw_material_type_of_type').on('change', function() {
         $.ajax({
            url: '<?php echo base_url();?>Admin/getInwardWeightByInwardTypeOfType',
            type: 'POST',
            dataType: 'json',
            data: {inwardtypeoftype: this.value},
          })
          .done((result) => {
            console.log(result);
            // alert(result.inward_weight)
                $(this).parent().next().children('input').val(result.inward_weight);
            select2p()
          })
          .fail(function(jqXHR,exception) {
            console.log(jqXHR.responseText);
          })
    });

  
}



$('#coating_allocate_data_insert').submit(function(e){
  e.preventDefault()
  var coutingAllocatePageData = $(this).serializeArray();
  // console.log(coutingAllocatePageData);
  // return false;

  $.ajax({
    url: '<?php echo base_url();?>Admin/coatingAllocateDataInsert',
    type: 'POST',
    dataType: 'json',
    data: coutingAllocatePageData,
  })
  .done(function(result) {
    console.log(result);
    
    if(result.status === true){


          $('#sumit_alert').show();  
          $('#coating_danger').hide();  
          $('#coating_success').show();
          $('#coating_success').html('Success');
          
          setTimeout(function(){ 
            $('#coating_success').hide();  
          }, 15000);
          location.reload();
          
    } else {
          
          $('#sumit_alert').show(); 
          $('#coating_success').hide(); 
          $('#coating_danger').show();
          $('#coating_danger').html(result.data);
          
           setTimeout(function(){ 
          $('#coating_danger').hide();
          }, 15000);

    }
    
  })
  .fail(function(jqXHR,exception) {
      console.log(jqXHR.responseText);
  })
  
  

});



</script>

