<!DOCTYPE html>
<html>
<?php $title = "Create Vendor";
  $nav_page = 7;
  include 'admin_assets/include/header.php';
 ?>
 <style type="text/css">
   input[type=number]::-webkit-inner-spin-button, 
input[type=number]::-webkit-outer-spin-button { 
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    margin: 0; 
}


 </style>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
 <?php include 'admin_assets/include/navbar.php'; ?>

  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Create Vendor</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Inventory</a></li>
              <li class="breadcrumb-item active">Create Vendor</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

     <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <div class="card">
              <div class="card-header">

                <button type="button" class="btn btn-info float-right" data-toggle="modal" data-target="#modal-xl">Add <i class="fa fa-plus"></i></button>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>Vendor Name</th>
                        <th>Vendor Phone</th>
                        <th>Company Name</th>
                        <th>Company Address</th>
                        <th>Purchase Order</th>
                        <th>Manage</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach($data as $key => $val): ?>
                      <tr>
                        <td><?= ++$key?></td>
                        <td><?= $val->vendor_name?></td>
                        <td><?= $val->vendor_phone?></td>
                        <td><?= $val->vendor_comp_name?></td>
                        <td><?= $val->vendor_comp_addr?></td>
                        <td class="text-center"><a href="<?= base_url()?>admin/purchase-order/<?= $val->vendor_id?>"><button class="btn btn-success btn-sm">Generate</button></a></td>
                        <td class="text-center"><a href="#" data-toggle="modal" data-target="#modal-xlview<?= $val->vendor_id?>"><i class="fa fa-eye text-info" title="View"></i></a>&emsp;|&emsp;<a href="#" data-toggle="modal" data-target="#modal-xledit<?= $val->vendor_id?>"><i class="fa fa-edit text-success" title="Edit"></i></a>&emsp;|&emsp;<a href="#" data-toggle="modal" data-target="#modal-sm<?= $val->vendor_id?>"><i class="fa fa-trash text-danger" title="Delete"></i></a></td>
                      </tr>

                      <!-- Vendor Detail View -->
          <div class="modal fade" id="modal-xlview<?= $val->vendor_id?>">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">View Vendor Details</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
            <div class="card">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-4">
                    <h4>Company Details</h4>
                <hr>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">Company Name</div>
                  <div class="col-md-7"><?= $val->vendor_comp_name?></div>
                </div>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">Company Phone</div>
                  <div class="col-md-7"><?= $val->vendor_comp_phone?></div>
                </div>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">Company Email</div>
                  <div class="col-md-7"><?= $val->vendor_comp_email?></div>
                </div>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">Company Address</div>
                  <div class="col-md-7"><?= $val->vendor_comp_addr?></div>
                </div>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">Country</div>
                  <div class="col-md-7"><?= $val->vendor_comp_country?></div>
                </div>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">State</div>
                  <div class="col-md-7"><?= $val->vendor_comp_state?></div>
                </div>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">City</div>
                  <div class="col-md-7"><?= $val->vendor_comp_city?></div>
                </div>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">Pin Code</div>
                  <div class="col-md-7"><?= $val->vendor_comp_pincode?></div>
                </div>
                  </div>
                  <div class="col-md-4">
                    <h4>Vendor Details</h4>
                <hr>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">Vendor Name</div>
                  <div class="col-md-7"><?= $val->vendor_name?></div>
                </div>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">Vendor Phone</div>
                  <div class="col-md-7"><?= $val->vendor_phone?></div>
                </div>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">Vendor Address</div>
                  <div class="col-md-7"><?= $val->vendor_addr?></div>
                </div>
                  </div>
                  <div class="col-md-4">
                    <h4>Bank Detail</h4>
                <hr>
                    <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">Bank Name</div>
                  <div class="col-md-7"><?= $val->vendor_bank_name?></div>
                </div>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">Branch Name</div>
                  <div class="col-md-7"><?= $val->vendor_branch_name?></div>
                </div>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">Account No.</div>
                  <div class="col-md-7"><?= $val->vendor_account_no?></div>
                </div>
                <div class="row p-2">
                  <div class="col-md-5 font-weight-bold">IFSC Code</div>
                  <div class="col-md-7"><?= $val->vendor_ifsc_code?></div>
                </div>
                  </div>
                </div>
                
              </div>
            </div>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->

      <!-- Vendor Edit -->
          <div class="modal fade" id="modal-xledit<?= $val->vendor_id?>">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Edit Vendor Details</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
               <form class="vendoredit" method="post">
              <div class="card-body">
                <div id="messageForm"></div>
                <h5>Company Details</h5>
                <hr>
                <div class="row">
                  <div class="col-md-4">
                    <input type="hidden" name="vendorid" value="<?= $val->vendor_id?>">
                    <div class="form-group">
                      <label for="ecname">Company Name <small class="text-danger">&ast;</small></label>
                      <input type="text" name="compname" id="ecname" class="form-control" placeholder="Company Name" value="<?= $val->vendor_comp_name?>" required>

                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="ecphone">Company Phone <small class="text-danger">&ast;</small></label>
                      <input type="number" name="comphone" id="ecphone" class="form-control" placeholder="Company Phone" value="<?= $val->vendor_comp_phone?>" required>
                    </div>
                  </div>

                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="cemail">Company Email <small class="text-danger">&ast;</small></label>
                      <input type="eemail" name="compemail" id="ecemail" class="form-control" placeholder="Company Email" value="<?= $val->vendor_comp_email?>" required>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="ecaddr">Company Address <small class="text-danger">&ast;</small></label>
                      <input type="text" name="compaddress" id="ecaddr" class="form-control" placeholder="Company Address" value="<?= $val->vendor_comp_addr?>" required>

                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="ecountry">Country <small class="text-danger">&ast;</small></label>
                      <input type="text" name="country" id="ecountry" class="form-control" placeholder="Country" value="<?= $val->vendor_comp_country?>" required>
                    </div>
                  </div>

                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="estate">State <small class="text-danger">&ast;</small></label>
                      <input type="text" name="state" id="estate" class="form-control" placeholder="State" value="<?= $val->vendor_comp_state?>" required>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="ecity">City <small class="text-danger">&ast;</small></label>
                      <input type="text" name="city" id="ecity" class="form-control" placeholder="City" value="<?= $val->vendor_comp_city?>" required>

                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="epincode">Pin Code <small class="text-danger">&ast;</small></label>
                      <input type="number" name="pincode" id="epincode" class="form-control" placeholder="Pin Code" value="<?= $val->vendor_comp_pincode?>" required>
                    </div>
                  </div>

                </div>
                <br>
                 <h5>Contact Person Details</h5>
                <hr>
                <div class="row">
                  <div class="col-md-3">
                    <div class="form-group">
                      <label for="evname">Vendor Name <small class="text-danger">&ast;</small></label>
                      <input type="text" name="vendorname" id="evname" class="form-control" placeholder="Vendor Name" value="<?= $val->vendor_name?>" required="">

                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group">
                      <label for="evphone">Vendor Phone <small class="text-danger">&ast;</small></label>
                      <input type="number" name="vendorphone" id="evphone" class="form-control" placeholder="Vendor Phone" value="<?= $val->vendor_phone?>" required="">
                    </div>
                  </div>

                   <div class="col-md-6">
                    <div class="form-group">
                      <label for="evaddr">Vender Address <small class="text-danger">&ast;</small></label>
                      <input type="text" name="vendoraddr" id="evaddr" class="form-control" placeholder="Vendor Address" value="<?= $val->vendor_addr?>" required="">
                    </div>
                  </div>

                </div>

                <br>
                 <h5>Bank Details</h5>
                <hr>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="ebname">Bank Name <small class="text-danger">&ast;</small></label>
                      <input type="text" name="bankname" id="ebname" class="form-control" placeholder="Bank Name" value="<?= $val->vendor_bank_name?>" required>

                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="ebranch">Branch Name <small class="text-danger">&ast;</small></label>
                      <input type="text" name="branchname" id="ebranch" class="form-control" placeholder="Branch Name" value="<?= $val->vendor_branch_name?>" required>
                    </div>
                  </div>

                   <div class="col-md-6">
                    <div class="form-group">
                      <label for="eactno">Account No. <small class="text-danger">&ast;</small></label>
                      <input type="number" name="accountno" id="eactno" class="form-control" placeholder="Account Number" value="<?= $val->vendor_account_no?>" required>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="eifsc">IFSC Code <small class="text-danger">&ast;</small></label>
                      <input type="text" name="ifsccode" id="eifsc" class="form-control" placeholder="IFSC" value="<?= $val->vendor_ifsc_code?>" required>
                    </div>
                  </div>

                </div> 
                <div id="messageForm"></div> 

        </div>
          

        <!-- /.card-body -->

        <div class="card-footer">
          <button type="submit" class="btn btn-primary float-right">Submit</button>
        </div>
      </form>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->

      <!-- Delete Staff -->
                  <div class="modal fade" id="modal-sm<?= $val->vendor_id?>">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">Delete Vendor</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <form action="<?= base_url()?>admin/delete-vendor" method="post"> 
                          <div class="modal-body">
                            <input type="hidden" name="vid" value="<?= $val->vendor_id?>">
                            <p>Are you sure, you want to delete this?</p>
                          </div>
                          <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Yes</button>
                          </div>
                        </form>
                      </div>
                      <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                  </div>
                  <!-- /.modal -->


                    <?php endforeach; ?>
                    </tbody>
                    

                  </table>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Add Vendor -->
          <div class="modal fade" id="modal-xl">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Add Vendor</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
             <!-- form start -->
            <form id="ajaxform1" method="post">
              <div class="card-body">
                <div id="messageForm"></div>
                <h5>Company Details</h5>
                <hr>
                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="cname">Company Name <small class="text-danger">&ast;</small></label>
                      <input type="text" name="compname" id="cname" class="form-control" placeholder="Company Name" required>

                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="cphone">Company Phone <small class="text-danger">&ast;</small></label>
                      <input type="number" name="comphone" id="cphone" class="form-control" placeholder="Company Phone" required>
                    </div>
                  </div>

                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="cemail">Company Email <small class="text-danger">&ast;</small></label>
                      <input type="email" name="compemail" id="cemail" class="form-control" placeholder="Company Email" required>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="caddr">Company Address <small class="text-danger">&ast;</small></label>
                      <input type="text" name="compaddress" id="caddr" class="form-control" placeholder="Company Address" required>

                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="country">Country <small class="text-danger">&ast;</small></label>
                      <input type="text" name="country" id="country" class="form-control" placeholder="Country" required>
                    </div>
                  </div>

                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="state">State <small class="text-danger">&ast;</small></label>
                      <input type="text" name="state" id="state" class="form-control" placeholder="State" required>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="city">City <small class="text-danger">&ast;</small></label>
                      <input type="text" name="city" id="city" class="form-control" placeholder="City" required>

                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label for="pincode">Pin Code <small class="text-danger">&ast;</small></label>
                      <input type="number" name="pincode" id="pincode" class="form-control" placeholder="Pin Code" required>
                    </div>
                  </div>

                </div>
                <br>
                 <h5>Contact Person Details</h5>
                <hr>
                <div class="row">
                  <div class="col-md-3">
                    <div class="form-group">
                      <label for="vname">Vendor Name <small class="text-danger">&ast;</small></label>
                      <input type="text" name="vendorname" id="vname" class="form-control" placeholder="Vendor Name" required="">

                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group">
                      <label for="vphone">Vendor Phone <small class="text-danger">&ast;</small></label>
                      <input type="number" name="vendorphone" id="vphone" class="form-control" placeholder="Vendor Phone" required="">
                    </div>
                  </div>

                   <div class="col-md-6">
                    <div class="form-group">
                      <label for="vaddr">Vender Address <small class="text-danger">&ast;</small></label>
                      <input type="text" name="vendoraddr" id="vaddr" class="form-control" placeholder="Vendor Address" required="">
                    </div>
                  </div>

                </div>

                <br>
                 <h5>Bank Details</h5>
                <hr>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="bname">Bank Name <small class="text-danger">&ast;</small></label>
                      <input type="text" name="bankname" id="bname" class="form-control" placeholder="Bank Name" required>

                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="branch">Branch Name <small class="text-danger">&ast;</small></label>
                      <input type="text" name="branchname" id="branch" class="form-control" placeholder="Branch Name" required>
                    </div>
                  </div>

                   <div class="col-md-6">
                    <div class="form-group">
                      <label for="actno">Account No. <small class="text-danger">&ast;</small></label>
                      <input type="number" name="accountno" id="actno" class="form-control" placeholder="Account Number" required>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="ifsc">IFSC Code <small class="text-danger">&ast;</small></label>
                      <input type="text" name="ifsccode" id="ifsc" class="form-control" placeholder="IFSC" required>
                    </div>
                  </div>

                </div> 
                <div id="messageForm"></div> 

        </div>
          

        <!-- /.card-body -->

        <div class="card-footer">
          <button type="submit" class="btn btn-primary float-right">Submit</button>
        </div>
      </form>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
    
</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>

  <script type="text/javascript">
  $(function() {
    $('#ajaxform1').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/insert-vendor", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>

<script type="text/javascript">
  $(function() {
    $('.vendoredit').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/update-vendor", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>
</body>
</html>
