<!DOCTYPE html>
<html>
<?php $title = "Raw Materials";
$nav_page = 10100;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }

}
</style>
<body class="hold-transition sidebar-mini">

  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Manage Excess raw materials</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Manage raw materials</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <div class="card">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-12 mb-3">
                    <?php echo $this->session->flashdata('val_error'); ?>
                  </div>
                </div>
                <div class="table-responsive">
                  <table id="examplec1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th style="width: 5%">Sl no.</th>
                        <th>Raw material type</th>
                        <th>Second Type</th>
                        <th>No of cartons</th>
                        <!-- <th>Avg weight</th> -->
                        <th>Weight</th>
                        <th style="width: 20%">Date</th>
                        <!-- <th style="width: 15%">Manage</th> -->
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($all_data as $key => $value): ?>

                        <tr>
                          <td><?php echo $key+1; ?></td>
                          <td><?php echo $value->inward_type ?></td>
                          <td><?php echo $value->inward_type_of_type ?></td>
                          <td><?php echo $value->inward_no_of_cartons ?></td>
                          <!-- <td><?php echo $value->inward_avg_weight ?></td> -->
                          <td><?php echo $value->inward_weight ?></td>
                          <td><?php echo date('d-m-Y, h:i a', strtotime($value->inward_date)) ?></td>
                          <!-- <td> -->
                            <!-- <button class="btn btn-warning" data-toggle="modal" data-target="#edit-raw-materials<?php echo $key; ?>"><i class="fa fa-edit"></i></button>  -->
                          <!--   <a href="<?php echo base_url();?>Admin/delete_Raw_material/<?php echo $value->inward_id ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this item?');"><i class="fa fa-trash"></i></a> -->
                          <!-- </td> -->
                        </tr>


                        <div id="edit-raw-materials<?php echo $key; ?>" class="modal fade" role="dialog">
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h4 class="modal-title">Edit</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <form action="<?php echo base_url();?>Admin/edit_inward_data" method="POST">
                                <div class="modal-body">
                                  <div class="form-group">
                                    <label for="">Raw Material Type</label>
                                    <input type="text" name="raw_material_type" id="raw_material_type" class="form-control" value="<?php echo $value->inward_type; ?>" readonly="">
                                  </div>

                                  <input type="hidden" name="id" value="<?php echo $value->inward_id; ?>">

                                  <?php if ($value->inward_type === 'Yarn') {?>
                                   <div class="form-group">
                                     <label for="">Yarn type</label>
                                     <input type="text" name="raw_custom_type" class="form-control" id="raw_custom_type" required="" readonly="" value="<?php echo $value->inward_type_of_type ?>">
                                   </div>

                                   <div class="form-group">
                                     <label for="">No of cartons</label>
                                     <input type="number" min="1" name="no_of_cartons" class="form-control" required="" value="<?php echo $value->inward_no_of_cartons ?>">
                                   </div>

                                   <div class="form-group">
                                     <label for="">Total Weight (KG)</label>
                                     <input type="number" min="1" name="weight" class="form-control" required="" value="<?php echo $value->inward_weight ?>">
                                   </div>
                                  <?php }elseif ($value->inward_type === 'Roing') {?>
                                      <div class="form-group">
                                        <label for="">Roing type</label>
                                        <input type="text" name="raw_custom_type" class="form-control" id="raw_custom_type" required="" readonly="" value="<?php echo $value->inward_type_of_type ?>">
                                      </div>
                                      <div class="form-group">
                                        <label for="">Total Weight (KG)</label>
                                        <input type="number" min="1" name="weight" class="form-control" required="" value="<?php echo $value->inward_weight ?>">
                                      </div>
                                  <?php }elseif ($value->inward_type === 'Chemicals') {?>
                                    <div class="form-group">
                                      <label for="">Chemicals type</label>
                                      <input type="text" name="raw_custom_type" class="form-control" id="raw_custom_type" required="" readonly="" value="<?php echo $value->inward_type_of_type ?>">
                                    </div>
                                    <div class="form-group">
                                      <label for="">Total Weight (KG)</label>
                                      <input type="number" name="weight" min="1" class="form-control" required="" value="<?php echo $value->inward_weight ?>">
                                    </div>
                                  <?php } ?>


                                </div>
                                <div class="modal-footer">
                                  <button type="submit" class="btn btn-success">Submit</button>
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      <?php endforeach ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Sl no.</th>
                            <th>Raw material type</th>
                            <th>Second Type</th>
                            <th>No of cartons</th>
                            <!-- <th>Avg weight</th> -->
                            <th>Weight</th>
                            <th>Date</th>
                            <!-- <th style="display: none;">Manage</th> -->
                        </tr>
                    </tfoot>

            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Add Staff -->

</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->

</div>



<?php include 'admin_assets/include/footer.php'; ?>
<script>
  $(function() {



    $('input[name="dop"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxYear: parseInt(moment().format('YYYY'),10)
    });
  });

  $(document).ready(function() {
      // Setup - add a text input to each footer cell
      $('#examplec1 tfoot th').each( function () {
          var title = $(this).text();
          $(this).html( '<input class="form-control" type="text" placeholder="Search '+title+'" />' );
      } );
   
      // DataTable
      var table = $('#examplec1').DataTable({
          initComplete: function () {
              // Apply the search
              this.api().columns().every( function () {
                  var that = this;
   
                  $( 'input', this.footer() ).on( 'keyup change clear', function () {
                      if ( that.search() !== this.value ) {
                          that
                              .search( this.value )
                              .draw();
                      }
                  } );
              } );
          }
      });
   
  } );
</script>


</body>
</html>
