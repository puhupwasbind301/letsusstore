<!DOCTYPE html>
<html>
<?php $title = "Machine Staus";
  $nav_page = 57;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
 <?php include 'admin_assets/include/navbar.php'; ?>

  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Machine Status</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Manufacturing</a></li>
              <li class="breadcrumb-item active">Machine Status</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <div class="card">
      <div class="card-header">
      
      </div>
      <div class="card-body">
      <div class=" col-md-3 offset-md-9">
                    <div class="form-group">
                      <label for="adate">Date</label>
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="far fa-calendar-alt"></i>
                        </span><input type="text" value="<?php echo isset($date) ? date('m-d-Y', strtotime($date)) : ''?>" name="adate" id="adate" class="form-control datepick" >
                        
                      </div>
                      
                    </div>
                  </div>
      <div class="table-responsive">
        <table  id="example1" class="table table-bordered table-striped">
          <thead class="thead-light">
            <tr>
              <th>#</th>
              <th>Machine</th>
              <th>Stop Time</th>
              <th>Start Time</th>
              <th>Reason</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($machine as $key => $val): ?>
              <tr>
                <td><?= ++$key?></td>
                <td><?= $val->machine_model?></td>
                <td><?= $val->mstatus_stop_time?></td>
                <td><?= $val->mstatus_start_time?></td>
                <td><?php if($val->mstatus_reason == 1){ echo "Maintenance"; }else if($val->mstatus_reason == 2){ echo "Power Off"; } ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
  <script>
  $(function() {
    $('.datepick').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10),
    });

    $('input[name="adate"]').change(function(e) {
      e.preventDefault()
      let date = $(this).val()

      window.location.replace($('meta[name=url]').attr("content") + 'admin/machine-status?date=' + encodeURIComponent(date))
    })
  });
</script>
</body>
</html>
