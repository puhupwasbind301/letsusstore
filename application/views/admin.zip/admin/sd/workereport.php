<!DOCTYPE html>
<html>
<?php $title = "Workers Report";
$nav_page = 56;
include 'admin_assets/include/header.php';
?>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Worker Report</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url()?>admin">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Manufacturing</a></li>
              <li class="breadcrumb-item active">Worker Reports</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <div class="card">
      <div class="card-header">

      </div>
      <div class="card-body">


        <div class="row d-print-none">
          <div class="col-sm-4">
            <div class="form-group">
              <label>Get Report by</label>
              <select class="form-control" id="report">
               <option value="">---Select---</option>
               <option value="1">by Staff</option>
               <option value="2">by Date</option>
             </select>
           </div> 
         </div>
       </div>
       <div id="show1" style="display: none;" class="d-print-none">
         <div class="row">
          <div class="col-sm-4">
            <div class="form-group">
              <label>Select Staff</label>
              <select class="form-control" name="staff" id="staff">
                <option value="">---Select Staff---</option>
                <?php foreach($staff as $key => $val): ?>
                  <option value="<?= $val->staff_id?>"><?= $val->staff_name?></option>
                <?php endforeach; ?>
              </select>
              <small id="staffnot" class="text-danger"></small>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="form-group">
              <label for="fdate">First Date</label>
              <div class="input-group-prepend">
                <span class="input-group-text">
                  <i class="far fa-calendar-alt"></i>
                </span><input type="text" name="fdate" id="fdate" class="form-control daterangep">
              </div>
              <small id="frstdate" class="text-danger"></small>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="form-group">
              <label for="sdate">Second Date</label>
              <div class="input-group-prepend">
                <span class="input-group-text">
                  <i class="far fa-calendar-alt"></i>
                </span><input type="text" name="sdate" id="sdate" class="form-control daterangep">
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <button type="button" class="btn btn-primary float-sm-right" id="getstaff">Get</button>
          </div>
        </div>
      </div>
      
      <div id="show2" style="display: none;" class="d-print-none">      
        <div class="row">
          <div class="col-sm-4">
            <div class="form-group">
              <label for="shift">Shift</label>
              <select class="form-control" id="shift">
                <option value="">---Select Shift---</option>
                <option value="1">Day</option>
                <option value="2">Night</option>
              </select>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="form-group">
              <label for="dfdate">First Date</label>
              <div class="input-group-prepend">
                <span class="input-group-text">
                  <i class="far fa-calendar-alt"></i>
                </span><input type="text" name="dfdate" id="dfdate" class="form-control daterangep">
              </div>
              <small id="dfrstdate" class="text-danger"></small>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="form-group">
              <label for="dsdate">Second Date</label>
              <div class="input-group-prepend">
                <span class="input-group-text">
                  <i class="far fa-calendar-alt"></i>
                </span><input type="text" name="dsdate" id="dsdate" class="form-control daterangep">
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <button type="button" class="btn btn-primary float-sm-right" id="getwork">Get</button>
          </div>

        </div>
      </div>

      <br><br>
      <div class="table-responsive">
        <table  id="mytable1" class="table table-bordered table-striped">
          <thead class="thead-light">
            <tr>
              <th>#</th>
              <th>Machine</th>
              <th>Staff Name</th>
              <th>Date</th>
              <th>Shift</th>
              <th>Meter</th>
              <th>Cone Given(in kgs)</th>
              <th>Wastage(in kgs)</th>
              <th>Bal. Taana</th>
              <th>Roll Weight(in kgs)</th>
              <th>Wastage %</th>
            </tr>
          </thead>
          <tbody id="workdata">

          </tbody>
        </table>
      </div>
    </div>
  </div>



</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php'; ?>

<script type="text/javascript">
  $(function() { 
    $('#report').change(function(){

     let vals = $(this).val();

     if(vals === '1'){

      $('#show1').show();
      $('#show2').hide();

    }
    else if(vals === '2'){

      $('#show2').show();
      $('#show1').hide();  
    }
    else{


    }
  });
  });
</script>
<script>
  $(function() {
    $('.daterangep').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });

  });
</script>
<script type="text/javascript">
  $(document).ready(function(){
    $('#getstaff').click(function(){

      var staff = $('#staff').val();
      var first = $('#fdate').val();
      var second = $('#sdate').val();

      if(staff === ""){

       $('#staffnot').html('Staff is not selected');
     }
     else if(new Date(first) > new Date(second)){

      $('#frstdate').html('First date should be less than Second date');
    }
    else{

       

     $.ajax({

       type       : 'POST',
       url        : '<?php echo base_url() ?>admin/get-staff-work-detail',
       dataType   : 'json',
       data       : {'staff':staff, 'fdate':first,'sdate':second},
       beforeSend : function() {

        $('#workdata').html('');
      },
       success    : function(data) {

        $.map(data, function(ele,i){

          $('#workdata').append(`<tr>
            <td>${++i}</td>
            <td>${ele.machine_model}</td>
            <td>${ele.staff_name}</td>
            <td>${ele.work_date}</td>
            <td>${(ele.work_shift == 1) ? "Day" : "Night"}</td>
            <td>${ele.work_meter}</td>
            <td>${ele.work_cone_given}</td>
            <td>${ele.work_wastage}</td>
            <td>${ele.work_beam_bal}</td>
            <td>${ele.work_roll_weight}</td>
            <td>${Math.round((ele.work_wastage / ele.work_cone_given)*100)}</td>
            </tr>`);

        })

        $("#mytable1").DataTable();
        

      },error: function(jqXHR, exception) {

        console.log(jqXHR.responseText);
      }

    });

   }

 });


  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    $('#getwork').click(function(){

      var first = $('#dfdate').val();
      var second = $('#dsdate').val();
      var shift = $('#shift').val();

      if(new Date(first) > new Date(second)){

        $('#dfrstdate').html('First date should be less than Second date');
      }
      else{

          
       $.ajax({

         type       : 'POST',
         url        : '<?php echo base_url() ?>admin/get-work-detail-staff',
         dataType   : 'json',
         data       : {'dfdate':first,'dsdate':second, 'shift':shift},
         beforeSend : function() {

        $('#workdata').html('');
      },
         success    : function(datas) {

          

          $.map(datas, function(elem,j){

            $('#workdata').append(`<tr>
              <td>${++j}</td>
              <td>${elem.machine_model}</td>
              <td>${elem.staff_name}</td>
              <td>${elem.work_date}</td>
              <td>${(elem.work_shift == 1) ? "Day" : "Night"}</td>
              <td>${elem.work_meter}</td>
              <td>${elem.work_cone_given}</td>
              <td>${elem.work_wastage}</td>
              <td>${elem.work_beam_bal}</td>
              <td>${elem.work_roll_weight}</td>
            <td>${Math.round((elem.work_wastage/elem.work_cone_given)*100)}</td>

              </tr>`);

          })

          $("#mytable1").DataTable();
          

        },error: function(jqXHR, exception) {

          console.log(jqXHR.responseText);
        }

      });

     }

   });


  });
</script>

</body>
</html>
