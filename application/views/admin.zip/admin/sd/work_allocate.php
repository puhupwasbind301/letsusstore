<!DOCTYPE html>
<html>
<?php $title = "Work Allocate";
$nav_page = 5;
include 'admin_assets/include/header.php';
?>
<!-- jQuery -->
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }
}
</style>

<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Work Allocate</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Work Allocate</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <div class="card">
              <div class="card-header">

                <button type="button" class="btn btn-info float-right" data-toggle="modal" data-target="#modal-lg">Assign Work</button>
              </div>
              <div class=" col-md-3 offset-md-9">
                <div class="form-group">
                  <label for="adate">Date</label>
                  <div class="input-group-prepend">
                    <span class="input-group-text">
                      <i class="far fa-calendar-alt"></i>
                    </span><input type="text" value="<?php echo isset($date) ? date('m-d-Y', strtotime($date)) : ''?>" name="adate" id="adate" class="form-control" >
                  </div>
                </div>
              </div>
         
              <div class="card-body">
         
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                         <th>#</th>
                         <th>Staff Member Name</th>
                         <th>Machine Model</th>
                         <th>Date</th>
                         <th>Shift</th>
                         <th>Cone Given (in kgs)</th>
                         <th>Shift Over</th>
                         <th>Machine Status</th>
                         <th>Manage</th>
                      </tr>
                    </thead>
                    <tbody>
                     <?php foreach($work as $key => $val): 

                          $staffattn = $this->name->getStaffAttendStatus($val->work_staff_id, $val->work_date);

                      ?>


                      <tr>
                        <td><?= ++$key?></td>
                        <td><?= $val->staff_name ?></td>
                        <td><?= $val->machine_model ?></td>
                        <td><?= date('d M Y',strtotime($val->work_date))?></td>
                        <td><?php echo ($val->work_shift == 1) ? 'Day' : 'Night';?></td>
                        <td><?= $val->work_cone_given?></td>
                        <td class="text-center"><?php if($staffattn){ if($val->work_meter == ''){ ?><a href="#" data-toggle="modal" data-target="#modalover-lg<?= $val->work_id?>"><i class="fa fa-plus"></i></a><?php }else{ ?><a href="#" data-toggle="modal" data-target="#modalover-lg<?= $val->work_id?>"><i class="fa fa-plus text-success"></i></a><?php } } else{?><span class="badge badge-danger">First Complete Attendance</span> <?php } ?></td>
                        <td class="text-center"><a href="#" data-toggle="modal" data-target="#modalstatus-lg<?= $val->work_id?>"><i class="fa fa-plus"></i></a></td>
                        <td class="text-center"><!-- <i class="fa fa-eye text-info" title="View"></i>&emsp;|&emsp; -->
                          <a href="#" data-toggle="modal" data-target="#modaledit-lg<?= $val->work_id?>"><i class="fa fa-edit text-success" title="Edit"></i></a></td>
                        </tr>

                        <!-- Edit Work Assign -->
                        <div class="modal fade" id="modaledit-lg<?= $val->work_id?>">
                          <div class="modal-dialog modaledit-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h4 class="modal-title">Edit Work Allocated</h4>
                                <div id="messageForm1"></div>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <!-- form start -->
                                <form action="" class="work_allocateup" method="post">
                                  <div class="card-body">
                                    <div id="msgwork1"></div>
                                    <div class="row">
                                      <div class="col-md-12">
                                       <div class="form-group">
                                        <input type="hidden" name="wid" value="<?= $val->work_id?>">
                                        <label for="wedate">Date</label>
                                        <div class="input-group-prepend">
                                          <span class="input-group-text">
                                            <i class="far fa-calendar-alt"></i>
                                          </span><input type="text" name="wedate" class="form-control dated"  value="<?= date('m/d/Y',strtotime($val->work_date))?>">
                                          <input type="hidden" name="edate" value="<?= $val->work_date?>">
                                        </div>

                                      </div>
                                    </div>

                                  </div>
                                  <div class="row">
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label for="staff">Staff Member</label>
                                        <select class="form-control" name="sname">
                                          <?php foreach($staff as $k => $v): ?>
                                            <option value="<?= $v->staff_id?>" <?php if($v->staff_id == $val->work_staff_id){ echo "selected";} ?>><?= $v->staff_name?></option>
                                          <?php endforeach; ?>
                                        </select>

                                      </div>
                                    </div>

                                    <div class="col-md-6">
                                     <div class="form-group">
                                      <label for="address">Select Machine</label>
                                      <!-- <?php //print_r($machine); ?> -->
                                      <select class="form-control" name="smachine">

                                        <?php foreach($machine as $key1 => $v): ?>
                                          <option value="<?= $v->bim_machine_id?>" <?php if($v->bim_machine_id == $val->work_machine_id){ echo "selected";} ?>><?= $v->machine_model?></option>
                                        <?php endforeach; ?>
                                      </select>
                                    </div>
                                  </div>
                                </div>
                                
                                <div class="row">
                                  <div class="col-md-6">
                                    <div class="form-group">
                                      <label for="shift">Select Shift</label>
                                      <select class="form-control" name="shift">
                                        <option value="1" <?php if($val->work_shift == 1){ echo "selected";} ?>>Day</option>
                                        <option value="2" <?php if($val->work_shift == 2){ echo "selected";} ?>>Night</option>
                                      </select>
                                    </div>
                                  </div>

                                  <div class="col-md-6">
                                    <div class="form-group">
                                      <label for="coneg">Cone Given<small>(in Kgs)</small></label>
                                      <input type="number" name="cone"  class="form-control coneg" step="any" value="<?= $val->work_cone_given?>">
                                    </div>
                                  </div>

                                </div>
                                <div class="row">


                                </div>



                              </div>


                              <!-- /.card-body -->

                              <div class="card-footer">
                                <button type="submit" class="btn btn-primary float-right">Submit</button>
                              </div>
                            </form>
                          </div>

                        </div>
                        <!-- /.modal-content -->
                      </div>
                      <!-- /.modal-dialog -->
                    </div>

                    <!-- After Shift is Over -->
                    <div class="modal fade" id="modalover-lg<?= $val->work_id?>">
                      <div class="modal-dialog modaledit-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Shift Over</h4>
                            <div class="msgworkafter"></div>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <!-- form start -->
                            <form action="" class="shift_over" method="post" data-work_id="<?= $val->work_id?>">
                              <div class="card-body">
                                <div class="row closest">
                                  <input type="hidden" name="wrkid" value="<?= $val->work_id ?>">
                                  <input type="hidden" name="bid" value="<?= $val->work_beam_id ?>">
                                  <input type="hidden" name="mchnid" value="<?= $val->work_machine_id ?>" class="machinesid">
                                  <input type="hidden" name="staff_id" value="<?php echo $val->work_staff_id; ?>">
                                  <div class="col-sm-6">
                                    <div class="form-group">
                                      <label for="meter<?= $val->work_id?>">Meter</label>
                                      <input type="number" id="meter<?= $val->work_id?>" name="meter" class="form-control meter" step="any" value="<?= $val->work_meter?>" max="<?= $val->bim_beam_length_left ?>" <?php if (!empty($val->work_meter)): ?>
                                        readonly=""
                                      <?php endif ?>>
                                      <input type="hidden" name="getmeter" class="mymeter" value="<?= $val->work_meter?>">
                                    </div>
                                  </div>
                                  <div class="col-sm-6">
                                   <label for="wastage<?= $val->work_id?>">Wastage <small>(in kgs)</small></label>
                                   <input type="number" name="wastage" id="wastage<?= $val->work_id?>" class="form-control wastage" step="any" value="<?= $val->work_wastage?>" <?php if (!empty($val->work_wastage)): ?>
                                   readonly=""
                                      <?php endif ?>>
                                   <input type="hidden" name="getwastage" value="<?= $val->work_wastage?>">
                                 </div>
                               </div>
                               <div class="row">
                                <div class="col-sm-6">
                                  <div class="form-group">
                                    <label for="noroll<?= $val->work_id?>">Number of Roll</label>
                                    <input type="number"  name="noroll" id="noroll<?= $val->work_id?>" class="form-control conew noofrolls" step="any" data-work_id="<?= $val->work_id?>" value="<?= $val->work_no_of_roll_weight ?>" <?php if (!empty($val->work_no_of_roll_weight)): ?>
                                        readonly=""
                                      <?php endif ?>>
                                    <input type="hidden" name="getcone" value="<?= $val->work_no_of_roll_weight ?>">
                                  </div>
                                </div>
                                <div class="col-sm-6">
                                 <label for="conweight<?= $val->work_id?>">Core Weight <small>(in kgs)</small></label>
                                 <input type="number" name="conweight" id="conweight<?= $val->work_id?>" class="form-control rweight" step="any" value="<?= $val->work_roll_weight?>" <?php if (!empty($val->work_roll_weight)): ?>
                                   readonly=""
                                 <?php endif ?>>
                                 <input type="hidden" name="rollweight" value="<?= $val->work_roll_weight?>">
                               </div>
                             </div>
                               <div class="row">
                                <div class="col-sm-6">
                                  <div class="form-group">
                                    <label for="conew<?= $val->work_id?>">Cone Weight (After use)</label>
                                    <input type="number"  name="conew" id="conew<?= $val->work_id?>" class="form-control conew" step="any" value="<?= $val->work_coneweight ?>" <?php if (!empty($val->work_coneweight)): ?>
                                        readonly=""
                                      <?php endif ?>>
                                    <input type="hidden" name="getcone" value="<?= $val->work_coneweight ?>">
                                  </div>
                                </div>
                                <div class="col-sm-6">
                                 <label for="rweight<?= $val->work_id?>">Roll Weight <small>(in kgs)</small></label>
                                 <input type="number" name="rweight" id="rweight<?= $val->work_id?>" class="form-control rweight" step="any" value="<?= $val->work_roll_weight?>" <?php if (!empty($val->work_roll_weight)): ?>
                                        readonly=""
                                      <?php endif ?>>
                                 <input type="hidden" name="rollweight" value="<?= $val->work_roll_weight?>">
                               </div>
                             </div>
                             <div class="details-roll<?= $val->work_id?>">

                              <?php 
                              $roll_data = $this->name->Get_roll_by_id($val->work_id,$val->work_beam_id,$val->work_machine_id,$val->work_staff_id); 
                              if (!empty($roll_data)) {
                                foreach ($roll_data as $key_roll => $value_roll) {
                              ?>
                                <div class="row">
                                  <div class="col-md-12">
                                    <label for="roll_name">Roll Name</label>
                                    <input type="text" class="form-control" name="roll_name<?= $val->work_id?>[]" value="<?php echo $value_roll->roll_name; ?>" id="roll_name" required="" <?php if (!empty($value_roll->roll_name)): ?>
                                        readonly=""
                                      <?php endif ?>>
                                  </div>
                                  <div class="col-md-6">
                                    <label for="roll_length">Roll length</label>
                                    <input type="number" class="form-control" name="roll_length<?= $val->work_id?>[]" value="<?php echo $value_roll->roll_length; ?>" id="roll_name" <?php if (!empty($value_roll->roll_length)): ?>
                                        readonly=""
                                      <?php endif ?>>
                                  </div>
                                  <div class="col-md-6">
                                    <label for="roll_weight">Roll weight</label>
                                    <input type="number" class="form-control" name="roll_weight<?= $val->work_id?>[]" value="<?php echo $value_roll->roll_weight; ?>" id="roll_name" <?php if (!empty($value_roll->roll_weight)): ?>
                                        readonly=""
                                      <?php endif ?>>
                                  </div>
                                </div>
                              <?php
                                }
                              }
                              ?>
                               


                             </div>
                           </div>


                           <!-- /.card-body -->

                           <div class="card-footer">
                            <?php if (empty($val->work_meter)): ?>
                                <button type="submit" class="btn btn-primary float-right">Submit</button>
                            <?php endif ?>
                            
                          </div>
                        </form>
                      </div>

                    </div>
                    <!-- /.modal-content -->
                  </div>
                  <!-- /.modal-dialog -->
                </div>

                <!-- Machine Status -->
                <div class="modal fade" id="modalstatus-lg<?= $val->work_id?>">
                  <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Machine Status</h4>
                        <div id="msg"></div>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <!-- form start -->
                        <form action="" class="machine_off" data-work_id="<?= $val->work_id?>" method="post">
                          <div class="card-body">
                            <div id="msgworkstatus"></div>
                            <div class="row">
                              <input type="hidden" name="machid" value="<?= $val->work_machine_id?>">
                              <input type="hidden" name="wrkid" value="<?= $val->work_id?>">
                              <input type="hidden" name="mshift" value="<?= $val->work_shift?>">
                              <div class="col-md-12">
                               <div class="form-group">
                                <label for="sdate">Date</label>
                                <div class="input-group-prepend">
                                  <span class="input-group-text">
                                    <i class="far fa-calendar-alt"></i>
                                  </span><input type="text" name="sdate" class="form-control">
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group">
                                <label for="staff">Stop Time</label>
                                <input type="text" name="stoptime" class="form-control stoptime">
                              </div>
                            </div>

                            <div class="col-md-6">
                             <div class="form-group">
                              <label for="address">Start Time</label>
                              <input type="text" name="strttime" class="form-control starttime">
                            </div>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="reason">Select Reason</label>
                              <select class="form-control reason" name="reason">
                                <option value="">---Select Reason---</option>
                                <option value="1">Maintenance</option>
                                <option value="2">Power Off</option>
                              </select>
                            </div>
                          </div>

                        </div>
                        <div style="display: none;" class="d-print-none part adddd<?= $val->work_id?>">

                          <div class="row">
                            <div class="col-12">
                              <button class="btn btn-primary float-md-right Add-m" data-work_id="<?= $val->work_id?>">Add more Parts</button>
                            </div>
                          </div>

                          <div class="addthis">
                            <div class="row">
                            <div class="col-md-12">
                              <div class="form-group">
                                <label for="reason">Part</label>
                                <input type="text" name="part2<?= $val->work_id?>[]" class="form-control">
                              </div>
                            </div>

                          </div>
                               <div class="row">
                              <div class="col-md-6">
                                <div class="form-group">
                                  <label for="staff">Qty</label>
                                  <input type="number" name="qty2<?= $val->work_id?>[]" class="form-control">
                                </div>
                              </div>

                              <div class="col-md-6">
                               <div class="form-group">
                                <label for="address">Total Amount</label>
                                <input type="text" name="amount2<?= $val->work_id?>[]" class="form-control">
                              </div>
                            </div>
                          </div>
                        </div>

      

                        </div>


                      </div>


                      <!-- /.card-body -->

                      <div class="card-footer">
                        <button type="submit" class="btn btn-primary float-right">Submit</button>
                      </div>
                    </form>
                  </div>

                </div>
                <!-- /.modal-content -->
              </div>
              <!-- /.modal-dialog -->
            </div>

          <?php endforeach; ?>
        </tbody>

      </table>
    </div>
  </div>
</div>
</div>
<!-- Insert Allocated Work -->
<div class="modal fade" id="modal-lg">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Allocate Work</h4>
        <div id="msg"></div>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- form start -->
        <form action="" id="work_allocate" method="post">
          <div class="card-body">
            <div id="msgwork"></div>
            <div class="row">
              <div class="col-md-12">
               <div class="form-group">
                <label for="wdate">Date</label>
                <div class="input-group-prepend">
                  <span class="input-group-text">
                    <i class="far fa-calendar-alt"></i>
                  </span><input type="text" name="wdate" id="wdate" class="form-control dated">
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="staff">Select Staff Member</label>
                <select class="form-control" name="staff">
                  <option value="">---Select Staff Member---</option>
                  <?php foreach($staff as $key => $v): ?>
                    <option value="<?= $v->staff_id?>"><?= $v->staff_name?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>

            <div class="col-md-6">
             <div class="form-group">
              <label for="address">Select Machine</label>
              <select class="form-control" name="machine" id="machine">
                <option value="">---Select Machine---</option>
                <?php foreach($machine as $key1 => $v): ?>
                  <option value="<?= $v->bim_machine_id?>"><?= $v->machine_model?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>
        <div id="beam" class="d-none">

        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="shift">Select Shift</label>
              <select class="form-control" name="shift" id="shift">
                <option value="">---Select Shift---</option>
                <option value="1">Day</option>
                <option value="2">Night</option>
              </select>
            </div>
          </div>

          <div class="col-md-6">
            <div class="form-group">
              <label for="cone">Cone Given<small> (in Kgs)</small></label>
              <input type="number" name="cone" id="cone" class="form-control" step="any">
            </div>
          </div>

        </div>


      </div>


      <!-- /.card-body -->

      <div class="card-footer">
        <button type="submit" class="btn btn-primary float-right">Submit</button>
      </div>
    </form>
  </div>

</div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->


</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php' ?>


<script type="text/javascript">
  window.onload = function() {

    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();

    today = yyyy + '/' + mm + '/' + dd;
    $.fn.getStaffList(today);
  };
</script>
<script>
  $(function() {

    $('.noofrolls').keyup(function(event) {
      event.preventDefault()
      var value = $(this).val().trim()
      var w_id = $(this).attr('data-work_id')
      $('.details-roll').html('')
      if (value > 0) {
        for (i = 0; i < value; i++) {
          $('.details-roll'+w_id+'').append(`<div class="row">
                                 <div class="col-md-12">
                                   <label for="roll_name">Roll Name</label>
                                   <input type="text" class="form-control" name="roll_name${w_id}[]" id="roll_name" required="">
                                 </div>
                                 <div class="col-md-6">
                                   <label for="roll_length">Roll length</label>
                                   <input type="number" class="form-control" name="roll_length${w_id}[]" id="roll_name">
                                 </div>
                                 <div class="col-md-6">
                                   <label for="roll_weight">Roll weight</label>
                                   <input type="number" class="form-control" name="roll_weight${w_id}[]" id="roll_name">
                                 </div>
                               </div>`)
        }
        Shift_oveR()
      }
    });

    $('.Add-m').click(function(event) {
      event.preventDefault()
      var w_id = $(this).attr('data-work_id')
      $('.adddd'+w_id+'').append(`<div class="addthis">
                              <div class="row">
                              <div class="col-md-12">
                                <div class="form-group">
                                  <label for="reason">Part</label>
                                  <input type="text" name="part2${w_id}[]" class="form-control">
                                </div>
                              </div>

                            </div>
                                 <div class="row">
                                <div class="col-md-6">
                                  <div class="form-group">
                                    <label for="staff">Qty</label>
                                    <input type="number" name="qty2${w_id}[]" class="form-control">
                                  </div>
                                </div>

                                <div class="col-md-6">
                                 <div class="form-group">
                                  <label for="address">Total Amount</label>
                                  <input type="text" name="amount2${w_id}[]" class="form-control">
                                </div>
                              </div>
                            </div>
                          </div>`)

    });

    

    $('.dated').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });

    $('input[name="adate"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });

    $('input[name="sdate"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });

    $('input[name="adate"]').change(function(e) {
      e.preventDefault()
      let date = $(this).val()

      window.location.replace($('meta[name=url]').attr("content") + 'admin/work-allocate?date=' + encodeURIComponent(date))
    })

    $('#machine').change(function(e) {
      e.preventDefault()
      let mac = $(this).val()
      $('.beamid').val('');
      $.ajax({

       type       : 'POST',
       url        : '<?php echo base_url() ?>admin/get-latest-beam-in-machine',
       dataType   : 'json',
       data       : {'mac' : mac},
       success    : function(result) {

         var select = `<input class='beamid' type="text" value="${result.bim_beam_id}" name="beamid">`;

         $('#beam').html(select);

       },error: function(jqXHR, exception) {

         console.log(jqXHR.responseText);
       }

     });

      
    })

    $('.reason').change(function(e) {
      e.preventDefault()
      let re = $(this).val();

      
      if(re === '1'){

        $('.part').show();
      
      }
      else{

        $('.part').hide();  
      }
      
      

      
    })

    $.fn.getStaffList = function(e){

      $.ajax({

       type       : 'POST',
       url        : '<?php echo base_url() ?>admin/get-Staff-for-Work',
       dataType   : 'json',
       data       : {'date' : e},
       success    : function(result) {
         var select = '';
         select += '<option value="">Select Staff Member</option>';
         $.each(result, function(result, val) {

           select += '<option value="'+val['staff_id']+'">'+val['staff_name']+'</option>';
         });

         $('#staff_mem').html(select);

       },error: function(jqXHR, exception) {

         console.log(jqXHR.responseText);
       }

     });
    }

  });
</script>

<script type="text/javascript">
  $(function() {
    $('#work_allocate').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/insert-work-allocated", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          $('#msgwork').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>

<script type="text/javascript">
  $(function() {
    $('.work_allocateup').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))



      ajax(url+"admin/edit-work-allocated", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          window.location.reload()
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>
  
<!-- <script type="text/javascript">
  
  $(function() {

      $('.meter').on('input', function () {

       let machine = '';

      num = $(this).serializeArray()

      let getmeter = $.map(num, function(val, i) {
        if (val.name === 'getmeter') {
          return val.value
        }
      })
    
    var value = $(this).val();
    
    if ((value !== '') && (value.indexOf('.') === -1)) {
        
        $(this).val(Math.max(Math.min(value, 90), -90));
    }
});

  })
  
</script> -->
<script type="text/javascript">
  $('.stoptime').timeselector({ min: '01:00', max: '24:00' });

  $('.starttime').timeselector({ min: '01:00', max: '24:00' });
</script>
<script type="text/javascript">
  $(function() {
    $('.machine_off').on('submit' , function (e) {
      e.preventDefault();

      var w_id = $(this).attr('data-work_id')
      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      var part = [];
      $('input[name="part2'+w_id+'[]"]').each( function(i, val) {
          data.append("part[" + i + "]", this.value)
      });

      var qty = [];
      $('input[name="qty2'+w_id+'[]"]').each( function(i, val) {
          data.append("qty[" + i + "]", this.value)
      });

      var amount = [];
      $('input[name="amount2'+w_id+'[]"]').each( function(i, val) {
          data.append("amount[" + i + "]", this.value)
      });

      // data.append("part", part)
      // data.append("qty", qty)
      // data.append("amount", amount)

      ajax(url+"admin/insert-machine-off-status", data).then(function(result) {

        console.log(result)

        if(result.result){
          window.location.reload()
        }
        else{
          $('#msgworkstatus').html('<div class="alert alert-danger">'+result.msg+'</div>');
        }
      window.location.reload()
      

    })

    })
  })

  function Shift_oveR(){
      $('.shift_over').on('submit' , function (e) {
        e.preventDefault();
        var w_id = $(this).attr('data-work_id')

        let num = '';

        num = $(this).serializeArray()

        let getmeter = $.map(num, function(val, i) {
          if (val.name === 'getmeter') {
            return val.value
          }
        })

        if(getmeter == ''){

          let url = $('meta[name=url]').attr("content");
          let data = new FormData($(this).get(0))


          var part = [];
          $('input[name="roll_name'+w_id+'[]"]').each( function(i, val) {
              data.append("roll_nam[" + i + "]", this.value)
          });

          var qty = [];
          $('input[name="roll_length'+w_id+'[]"]').each( function(i, val) {
              data.append("roll_lengt[" + i + "]", this.value)
          });

          var amount = [];
          $('input[name="roll_weight'+w_id+'[]"]').each( function(i, val) {
              data.append("roll_weigh[" + i + "]", this.value)
          });

          ajax(url+"admin/insert-work-assign-after-work", data).then(function(result) {
            console.log(result);
            if(result.result){
              window.location.reload()
            }
            else{
              console.log(result);
            }
        }).catch(function(e) {


          console.log(e)

        })
      }
      else{
          let url = $('meta[name=url]').attr("content");
          let data = new FormData($(this).get(0))


          var part = [];
          $('input[name="roll_name[]"]').each( function(i, val) {
              data.append("roll_nam[" + i + "]", this.value)
          });

          var qty = [];
          $('input[name="roll_length[]"]').each( function(i, val) {
              data.append("roll_lengt[" + i + "]", this.value)
          });

          var amount = [];
          $('input[name="roll_weight[]"]').each( function(i, val) {
              data.append("roll_weigh[" + i + "]", this.value)
          });

          ajax(url+"admin/update-work-assign-after-work", data).then(function(result) {

            console.log(result)

          //   if(result.result){
          //     window.location.reload()
          //   }
          //   else{
          //     $('.msgworkafter').html('<div class="alert alert-danger">'+result.msg+'</div>');
          // }


        }).catch(function(e) {


          console.log(e)

        })
      }



    })
  }

</script>
</body>
</html>
