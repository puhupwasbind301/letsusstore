<!DOCTYPE html>
<html>
<?php $title = "Beam Add";
$nav_page = 4;
include 'admin_assets/include/header.php';
?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
<style>
  .select2-container .select2-selection--single {
      height: 44px;
    }
  .select2-container--default .select2-selection--single .select2-selection__arrow {
      height: 40px;
    }
</style>
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Beam in <?= $mtitle->machine_title?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?= base_url()?>admin/machine">Machine</a></li>
              <li class="breadcrumb-item active">Beam Add</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <div class="card">
              <?php
               $length_left = $this->name->Check_beam_length_left_in_machine($machine_id); 
               if ($length_left == 0) {
              ?>
              <div class="card-header">
                <em class="text-warning">Click on the button to add beam.</em>
              <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-lg-beam">Add Beam</button>
              </div>
              <?php } ?>
              <div class="card-body">
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th>Sl no</th>
                        <th>Beam Name</th>
                        <th>Beam Weight (kg)</th>
                        <th>Beam Length (meter)</th>
                        <th>Beam Wastage (kg)</th>
                        <th>Beam Length <br> Left (meter)</th>
                        <th>Beam Added in <br> Machine Time</th>
                        <th>Beam Creation Time</th>
                      </tr>
                    </thead>
                    <tbody>

                      <?php foreach ($get_all_beams_by_machine_id as $key => $value): ?>
                        <tr>
                          <td><?php echo $key+1; ?></td>
                          <td><?php echo $value->beam_name; ?></td>
                          <td><?php echo $value->beam_weight; ?></td>
                          <td><?php echo $value->beam_length; ?></td>
                          <td><?php echo $value->beam_wastage; ?></td>
                          <td><?php echo $value->bim_beam_length_left; ?></td>
                          <td><?php echo date('h:i a, d-M-Y',strtotime($value->bim_time)); ?></td>
                          <td><?php echo date('h:i a, d-M-Y',strtotime($value->beam_time)); ?></td>
                        </tr>
                      <?php endforeach ?>
                      
                    </tbody>


                  </table>
                </div>
              </div>

            </div>
          </div>




        <div class="modal fade" id="modal-lg-beam">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h4 class="modal-title">Add Beam</h4>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form  id="add_beam_in_machine" method="post">
                  <div class="card-body">
                    <div id="messageForm"></div>

                    <div class="form-group">
                      <label for="select-beam">Select Beam</label>
                      <select name="select_beam" id="select-beam" class="form-control select2" style="width: 100% !important;">
                        <option selected="" style="display: none;"></option>
                        <?php foreach ($all_beam as $key => $value): ?>
                          <option value="<?php echo $value->beam_id; ?>"><?php echo $value->beam_name.' - ('.date('h:i a,  d-M-Y', strtotime($value->beam_time)).')'; ?></option>
                        <?php endforeach ?>
                      </select>
                    </div>
                    <input type="hidden" name="machine_id" value="<?php echo $machine_id; ?>">

                    <div class="append_here">
                      
                    </div>

                  </div>

                  <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
              </div>

            </div>
          </div>
        </div>




          
          <!-- <div class="modal fade" id="modal-lg">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">Add Beam</h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <form  id="ajaxform1" method="post">
                    <div class="card-body">
                      <div id="messageForm"></div>
                      <div class="row">
                        <div class="col-md-12">
                          <div class="form-group">
                            <label for="idate">Date</label>
                            <div class="input-group-prepend">
                              <span class="input-group-text">
                                <i class="far fa-calendar-alt"></i>
                              </span><input type="text" name="idate" id="idate" class="form-control" >
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <input type="hidden" name="mid" value="<?= $this->uri->segment(3)?>">
                            <label for="length">Length <small>(in Meters)</small></label>
                            <div class="input-group-prepend">
                              <input type="number" name="length" id="length" class="form-control" step="any">
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="weight">Weight <small>(in Kgs)</small></label>
                            <div class="input-group-prepend">
                              <input type="number" name="weight" id="weight" class="form-control" step="any">
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary float-right">Submit</button>
                    </div>
                  </form>
                </div>

              </div>
            </div>
          </div> -->



        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
  <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>">
  <script>
  $(function() {

    $('.select2').select2()

    $('.select2').change(function(event) {
      event.preventDefault()
      var beam_id = $(this).val()
      $.ajax({
        url: '<?php echo base_url();?>Admin/Get_beam_by_id_ajax/'+beam_id+'',
        type: 'GET',
        dataType: 'json',
      })
      .done(function(result) {
        $('.append_here').html(`<div class="row">
                      <div class="col-md-12">
                        <h4>Details of the Beam</h4>
                      </div>
                    </div>
                    
                    <div class="form-group">
                      <label for="name">Name</label>
                      <input type="text" id="name"  class="form-control" value="${result.beam_name}" readonly="">
                    </div>

                    <div class="form-group">
                      <label for="weight">Weight (kg)</label>
                      <input type="text" id="weight" name="weight"  class="form-control" value="${result.beam_weight}" readonly="">
                    </div>

                    <div class="form-group">
                      <label for="length">Length (meters)</label>
                      <input type="text" id="length" name="length" class="form-control" value="${result.beam_length}" readonly="">
                    </div>

                    

                    <div class="form-group">
                      <label for="time">Beam creation time</label>
                      <input type="text" id="time"  class="form-control" value="${result.beam_time}" readonly="">
                    </div>`)
      })
      .fail(function(jqXHR,exception) {
              console.log(jqXHR.responseText);
            })
      
    });


    $('#add_beam_in_machine').submit(function(event) {
      event.preventDefault()

      var data = $(this).serializeArray()

      $.ajax({
        url: '<?php echo base_url();?>Admin/Add_beam_in_machine2',
        type: 'POST',
        dataType: 'json',
        data: data,
      })
      .done(function(result) {
        console.log(result);
          $('#messageForm').html(`${result.msg}`)
          location.reload()
      })
      .fail(function(jqXHR,exception) {
        console.log(jqXHR.responseText);
      })
      
    });


    $('input[name="idate"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxYear: parseInt(moment().format('YYYY'),10)
    });
  });
</script>

<script type="text/javascript">
  $(function() {
    $('#ajaxform1').on('submit' , function (e) {
      e.preventDefault();


      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/insert-beam", data).then(function(result) {

        console.log(result);

        if(result.result){
          window.location.reload()
        }
        else{
          $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>
</body>
</html>
