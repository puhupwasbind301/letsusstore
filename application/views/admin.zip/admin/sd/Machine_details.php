<!DOCTYPE html>
<html>
<?php $title = "Machines Details";
$nav_page = 10009;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }

}
</style>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Machine Details</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Machine Details</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4><?php echo $this->name->get_machine_name_by_id($machine_id)->mac_name; ?></h4>
                <em>Created on: <?php echo date('d-m-Y, h:i a', strtotime($this->name->get_machine_name_by_id($machine_id)->mac_date)); ?></em>
              </div>
              <div class="card-body">
                <div class="row">
                  <?php if (!empty($this->name->get_last_inward_in_warping_by_id($machine_id))): ?>
                    <div class="col-md-6">
                      <h5>Details of last Inward materials used in this machine</h5>
                      <h6>Inward Type: <span class="font-weight-bold"><?php echo $this->name->get_last_inward_in_warping_by_id($machine_id)->inward_type; ?></span></h6>
                      <h6><?php echo $this->name->get_last_inward_in_warping_by_id($machine_id)->inward_type; ?> Type: <span class="font-weight-bold"><?php echo $this->name->get_last_inward_in_warping_by_id($machine_id)->inward_type_of_type; ?></span></h6>
                      <h6>Weight: <span class="font-weight-bold"><?php echo $this->name->get_last_inward_in_warping_by_id($machine_id)->weight; ?></span></h6>
                      <h6>Name: <span class="font-weight-bold"><?php echo $this->name->get_last_inward_in_warping_by_id($machine_id)->name; ?></span></h6>
                      <h6>Time: <span class="font-weight-bold"><?php echo date('d-m-Y, h:i a', strtotime($this->name->get_last_inward_in_warping_by_id($machine_id)->time)); ?></span></h6>
                    </div>
                  <?php endif ?>

                  <?php if (!empty($this->name->get_machine_present_weight_by_id($machine_id))): ?>
                    <div class="col-md-6">
                      <h5>Weight currently present in this machine: <span class="font-weight-bold"><?php echo $this->name->get_machine_present_weight_by_id($machine_id)->Present_weight.' KG'; ?></span></h5>
                    </div>
                  <?php endif ?>

                </div>

              </div>
            </div>
          </div>
        </div>


      </div>
    </div>

</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php'; ?>


</body>
</html>
