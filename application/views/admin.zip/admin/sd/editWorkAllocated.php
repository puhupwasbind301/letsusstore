<!DOCTYPE html>
<html>
<?php $title = "Work Allocate";
$nav_page = 5;
include 'admin_assets/include/header.php';
?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
<!-- jQuery -->
<style type="text/css">
  .select2-container--default .select2-selection--single .select2-selection__rendered {
      color: #444;
      line-height: 24px;
  }
  .select2-container .select2-selection--single {
      height: 38px;
  }
  .select2-container--default .select2-selection--single .select2-selection__arrow {
      height: 35px;
  }
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }
}
</style>

<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Work Allocate</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Work Allocate</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <form class="work-form">
                  <div class="row">
                     <div class="col-md-12 bal-taana" style="font-size: 36px;margin-bottom: 28px;"> </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <h5 for="">Select shift</h5>
                        <?php //print_r($allocated_work); ?>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" id="customRadio1" value="day" name="shift_type"  <?php if($allocated_work->allocated_work_shift_type === 'day'): ?>
                              checked=""
                            <?php endif ?>>
                            <label class="custom-control-label" for="customRadio1">Day Shift</label>
                          </div>
                          <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" id="customRadio2" value="night" name="shift_type"  <?php if ($allocated_work->allocated_work_shift_type === 'night'): ?>
                              checked=""
                            <?php endif ?>>
                            <label class="custom-control-label" for="customRadio2">Night Shift</label>
                          </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Select Operator</label>
                        <?php if (empty($staff_availability_list)){ ?>
                          <h5 class="text-danger">Todays attandence is not marked</h5>
                        <?php }else{ ?>
                        <select name="staff" id="staff" class="form-control" >
                          <option value="" style="display: none;"></option>
                          <?php foreach ($staff_availability_list as $key => $value): ?>
                          <option value="<?php echo $value->staff_id; ?>" <?php if ($allocated_work->allocated_work_staff === $value->staff_id) {
                            echo "selected=''";
                          } ?>><?php echo $value->staff_name; ?></option>
                          <?php endforeach ?>
                        </select>
                        <?php } ?>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Select Machines</label>
                        <?php if (empty($machines_which_r_free_today)){ ?>
                          <h5 class="text-danger">All machines are already assigned for Today</h5>
                        <?php }else{?>
                        <select name="Machines" id="Machines" class="form-control" >
                          <option value="" style="display: none;"></option>
                          <?php foreach ($machines_which_r_free_today as $key => $value) { ?>
                          <option value="<?php echo $value->machine_id; ?>" <?php if ($allocated_work->allocated_work_machines === $value->machine_id) {
                            echo "selected=''";
                          } ?>><?php echo $value->machine_title.' ('.$value->machine_model.') '; ?></option>
                          <?php } ?>
                        </select>
                        <?php } ?>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Select Date</label>
                        <input type="text" name="Date" value="<?= date('m/d/Y',strtotime($allocated_work->allocated_work_current_date)) ?>" class="form-control" required="">
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group beamClass">
                        <label for="">Select Beam</label>
                        <select name="Beam" id="Beam" class="form-control" >
                          <option value="" style="display: none;"></option>
                          
                        </select>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Meters Used</label>
                        <input type="number" class="form-control" name="meters_used" value="<?php echo $allocated_work->allocated_work_meters_used; ?>"  step="any">
                      </div>
                    </div>

                    <!-- <div class="col-md-6">
                      <div class="form-group">
                        <label for="type_of_raw_material">Select type of Raw material</label>
                        <select name="type_of_raw_material" id="type_of_raw_material" class="form-control" required="">
                          <option style="display: none;" value="">Select type</option>
                          <?php foreach ($res as $key => $value): ?>
                            <option value="<?php echo $value->inward_type; ?>"><?php echo $value->inward_type; ?></option>
                          <?php endforeach ?>
                        </select>
                      </div>
                    </div>


                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="raw_material_inward_type">Select Inward Type</label>
                        <select name="raw_material_inward_type" id="raw_material_inward_type" class="form-control" required="">
                          <option style="display: none;" value="">Select type</option>
                          <?php foreach ($res as $key => $value): ?>
                            <option value="<?php echo $value->inward_type_of_type; ?>"><?php echo $value->inward_type_of_type; ?></option>
                          <?php endforeach ?>
                        </select>
                      </div>
                    </div> -->


                    <!-- <div class="col-md-6">
                      <div class="form-group">
                        <label for="raw_material_name">Raw Material name</label>
                        <select name="raw_material_name[]" id="raw_material_name" class="form-control" required="">
                          <option style="display: none;" value="">Select Name</option>
                          <?php foreach ($res as $key => $value): ?>
                            <option value="<?php echo $value->name; ?>"><?php echo $value->name; ?></option>
                          <?php endforeach ?>
                        </select>
                      </div>
                    </div> -->

                    <!-- <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Raw Material Used</label>
                        <input type="number" class="form-control raw_material_weight" name="raw_material_weight" >
                        <input type="hidden" class="form-control raw_material_id" name="raw_material_id" readonly="">
                      </div>
                    </div> -->

                   <?php foreach ($manufacturing_work_allocate_inwards_used as $key => $mwaiu) { ?>
                   
                   <div class="col-md-6">
                      <div class="form-group">
                      
                        <input type="hidden" name="row_mt_uid[]" value="<?= $mwaiu->id ?>">
                        <label for="raw_material_name">Raw material name</label>
                        <select name="raw_material_name[]" id="<?= $mwaiu->id ?>" class="form-control raw_material_name" >
                          <option style="display: none;" value="">Select Name</option>      
                          <?php foreach ($inward as $key => $value): ?>
                            <option <?= ($mwaiu->inward_id == $value->inward_id )?'selected':'' ?> value="<?php echo $value->inward_id; ?>"><?php echo $value->inward_type.' - '. $value->inward_type_of_type; ?></option>
                          <?php endforeach ?>
                        </select>
                      </div>
                    </div>


                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Raw materials used(kg)</label>
                        <input type="text" name="inward_used[]" data_mwaiu_id="<?= $mwaiu->id ?>" class="form-control" value="<?php echo $mwaiu->inward_weight; ?>">
                      </div>
                    </div>

                  <?php } ?> 

                    <!-- <div class="col-md-12">
                      <div class="row append-raw-materials-here">
                      </div>
                    </div> -->

                  <!--   <div class="col-12" style="text-align: end">
                      <button class="btn btn-dark btn-sm add-raw-material-btn">Add more raw materials</button>
                    </div> -->


                 <!--    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Cone Given (kg)</label>
                        <input type="number" class="form-control" name="cone_given" value="<?php echo $allocated_work->allocated_work_cone_given; ?>" required="" step="any">
                      </div>
                    </div> -->

                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Wastage (kg)</label>
                        <input type="number" class="form-control" name="wastage"  step="any" value="<?php echo $allocated_work->allocated_work_wastage; ?>">
                      </div>
                    </div>

                    <div class="col-md-12">
                       <h4>Output</h4>

                        <div class="custom-control custom-checkbox d-inline">
                            <input type="checkbox" class="custom-control-input" id="finishedCheckbox" name="dctextile" value="finish" checked="checked">
                            <label class="custom-control-label" for="finishedCheckbox">Finished</label>
                        </div> 
                    </div>

                    
                      <div class="col-md-12" id="getfinishedrows">
                      <div class="row "> 
                       <!-- <div class="col-md-12">
                         <button class="btn btn-sm btn-primary mt-3 addfinishedrow" style="display: none;">Add more</button>
                       </div> -->
                        </div>

                          <?php foreach ($new_rolls_created_finished as $key => $nrcF) {  ?>
                            
                          <div class="row frow" style="border: 2px solid #E0E0E0;padding: 20px 10px 30px 10px;margin:2% 0%">
                                      <div class="col-md-6">
                                        <input type="hidden" name="row_Roll_F_uid[]" value="<?= $nrcF->new_roll_id ?>">
                                        <label for="">Roll type</label>
                                        <select name="roll_typeF[]"  data_nrcF_id="<?= $nrcF->new_roll_id ?>" class="form-control" >
                                          <option value="" style="display: none;"></option>
                                          <?php foreach ($all_rolls as $key => $value): ?>
                                            <option <?= ($nrcF->new_roll_type == $value->roll_types_id)?'selected':'' ?> value="<?php echo $value->roll_types_id; ?>"><?php echo $value->roll_types_name; ?></option>
                                          <?php endforeach ?>
                                        </select>
                                      </div>

                                      <div class="col-md-6 mt-3 mt-md-0">
                                        <label for="">Roll Length ( <sub>sq</sub><sup>2</sup><sub>m</sub> )</label>
                                        <input type="number" data_nrcF_id="<?= $nrcF->new_roll_id ?>" name="roll_lengthF[]"  class="form-control"  placeholder="Enter length" value="<?php echo $nrcF->new_roll_length; ?>" >
                                      </div>

                                      <div class="col-md-6 mt-3">
                                        <label for="">Roll weight (kg)</label>
                                        <input type="number" data_nrcF_id="<?= $nrcF->new_roll_id ?>" name="roll_weightF[]"  class="form-control"  step="any" placeholder="Enter roll weight" value="<?php echo $nrcF->new_roll_weight; ?>">
                                      </div>

                                       <div class="col-md-6 mt-3">
                                        <label for="">Roll Name</label>
                                        <input type="input" data_nrcF_id="<?= $nrcF->new_roll_id ?>" name="roll_nameF[]"  class="form-control"  step="any" placeholder="Enter roll name" value="<?php echo $nrcF->new_roll_name; ?>">
                                      </div>

                             </div>

                                   <?php } ?>     
                      
                    </div>



                    
                    <div class="col-md-12">
                      <div class="custom-control custom-checkbox d-inline">
                          <input type="checkbox" class="custom-control-input" id="unfinishedCheckbox" name="dctextile" value="unfinish" checked="checked" readonly="readonly" >
                          <label class="custom-control-label" for="unfinishedCheckbox">Unfinished</label>
                      </div>
                    </div>


                    <div class="col-md-12" id="getunfinishedrows">
                      <div class="row"> 
                     <!-- <div class="col-md-12">
                         <button class="btn btn-sm btn-primary mt-3 addunfinishedrow" style="display: none;">Add more</button>
                     </div> -->
                      </div>


                      <?php foreach ($new_rolls_created_unfinished as $key => $nrcU) { ?>
                          <div class="row funrow" style="border: 2px solid #E0E0E0;padding: 20px 10px 20px 10px;margin:2% 0%">
                                  <div class="col-md-6">
                                    <input type="hidden" name="row_Roll_U_uid[]" value="<?= $nrcU->new_roll_id ?>">
                                    <label for="">Roll type</label>
                                    <select name="roll_typeU[]" data_nrcu_id="<?= $nrcU->new_roll_id ?>" class="form-control" >
                                      <option value="" style="display: none;"></option>
                                      <?php foreach ($all_rolls as $key => $value): ?>
                                        <option  <?= ($nrcU->new_roll_type == $value->roll_types_id)?'selected':'' ?> value="<?php echo $value->roll_types_id; ?>"><?php echo $value->roll_types_name; ?></option>  
                                      <?php endforeach ?>
                                    </select>
                                  </div>

                                   <div class="col-md-6">
                                    <label for="">Roll Name</label>
                                    <input type="input" data_nrcu_id="<?= $nrcU->new_roll_id ?>" name="roll_nameU[]" class="form-control"  step="any" placeholder="Enter roll name" value="<?php echo $nrcU->new_roll_name; ?>">
                                  </div>
                              </div>
                      <?php } ?>    

                    </div>


                       
                          
                    
                  

                   <!--   <div class="col-md-12">
                      <div class="row" id="append-more-roll-weight">
                        <div class="col-md-6">
                          <label for="">Roll type</label>
                          <select name="roll_type" id="roll_type" class="form-control" required="">
                            <option value="" style="display: none;"></option>
                            <?php foreach ($all_rolls as $key => $value): ?>
                              <option value="<?php echo $value->roll_types_id; ?>"><?php echo $value->roll_types_name; ?></option>
                            <?php endforeach ?>
                          </select>
                        </div>

                        <div class="col-md-6">
                          <label for="">No of rolls Created</label>
                          <input type="number" name="no_of_rolls" id="no_of_rolls" class="form-control" required="">
                        </div>

                        <div class="col-md-6 mt-3">
                          <label for="">Roll weight</label> <button class="btn btn-warning btn-sm float-right add-more-rolls">Add More</button>
                          <input type="number" name="roll_weight[]" id="roll_weight" class="form-control" required="" step="any">
                        </div>

                      </div>
                    </div> -->

                    <div class="col-md-12 text-center" id="allocateMsg">
                    </div>

                    <div class="col-md-12 text-center my-5">
                      <button class="btn btn-success" type="submit"> Update </button>
                    </div>

                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </div>
<!-- /.content -->


</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php' ?>
</body>
</html>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>

<script>
  var machine_id = '<?php echo $allocated_work->allocated_work_machines ?>';
  $(function(){


    getBeams(machine_id)

    $('.addfinishedrow').click(function(event) {
      event.preventDefault();
      getCode()
    });

    $('.addunfinishedrow').click(function(event) {
      event.preventDefault();
      getUnFinishedCode()
    });

    $('#finishedCheckbox').on('change', function() {
        if($(this).prop('checked') === true){
            getCode()
         }else{
            $('.frow').remove()
            $('.addfinishedrow').hide();
         }
    });

    $('#unfinishedCheckbox').on('change', function() {
        if($(this).prop('checked') === true){
            // getUnFinishedCode()()
            getUnFinishedCode()
         }else{
            $('.funrow').remove()
            $('.addunfinishedrow').hide();
         }
    });


    $('#type_of_raw_material, #raw_material_inward_type, .raw_material_name').change(function(event) {
      event.preventDefault();
      // var type_of_raw_material = $('#type_of_raw_material').find(":selected").val();
      // var raw_material_inward_type = $('#raw_material_inward_type').find(":selected").val();
      var raw_material_name = $('.raw_material_name').find(":selected").val();
      // var m_id_and_inward_id = raw_material_name.split('|');  
      
      if (raw_material_name.trim() === '') {
        // alert('Please enter raw materials details!');
        return false;
      }else{
        // raw_material_weight
        $.ajax({
          url: '<?php echo base_url();?>Admin/get_weight_raw_material',
          type: 'POST',
          dataType: 'json',
          data: {param3: raw_material_name},
        })
        .done(function(result) {
          console.log('result');
          console.log(result);
          // $('.raw_material_weight').val(result.weight)
          // $('.raw_material_id').val(result.raw_mat_id)
        })
        .fail(function(jqXHR,exception) {
          console.log(jqXHR.responseText);
        })
      }
    });



    $('.add-raw-material-btn').click(function(event) {
      event.preventDefault()
      $('.append-raw-materials-here').append(`<div class="col-md-6">
                      <div class="form-group">
                        <label for="raw_material_name">Select Raw Material name</label>
                        <select name="raw_material_name[]" id="raw_material_name" class="form-control" required="">
                          <option style="display: none;" value="">Select Name</option>      
                          <?php foreach ($inward as $key => $value): ?>
                            <option value="<?php echo $value->inward_id; ?>"><?php echo $value->inward_type.' - '. $value->inward_type_of_type; ?></option>
                          <?php endforeach ?>
                        </select>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Weight used(kg)</label>
                        <input type="text" name="inward_used[]" class="form-control">
                      </div>
                    </div>`)
    });


    $('input[name="Date"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });


    $('#staff').select2({
        placeholder: "Select Operator",
    });

    $('#Machines').select2({
        placeholder: "Select Machine",
    });

    $('#Beam').select2({
        placeholder: "Select Beam",
    });

    $('#roll_type').select2({
        placeholder: "Select Roll type",
    });

    $('.add-more-rolls').click(function(event){
      event.preventDefault()
      $('#append-more-roll-weight').append(
        `<div class="col-md-6 mt-3">
            <label for="">Roll weight</label>
            <input type="number" name="roll_weight[]" id="roll_weight" class="form-control" required step="any">
        </div>`)
    });






// data += {name: "allocated_id", value: allocated_id};
      // Object.assign(data, {name: "edit_allocated_id", value: allocated_id});
    $('.work-form').submit(function(event) {
      // alert('hii');
      // return false;
      event.preventDefault()
      var allocated_id = window.location.href.substring(location.href.lastIndexOf('/') + 1);
      var data = $(this).serializeArray();

      data.push({name: "edit_allocated_id", value: allocated_id });
      console.log(data);
      
     

      $.ajax({
        url: '<?php echo base_url();?>Admin/updateNewAllocatedWork',
        type: 'POST',
        dataType: 'json',
        data: data,
      })
      .done(function(result) {
        console.log('result.msg');
        console.log(result.msg);
        if (result.status === 'success') {
          $('#allocateMsg').html('<div class="alert alert-success  mt-3">'+result.msg+'</div>');
        }else{
          $('#allocateMsg').html('<div class="alert alert-danger  mt-3">'+result.msg+'</div>');
        }
        
        setTimeout(()=>{
          window.location.reload()
        },2500)
      })
      .fail(function(jqXHR,exception) {
        console.log(jqXHR.responseText);
      })
    });




    // $('.work-form').submit(function(event) {
    //   event.preventDefault()
    //   var data = $(this).serializeArray();
    //   console.log(data)
    //   $.ajax({
    //     url: '<?php echo base_url();?>Admin/beam-report-data',
    //     type: 'POST',
    //     dataType: 'json',
    //     data: data,
    //   })
    //   .done(function(result) {
    //     console.log(result);
    //     // if (result.status === 'success') {
    //     //   $('#allocateMsg').html('<div class="alert alert-success  mt-3">'+result.msg+'</div>');
    //     // }else{
    //     //   $('#allocateMsg').html('<div class="alert alert-danger  mt-3">'+result.msg+'</div>');
    //     // }
    //     // setTimeout(()=>{
    //     //   window.location.reload()
    //     // },2500)
    //   })
    //   .fail(function(jqXHR,exception) {
    //     console.log(jqXHR.responseText);
    //   })
    // });


    $('#Machines').on('select2:selecting', function(e) {
        var value = e.params.args.data.id;

        getBeams(value)
      });



  })

function getBeams(value) {

  $.ajax({
    url: '<?php echo base_url();?>Admin/CheckWeatherBeamAlreadyPresentInMachines',
    type: 'POST',
    dataType: 'json',
    data: {param1: value},
  })
  .done(function(result) {
    
    // if( result.beams_which_r_not_used == null || result.beams_which_r_not_used.length == 0 ){
    if( result.beams_which_r_not_used == null  ){
       $('#Beam').parent().parent().css('visibility', 'hidden');
      } else {
       $('#Beam').parent().parent().show();     
      }
    // console.log(result);
    // console.log(typeof result)
    
    $('#Beam').html('<option value="" style="display: none;"></option>')
    $('.bal-taana').html('')
    
    if (result.status === 'NoBeamInMachine') {
      $.map(result.beams_which_r_not_used, function(elem, index) {
        $('#Beam').append(`<option value="${elem.beamC_id}">{ ${elem.beamC_weight} kg ) ${elem.beamC_name} - ${moment(elem.beamC_time).format('Do MMMM YYYY, h:mm:ss a')}</option>`)
      })

    }else if (result.status === 'BeamInMachineExhausted') {
      $.map(result.beams_which_r_not_used, function(elem, index) {
        $('#Beam').append(`<option value="${elem.beamC_id}">{ ${elem.beamC_weight} kg ) ${elem.beamC_name} - ${moment(elem.beamC_time).format('Do MMMM YYYY, h:mm:ss a')}</option>`)
      })
    }else{
      $('#Beam').append(`<option value="${result.beam_id}" selected="" readonly="">{ ${result.beam_details.beamC_weight} kg ) ${result.beam_details.beamC_name} - ${moment(result.beam_details.beamC_time).format('Do MMMM YYYY, h:mm:ss a')}</option>`)
      $('.bal-taana').html(`<div class="badge badge-warning">Balance Taana: <span style="color:green">${result.BeamLeft} meters</span></div>`)

    }
  })
  .fail(function(jqXHR,exception) {
    
    
    
    console.log(jqXHR.responseText);
  })
}

function getCode() {
  $('#getfinishedrows').append(`<div class="row frow" style="border: 2px solid #E0E0E0;padding: 20px 10px 30px 10px;margin:2% 0%">
                        <div class="col-md-6">
                          <label for="">Roll type</label>
                          <select name="roll_typeF[]" class="form-control" required="">
                            <option value="" style="display: none;"></option>
                            <?php foreach ($all_rolls as $key => $value): ?>
                              <option value="<?php echo $value->roll_types_id; ?>"><?php echo $value->roll_types_name; ?></option>
                            <?php endforeach ?>
                          </select>
                        </div>

                        <div class="col-md-6 mt-3 mt-md-0">
                          <label for="">Roll Length ( <sub>sq</sub><sup>2</sup><sub>m</sub> )</label>
                          <input type="number" name="roll_lengthF[]" class="form-control" required="" placeholder="Enter length" required>
                        </div>

                        <div class="col-md-6 mt-3">
                          <label for="">Roll weight (kg)</label>
                          <input type="number" name="roll_weightF[]" class="form-control" required="" step="any" placeholder="Enter roll weight" required>
                        </div>

                         <div class="col-md-6 mt-3">
                          <label for="">Roll Name</label>
                          <input type="input" name="roll_nameF[]" class="form-control" required="" step="any" placeholder="Enter roll name" required>
                        </div>

                      </div>`)
  $('.addfinishedrow').show();
}


function getUnFinishedCode() {
  $('#getunfinishedrows').append(`<div class="row funrow" style="border: 2px solid #E0E0E0;padding: 20px 10px 20px 10px;margin:2% 0%">
                        <div class="col-md-6">
                          <label for="">Roll type</label>
                          <select name="roll_typeU[]" class="form-control" required="">
                            <option value="" style="display: none;"></option>
                            <?php foreach ($all_rolls as $key => $value): ?>
                              <option value="<?php echo $value->roll_types_id; ?>"><?php echo $value->roll_types_name; ?></option>  
                            <?php endforeach ?>
                          </select>
                        </div>

                       

                         <div class="col-md-6">
                          <label for="">Roll Name</label>
                          <input type="input" name="roll_nameU[]" class="form-control" required="" step="any" placeholder="Enter roll name" required>
                        </div>
                      </div>`)

                      // <div class="col-md-4 my-3 my-md-0">
                      //   <label for="">Roll weight</label>
                      //   <input type="number" name="roll_weightU[]" class="form-control" required="" step="any" placeholder="Enter roll weight" required>
                      // </div>

  $('.addunfinishedrow').show();
}
</script>
