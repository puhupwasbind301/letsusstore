<!DOCTYPE html>
<html>
<?php $title = "Cut Stock";
$nav_page = 9995;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }

}
</style>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Cut Stock</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Cut Stock</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          
          <div class="col-md-12">

            <div class="card">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-12 mb-3">
                    <?php echo $this->session->flashdata('val_error'); ?>
                  </div>
                </div>
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Roll Name</th>
                        <th>Roll Weight (in Kgs)</th>
                        <th>Roll Length (in meter)</th>
                        <th>Cutting</th>
                        <th>Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach($cutroll as $ke => $ro): ?>
                      <tr>
                        <td><?= ++$ke ?></td>
                        <td><?= $ro->cutting_roll_name ?></td>
                        <td><?= $ro->cutting_roll_weight ?></td>
                        <td><?= $ro->cutting_roll_length ?></td>
                        <td class="text-center"><a href="<?= base_url('admin/stock-cut/'.$ro->cutting_id)?>"><i class="fa fa-eye text-success"></i></a></td>
                        <td><?= date('d-m-Y',strtotime($ro->cutting_created)) ?></td>
                      </tr>
                      <?php endforeach; ?>
                    </tbody>

            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Add Staff -->

</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->

</div>



<?php include 'admin_assets/include/footer.php'; ?>
<script>
  $(function() {
    // $('.csubmit').click(function(event) {
    //   event.preventDefault()
    //   if ($('#weight').val().trim() === '') {
    //     alert('Weight cannot be empty')
    //     return false;
    //   }else if($('#name').val().trim() === ''){
    //     alert('Name cannot be empty')
    //     return false;
    //   }else{
    //     $('#cweight').val($('#weight').val())
    //     $('#cname').val($('#name').val())
    //     $('#Confirm_raw').modal('show')
    //   }
    // });

    // $('.confirms').click(function(event) {
    //   $('#add_raw_form').submit()
    // });

    $('input[name="dop"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxYear: parseInt(moment().format('YYYY'),10)
    });
  });
</script>


</body>
</html>
