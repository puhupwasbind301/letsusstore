<!DOCTYPE html>
<html>
<?php $title = "All customer";
$nav_page = 9993;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }

}
</style>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>My customers</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">My customers</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          
          <div class="col-md-12">

            <div class="card">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-12 mb-3">
                    <button class="btn btn-success" data-toggle="modal" data-target="#addCustomers">Add customer</button>
                  </div>
                  <div class="col-md-12 mb-3">
                    <?php echo $this->session->flashdata('val_error'); ?>
                  </div>
                </div>
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th>Sl no.</th>
                        <th>Name</th>
                        <th>Location</th>
                        <th>Phone No.</th>
                        <th>Email</th>
                        <th>Description</th>
                        <th>Manage</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($Get_all_customers as $key => $value): ?>
                        <tr>
                          <td><?php echo $key+1; ?></td>
                          <td><?php echo $value->customer_name; ?></td>
                          <td><?php echo $value->customer_location; ?></td>
                          <td><?php echo $value->customer_number; ?></td>
                          <td><?php echo $value->customer_email; ?></td>
                          <td><?php echo $value->customer_description; ?></td>
                          <td class="text-center">
                            <button class="btn btn-warning mb-3" data-toggle="modal" data-target="#edit-customer"><i class="fa fa-edit"></i></button>
                            <a href="<?php echo base_url();?>Admin/Delete_customers/<?php echo $value->customer_id; ?>" class="btn btn-danger mb-3" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></a>
                          </td>
                        </tr>
                        
                        <!-- Modal -->
                        <div id="edit-customer" class="modal fade" role="dialog">
                          <div class="modal-dialog">
                        
                            <!-- Modal content-->
                            <div class="modal-content">
                              <div class="modal-header">
                                <h4 class="modal-title">Edit Customer</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <form action="<?php echo base_url();?>Admin/Edit_customers" method="POST">
                                <input type="hidden" name="customer_id" value="<?php echo $value->customer_id; ?>">
                                <div class="modal-body">
                                  <div class="form-group">
                                    <label for="company_name">Company Name <em class="text-danger" title="required">*</em></label>
                                    <input type="text" class="form-control" value="<?php echo $value->customer_name; ?>" name="company_name" id="company_name" placeholder="Company Name" required="" readonly="">
                                  </div>
                                  <div class="form-group">
                                    <label for="company_location">Company Location</label>
                                    <input type="text" class="form-control" value="<?php echo $value->customer_location; ?>" name="company_location" id="company_location" placeholder="Company Location">
                                  </div>
                                  <div class="row">
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label for="company_number">Contact Number</label>
                                        <input type="number" class="form-control" value="<?php echo $value->customer_number; ?>" name="company_number" id="company_number" placeholder="Company Number" readonly="">
                                      </div>
                                    </div>
                                    <div class="col-md-6">
                                      <div class="form-group">
                                        <label for="email_id">Email Id</label>
                                        <input type="email" class="form-control" value="<?php echo $value->customer_email; ?>" name="email_id" id="email_id" placeholder="Email Id" readonly="">
                                      </div>
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    <label for="description">Description</label>
                                    <textarea class="form-control" id="description" name="description" placeholder="Description" cols="30" rows="4"><?php echo $value->customer_description; ?></textarea>
                                  </div>
                                </div>
                                <div class="modal-footer" style="justify-content: flex-start;">
                                  <button type="submit" class="btn btn-success">Submit</button>
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                              </form>
                            </div>
                        
                          </div>
                        </div>
                      <?php endforeach ?>
                    </tbody>

            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Add Staff -->

</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->

</div>

<!-- Modal -->
<div id="addCustomers" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add Customer</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <form action="<?php echo base_url();?>Admin/Add_customers" method="POST">
        <div class="modal-body">
          <div class="form-group">
            <label for="company_name">Company Name <em class="text-danger" title="required">*</em></label>
            <input type="text" class="form-control" name="company_name" id="company_name" placeholder="Company Name" required="">
          </div>
          <div class="form-group">
            <label for="company_location">Company Location</label>
            <input type="text" class="form-control" name="company_location" id="company_location" placeholder="Company Location">
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="company_number">Contact Number</label>
                <input type="number" class="form-control" name="company_number" id="company_number" placeholder="Company Number" >
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="email_id">Email Id</label>
                <input type="email" class="form-control" name="email_id" id="email_id" placeholder="Email Id">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="description">Description</label>
            <textarea class="form-control" id="description" name="description" placeholder="Description" cols="30" rows="4"></textarea>
          </div>
        </div>
        <div class="modal-footer" style="justify-content: flex-start;">
          <button type="submit" class="btn btn-success">Submit</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>

  </div>
</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php'; ?>
<script>
  $(function() {
    // $('.csubmit').click(function(event) {
    //   event.preventDefault()
    //   if ($('#weight').val().trim() === '') {
    //     alert('Weight cannot be empty')
    //     return false;
    //   }else if($('#name').val().trim() === ''){
    //     alert('Name cannot be empty')
    //     return false;
    //   }else{
    //     $('#cweight').val($('#weight').val())
    //     $('#cname').val($('#name').val())
    //     $('#Confirm_raw').modal('show')
    //   }
    // });

    // $('.confirms').click(function(event) {
    //   $('#add_raw_form').submit()
    // });

    $('input[name="dop"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxYear: parseInt(moment().format('YYYY'),10)
    });
  });
</script>


</body>
</html>
