<!DOCTYPE html>
<html>
<?php $title = "Cutting Add Machine";
  $nav_page = 50;
  include 'admin_assets/include/header.php';
 ?>

<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php include 'admin_assets/include/navbar.php'; ?>
  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Cutting Add  Machine</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Cutting Add Machine</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item">Inward</li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">

                  <form class="px-xl-5" action="<?php echo base_url(); ?>admin/cutting-add-machine" method="POST">
                    <div class="row px-xl-5">
                      <div class="col-12">
                        <div class="row">
                          <div class="col-md-12">
                            <div class="row">
                              <div class="col-md-12">
                                <div class="form-group">
                                  <label for="">Name</label>
                                <input type="text" name="cutting_machine_name" id="machi" class="form-control" placeholder="Enter machine name">
                                  <!-- <em><?php echo form_error('raw_material_type'); ?></em> -->
                                </div>
                              </div>
                              <div class="col-md-12">
                                <div class="form-group">
                                  <label for="">Description</label>
                                   <textarea class="form-control"  name="cutting_machine_description" rows="3" placeholder="Cutting Machine Description."></textarea>
                                </div>
                              </div>
                              <!-- <div class="row" id="append-here">
                                
                              </div> -->
                            </div>
                          </div>
                          
                          <div class="col-md-12">
                            <button class="btn btn-outline-success" type="submit" name="submit">Submit</button>
                          </div>
                          <div class="col-md-12">
                             <?php echo $this->session->flashdata('val_error'); ?>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
</body>
</html>
<!-- <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script> -->


<!-- <script>

  $(function(){


      

    $('.date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });



    $('#raw_material_type').unbind().change(function(event) {
      event.preventDefault()
      let value = $(this).val()
      if (value === 'Yarn') {
        $('#append-here').html(`<div class="col-md-6">
                            <div class="form-group">
                              <label for="">Yarn type</label>
                              <input type="text" name="raw_custom_type" class="form-control" id="raw_custom_type" required="">
                            </div>
                          </div>
                            <div class="col-md-6">
                            <div class="form-group">
                              <label for="">No of cartons</label>
                              <input type="number" min="1" name="no_of_cartons" class="form-control" required="">
                            </div>
                          </div>
                          
            this section is comment
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="">Average weight per cartons (KG)</label>
                              <input type="number" min="1" name="avg_weight_of_cartons" class="form-control" required="">
                            </div>
                          </div>
            this section ends is comment
                          
                          
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="">Total Weight (KG)</label>
                              <input type="number" min="1" name="weight" class="form-control" required="">
                            </div>
                          </div>`)
      }else if(value === 'Roing') {
        $('#append-here').html(`<div class="col-md-6">
                            <div class="form-group">
                              <label for="">Roing type</label>
                              <input type="text" name="raw_custom_type" class="form-control" id="raw_custom_type" required="">
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="">Total Weight (KG)</label>
                              <input type="number" min="1" name="weight" class="form-control" required="">
                            </div>
                          </div>`)

      }else if(value === 'Chemicals') {
        $('#append-here').html(`<div class="col-md-6">
                            <div class="form-group">
                              <label for="">Chemicals type</label>
                              <input type="text" name="raw_custom_type" class="form-control" id="raw_custom_type" required="">
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="">Total Weight (KG)</label>
                              <input type="number" name="weight" min="1" class="form-control" required="">
                            </div>
                          </div>`)
      }
    });
  })
</script>

 -->