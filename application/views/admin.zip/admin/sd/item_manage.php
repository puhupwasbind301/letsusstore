<!DOCTYPE html>
<html>
<?php $title = "Item Manage";
  $nav_page = 7;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
 <?php include 'admin_assets/include/navbar.php'; ?>

  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Item Manage</h1>
          </div>
          <div class="col-sm-6">
           <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Inventory</a></li>
              <li class="breadcrumb-item "><a href="<?= base_url()?>admin/create-vendor">Vendor</a></li>
              <li class="breadcrumb-item"><a href="<?= base_url()?>admin/purchaseOrder/<?= $prorder->vpo_vendor_id?>">Purchase Order</a></li>
              <li class="breadcrumb-item active">Item Manage</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            
            <div class="card">
              <div class="card-header">
                <h4>Item for Vendor (<?= $prorder->vendor_name?>)</h4>
                <button type="button" class="btn btn-info float-right" data-toggle="modal" data-target="#modal-lg"><i class="fa fa-plus"></i></button>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>Category</th>
                        <th>Item</th>
                        <th>Quantity</th>
                        <th>Re-order Level</th>
                        <th>Manage</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach($data as $key => $val): ?>
                      <tr>
                        <td><?= ++$key?></td>
                        <td><?= $val->inventory_category?></td>
                        <td><?= $val->item_inventory?></td>
                        <td><?= $val->item_quantity?></td>
                        <td><?= $val->item_re_order?></td>
                        <td class="text-center"><a href="#" data-toggle="modal" data-target="#modalview-lg<?= $val->item_id?>"><i class="fa fa-eye text-info"></i></a>&emsp;|&emsp;<a href="#" data-toggle="modal" data-target="#modaledit-lg<?= $val->item_id?>"><i class="fa fa-edit text-success"></i></a>&emsp;|&emsp;<a href="#" data-toggle="modal" data-target="#modal-sm<?= $val->item_id?>"><i class="fa fa-trash text-danger"></i></a></td>
                      </tr>

                      <!-- View Item -->
                  <div class="modal fade" id="modalview-lg<?= $val->item_id?>">
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">View Item</h4>

                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="row">
                            <div class="col-md-4">
                              <label><b>Item Type</b></label><br>
                              <?php if($val->item_type == 1){

                                echo "Consumable";
                              }
                              else{

                                echo "Non-consumable";
                              } ?>
                            </div>

                            <div class="col-md-4">
                              <label><b>Inventory Category</b></label><br>
                              <?php foreach($icat as $key => $v):
                                  if($v->inventory_cat_id == $val->item_inv_cat){

                                    echo $v->inventory_category;
                                  }
                              endforeach; ?>
                            </div>

                            <div class="col-md-4">
                              <label><b>Inventory Item</b></label><br>
                              <?= $val->item_inventory; ?>
                            </div>
                          </div>
                          <br>
                          <div class="row">
                            <div class="col-md-4">
                              <label><b>Quantity</b></label><br>
                              <?= $val->item_quantity; ?>
                            </div>

                            <div class="col-md-4">
                              <label><b>Re-order Level</b></label><br>
                              <?= $val->item_re_order?>
                            </div>

                            <div class="col-md-4">
                              <label><b>Free</b></label><br>
                              <?= $val->item_free; ?>
                            </div>
                          </div>

                          <br>
                          <div class="row">
                            <div class="col-md-4">
                              <label><b>Discount</b></label><br>
                              <?= $val->item_discount; ?>
                            </div>

                            <div class="col-md-4">
                              <label><b>MRP</b></label><br>
                              <?= $val->item_mrp?>
                            </div>

                            <div class="col-md-4">
                              <label><b>Rate</b></label><br>
                              <?= $val->item_rate; ?>
                            </div>
                          </div>

                        </div>

                        </div>
                        <!-- /.modal-content -->
                      </div>
                      <!-- /.modal-dialog -->
                      </div>

                      <!-- Edit Item -->
    <div class="modal fade" id="modaledit-lg<?= $val->item_id?>">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Edit Item</h4>

            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <!-- form start -->
            <form  id="ajaxform2" method="post">
              <div class="card-body">
                <div id="messageForm1"></div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="eitype">Item Type</label>
                      <select name="itype" class="form-control" id="eitype">
                        <option value="1" <?php if($val->item_type == 1){ echo "selected";} ?>>Consumable</option>
                        <option value="2" <?php if($val->item_type == 2){ echo "selected";} ?>>Non Consumable</option>
                      </select>
                    </div>
                  </div>
                
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="eicategory">Inventory Category</label>
                      <select name="icateg" class="form-control" id="eicategory">
                        <?php foreach($icat as $key => $vl): ?>
                        <option value="<?= $v->inventory_cat_id?>" <?php if($val->item_inv_cat == $vl->inventory_cat_id){ echo "selected";}?>><?= $vl->inventory_category?></option>
                        <?php endforeach;?>   
                      </select>

                    </div>
                  </div>
                
                </div>

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="einvtitem">Inventory Item</label>
                      <input type="text" class="form-control" name="invitem" placeholder="Inventory Item" id="einvtitem" value="<?= $val->item_inventory?>">

                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <?php  ?>
                      <label for="equantity">Quantity</label>
                       <input type="hidden" name="poid" value="<?= $prorder->vpo_id?>">
                       <input type="hidden" name="vendid" value="<?= $prorder->vpo_vendor_id?>">
                       <input type="hidden" name="itemid" value="<?= $val->item_id?>">
                      <input type="number" class="form-control" name="quantity" placeholder="Quantity" id="equantity" value="<?= $val->item_quantity?>">
                    </div>
                  </div>
                
                </div>
                <input type="hidden" name="poid" value="<?= $prorder->vpo_id?>">
                <input type="hidden" name="vendid" value="<?= $prorder->vpo_vendor_id?>">
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="ereorder">Re-order Level</label>
                      <input type="number" class="form-control" name="reorder" placeholder="Re-order Level" id="ereorder" value="<?= $val->item_re_order?>">

                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="efree">Free</label>
                      <input type="number" class="form-control" name="free" placeholder="Free" id="efree" value="<?= $val->item_free?>">
                    </div>
                  </div>
                
                </div>

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="ediscount">Discount</label>
                      <input type="number" class="form-control" name="discount" placeholder="Discount" id="ediscount" value="<?= $val->item_discount?>">

                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="emrp">MRP</label>
                      <input type="number" class="form-control" name="mrp" placeholder="MRP" id="emrp" value="<?= $val->item_mrp?>" step="any">
                    </div>
                  </div>
                
                </div>

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="erate">Rate</label>
                      <input type="number" class="form-control" name="rate" placeholder="Rate" id="erate" value="<?= $val->item_rate?>" step="any">

                    </div>
                  </div>
                
                </div>
        </div>

        <!-- /.card-body -->

        <div class="card-footer">
          <button type="submit" class="btn btn-primary float-right">Submit</button>
        </div>
      </form>
    </div>

  </div>
  <!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>

<!-- Delete Purchase Order -->
                  <div class="modal fade" id="modal-sm<?= $val->item_id?>">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">Delete Item</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <form action="<?= base_url()?>admin/delete-item" method="post"> 
                          <div class="modal-body">
                            <input type="hidden" name="itemidd" value="<?= $val->item_id?>">
                            <p>Are you sure, you want to delete this?</p>
                          </div>
                          <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Yes</button>
                          </div>
                        </form>
                      </div>
                      <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                  </div>
                  <!-- /.modal -->
                    <?php endforeach; ?>
                    </tbody>
                   
                   

            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Add Item -->
    <div class="modal fade" id="modal-lg">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Add Item</h4>

            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <!-- form start -->
            <form  id="ajaxform1" method="post">
              <div class="card-body">
                <div id="messageForm"></div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="itype">Item Type</label>
                      <select name="itype" class="form-control" id="itype">
                        <option value="">---Select Item Type---</option>
                        <option value="1">Consumable</option>
                        <option value="2">Non Consumable</option>
                      </select>
                    </div>
                  </div>
                
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="icategory">Inventory Category</label>
                      <select name="icateg" class="form-control" id="icategory">
                        <option value="">---Select Inventory Category---</option>
                        <?php foreach($icat as $key => $v): ?>
                        <option value="<?= $v->inventory_cat_id?>"><?= $v->inventory_category?></option>
                        <?php endforeach;?>   
                      </select>

                    </div>
                  </div>
                
                </div>

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="invtitem">Inventory Item</label>
                      <input type="text" class="form-control" name="invitem" placeholder="Inventory Item" id="invtitem">

                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="quantity">Quantity</label>
                      <input type="number" class="form-control" name="quantity" placeholder="Quantity" id="quantity">
                    </div>
                  </div>
                
                </div>
                <input type="hidden" name="poid" value="<?= $prorder->vpo_id?>">
                <input type="hidden" name="vendid" value="<?= $prorder->vpo_vendor_id?>">
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="reorder">Re-order Level</label>
                      <input type="number" class="form-control" name="reorder" placeholder="Re-order Level" id="reorder">

                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="free">Free</label>
                      <input type="number" class="form-control" name="free" placeholder="Free" id="free">
                    </div>
                  </div>
                
                </div>

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="discount">Discount</label>
                      <input type="number" class="form-control" name="discount" placeholder="Discount" id="discount">

                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="mrp">MRP</label>
                      <input type="number" class="form-control" name="mrp" placeholder="MRP" id="mrp" step="any">
                    </div>
                  </div>
                
                </div>

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="rate">Rate</label>
                      <input type="number" class="form-control" name="rate" placeholder="Rate" id="rate" step="any">

                    </div>
                  </div>
                
                </div>
        </div>

        <!-- /.card-body -->

        <div class="card-footer">
          <button type="submit" class="btn btn-primary float-right">Submit</button>
        </div>
      </form>
    </div>

  </div>
  <!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>

  <script type="text/javascript">
  $(function() {
    $('#ajaxform1').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/insert-item", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>

 <script type="text/javascript">
  $(function() {
    $('#ajaxform2').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0));

      ajax(url+"admin/update-item", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          window.location.reload()
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>
</body>
</html>
