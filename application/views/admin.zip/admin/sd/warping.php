<!DOCTYPE html>
<html>
<?php $title = "Warping";
$nav_page = 9991;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }

}
</style>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="offset-md-2 col-md-8 text-center">
            <div class="card mx-auto">
              <!-- <div class="card-body" style="-webkit-box-shadow: 0px 0px 0px 5px #A0A0A0, inset 0px 10px 27px -8px #141414, inset 0px -10px 27px -8px #A31925, 5px 5px 15px 5px rgba(0,0,0,0);
    box-shadow: 0px 0px 0px 5px #a0a0a038, inset 0px 10px 27px -8px #1414141f, inset 0px -10px 27px -8px #a319254a, 5px 5px 15px 5px rgba(0,0,0,0);}">
                <span style="font-size: 24px;font-style: oblique;">Raw Materials left</span><span style="font-size: 25px;font-style: oblique;color: green;font-variant: 600"> : <?php echo $this->name->get_raw_materiats_left(); ?> kg</span> 
              </div> -->
            </div>
          </div>
        </div>
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Warping</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Warping</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-4">
            <form id="add_raw_form" action="<?php echo base_url();?>Admin/Insert_raw_materials" method="POST">
              <div class="card">
                <div class="card-header">
                  <h4 class="modal-title">Add Raw Materials </h4>
                </div>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-12 text-center">
                      <em class="text-danger"><?php echo $this->session->flashdata('msg'); ?></em>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="select_machines">Select Machines</label>
                    <select name="select_machines" id="select_machines" class="form-control" required="">
                      <option value="" style="display: none;">Select Machines</option>
                      <?php foreach ($machine_details as $key => $value): ?>

                      <option value="<?php echo $value->mac_id; ?>"><?php echo $value->mac_name; ?></option>

                      <?php endforeach ?>
                    </select>
                    <em class="text-danger"><?php echo form_error('raw_material_type'); ?></em>
                  </div>
                  <div class="form-group">
                    <label for="weight">Select type of Raw material</label>
                    <select name="raw_material_type" id="raw_material_type" class="form-control" required="">
                      <option selected="" style="display: none;">Select Raw Material Type</option>
                      <option value="Yarn">Yarn</option>
                      <option value="Roing">Roving</option>
                      <option value="Chemicals">Chemicals</option>
                      <option value="Chemicals">Gas Cylinder</option>
                    </select>
                    <em class="text-danger"><?php echo form_error('raw_material_type'); ?></em>
                  </div>
                  <div class="form-group">
                    <label for="">Select Date</label>
                    <input type="text" class="form-control date" name="date">
                  </div>
                  <div class="form-group" id="append2type">
                    
                  </div>
                  <div id="append3type">
                    
                  </div>
                </div>
                <div class="card-footer">
                  <button class="btn btn-outline-success csubmit" type="submit">Submit</button>
                </div>
              </div>
            </form>
          </div>
          <div class="col-md-8">

            <div class="card">
              <div class="card-body">
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th>Sl no.</th>
                        <th>Machine Name</th>
                        <th>Weight</th>
                        <th>Name</th>
                        <th>Time</th>
                        <!-- <th>Manage</th> -->
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($res as $key => $value): ?>
                        <tr>
                          <td><?php echo $key+1; ?></td>
                          <td><?php echo $this->name->get_machine_name_by_id($value->machine_id)->mac_name; ?></td>
                          <td><?php echo $value->weight; ?></td>
                          <td><?php echo $value->name; ?></td>
                          <td><?php echo date('h:i a, d-M-Y', strtotime($value->time)); ?></td>
                        </tr>
                      <?php endforeach ?>
                    </tbody>

            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Add Staff -->

</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->


<div id="Confirm_raw" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Confirm Raw Materials</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <form action="<?php echo base_url();?>Admin/Insert_raw_materials" method="POST">
        <div class="modal-body">
          <div class="form-group">
            <label for="weight">Weight (kg)</label>
            <input type="text" name="weight" id="cweight" class="form-control" readonly="">
          </div>
          <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" id="cname" class="form-control" readonly="">
          </div>
        </div>
        <input type="hidden" id="mftype" name="mftype">
        <input type="hidden" id="mstype" name="mstype">
        <div class="modal-footer">
          <button class="btn btn-outline-success confirms" type="button">Submit</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Reset</button>
        </div>
      </form>
    </div>

  </div>
</div>

</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>


<script>
  $(function(){

    $('.date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });
  })
  function twoselect(){
    $('#raw_custom_type').unbind().change(function(event) {
      event.preventDefault();
      let secondtype = $(this).val();
      let firsttype = $('#raw_material_type').val();
      $('#append3type').html('')
      $.ajax({
        url: '<?php echo base_url();?>Admin/getRawMaterialDetailsByItSTwoTypes',
        type: 'POST',
        dataType: 'json',
        data: {firsttype: firsttype, secondtype: secondtype},
      })
      .done((result) => {
        if (!result) {
          $('#append3type').html(`<h4 class="text-danger">No raw materials has been set yet.</h4>`)
        }else{
          $('#append3type').html(`<div class="form-group">
              <h4 class="text-success">Total weight left: ${result.inward_weight}</h4>
            </div>
            <div class="form-group">
                      <label for="weight">Weight (kg)</label>
                      <input type="number" name="weight" min="1" max="${result.inward_weight}" id="weight" data-firstType="${firsttype}" data-secondType="${secondtype}" class="form-control" required="">
                      <em class="text-danger"><?php echo form_error('weight'); ?></em>
                    </div>
                    <div class="form-group">
                      <label for="name">Name</label>
                      <input type="text" name="name" id="name" class="form-control">
                      <em class="text-danger"><?php echo form_error('name'); ?></em>
                    </div>`)
        }
      })
      .fail(function(jqXHR,exception) {
        console.log(jqXHR.responseText);
      })
    });
  }
  $(function() {
    $('#raw_material_type').unbind().change(function(event) {
      event.preventDefault();
      $('#append2type').html('')
      $('#append3type').html('')
      var value = $(this).val()
      $.ajax({
        url: '<?php echo base_url();?>Admin/Get_Inward_second_type',
        type: 'POST',
        dataType: 'json',
        data: {param1: value},
      })
      .done((result)=>{
        // console.log(result);
        if (result !== false) {
          var data = '';
          $.map(result, function(elem,index) {
            data += `<option value="${elem.inward_type_of_type}">${elem.inward_type_of_type}</option>`
          })
          // console.log(data);
          $('#append2type').html(`<label for="">${value} type</label>
                      <select name="raw_custom_type" class="form-control" id="raw_custom_type" required="">
                        <option selected style="display:none;"></option>
                        ${data}
                      </select>`)
          twoselect()
        }else{
          $('#append2type').html(`<h4 class="text-center">No inward data found for ${value} type</h4>`)
        }
      })
      .fail(function(jqXHR,exception) {
              console.log(jqXHR.responseText);
            })
    });

    

    $('.csubmit').click(function(event) {
      event.preventDefault()
      if ($('#weight').val().trim() === '') {
        alert('Weight cannot be empty')
        return false;
      }else if($('#name').val().trim() === ''){
        alert('Name cannot be empty')
        return false;
      }else{
        var max_set = $('#weight').attr('max')
        if (parseFloat($('#weight').val()) > parseFloat(max_set)) {
          alert('Raw materials left:'+ max_set)
          alert($('#weight').val())
          return false;
        }else{
          var firsttype = $('#weight').attr('data-firsttype')
          var secondType = $('#weight').attr('data-secondType')
          $('#mftype').val(firsttype)
          $('#mstype').val(secondType)
          $('#cweight').val($('#weight').val())
          $('#cname').val($('#name').val())
          $('#Confirm_raw').modal('show')
        }
        // $('#cweight').attr('max', )
        
      }
    });

    $('.confirms').click(function(event) {
      $('#add_raw_form').submit()
    });

    $('input[name="dop"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxYear: parseInt(moment().format('YYYY'),10)
    });
  });
</script>


</body>
</html>
