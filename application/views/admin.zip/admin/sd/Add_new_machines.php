<!DOCTYPE html>
<html>
<?php $title = "Add Machines";
$nav_page = 10009;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }

}
</style>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Machines</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Add Machines</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4>Add Machines</h4>
              </div>
              <div class="card-body">
                <form action="<?php echo base_url();?>Admin/Add_new_machines" method="POST">
                  <div class="form-group">
                    <label for="">Machine Name</label>
                    <input type="text" name="machine_name" class="form-control">
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <button type="submit" class="btn btn-success btn-sm">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>


        <div class="row">
          <!-- <?php print_r($machine_details) ?> -->
          <?php if (empty($machine_details)){ ?>
            <div class="col-md-12 text-center">
              <div class="alert alert-danger">
                <h4>No machines added!</h4>
              </div>
            </div>
          <?php }else{ ?>
          <div class="col-md-12">
              <h4>Existing Machines</h4>
              <div class="row">
                  <?php foreach ($machine_details as $key => $value) {?>
                  <div class="col-md-3">
                    <div class="card">
                      <div class="card-header text-center">
                        <h4><?php echo $value->mac_name; ?></h4>
                      </div>
                      <div class="card-body">
                        <?php if (empty($this->name->get_machine_present_weight_by_id($value->mac_id)->Present_weight)){ ?>
                          <h6 class="text-danger text-center">Inward material not assigned to this machine yet.</h6>
                        <?php }else{ ?>
                        <h6 class="text-center">Weight Present: <?php echo $this->name->get_machine_present_weight_by_id($value->mac_id)->Present_weight.' KG'; ?></h6>
                        <?php } ?>
                      </div>
                      <div class="card-footer">
                        <div class="row">
                          <div class="col-md-12 text-center">
                            <a href="<?php echo base_url();?>admin/machine-details/<?php echo $value->mac_id; ?>" target="_blank" class="btn btn-secondary btn-sm">View</a>
                            <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#edit-machine--<?php echo $key; ?>">Edit</button>
                            <a href="<?php echo base_url();?>Admin/Delete_new_machines/<?php echo $value->mac_id; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this item?');">Delete</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  
                  <div id="edit-machine--<?php echo $key; ?>" class="modal fade" role="dialog">
                    <div class="modal-dialog">
                  
                      <!-- Modal content-->
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">Edit Machines</h4>
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <form action="<?php echo base_url();?>Admin/Edit_new_machine" method="POST">
                          <div class="modal-body">
                            <div class="row">
                              <div class="col-md-12">
                                <div class="form-group">
                                  <label for="">Machine Name</label>
                                  <input type="text" class="form-control" name="machine_name" value="<?php echo $value->mac_name; ?>">
                                  <input type="hidden" name="mid" value="<?php echo $value->mac_id; ?>">
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="modal-footer">
                            <button class="btn btn-success" type="submit">Submit</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                          </div>
                        </form>
                      </div>
                  
                    </div>
                  </div>
                <?php } ?>
              </div>
          </div>
        <?php } ?>
        </div>


      </div>
    </div>

</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php'; ?>


</body>
</html>
