<!DOCTYPE html>
<html>
<?php $title = "Add Stock";
$nav_page = 10003;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }

}
</style>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Stock</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Add Stock</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          
          <div class="col-md-12">

            <div class="card">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-12 mb-3">
                    <?php echo $this->session->flashdata('val_error'); ?>
                  </div>
                </div>
                <div class="row">
                  <div class="container">
                    <div class="col-md-12">
                      <h4>Add other stock</h4>
                      <div >
                        <form class="row" action="<?php echo base_url();?>Admin/Add_other_stock_fn" method="POST">
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="name">Name</label>
                              <input type="text" class="form-control" name="name" placeholder="Name" required="">
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="qty">Add Quatity</label>
                              <input type="number" class="form-control" name="qty" placeholder="Add Quatity" required="">
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="weight">Weight (kg)</label>
                              <input type="text" class="form-control" name="weight" placeholder="Weight (Kg)">
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="length">Length (meters)</label>
                              <input type="text" class="form-control" name="length" placeholder="Length (meters)">
                            </div>
                          </div>
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="description">Description</label>
                              <textarea cols="30" rows="5" class="form-control" name="description" placeholder="Description"></textarea>
                            </div>
                          </div>
                          <div class="col-md-12 text-center">
                            <button class="btn btn-success" type="submit">Submit</button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
        </div>
      </div>
    </div>
    <!-- Add Staff -->

</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->

</div>


<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php'; ?>
<script>
  $(function() {
    // $('.csubmit').click(function(event) {
    //   event.preventDefault()
    //   if ($('#weight').val().trim() === '') {
    //     alert('Weight cannot be empty')
    //     return false;
    //   }else if($('#name').val().trim() === ''){
    //     alert('Name cannot be empty')
    //     return false;
    //   }else{
    //     $('#cweight').val($('#weight').val())
    //     $('#cname').val($('#name').val())
    //     $('#Confirm_raw').modal('show')
    //   }
    // });

    // $('.confirms').click(function(event) {
    //   $('#add_raw_form').submit()
    // });

    $('input[name="dop"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxYear: parseInt(moment().format('YYYY'),10)
    });
  });
</script>


</body>
</html>
