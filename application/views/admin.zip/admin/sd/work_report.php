<!DOCTYPE html>
<html>
<?php $title = "Work Report";
  $nav_page = 6666;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php include 'admin_assets/include/navbar.php'; ?>
  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Work Report</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Work Report</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item">Work Report</li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                  <form class="findworkreport" action="" method="GET">
                    <div class="row">
                    <div class="col-md-3">
                      <div class="form-group">
                        <label for="">Select Staffs</label>
                        <select class="form-control" name="staff_id" id="staff_id">
                          <option value="all">All staffs</option>
                          <?php foreach ($allStaff as $key => $value): ?>
                            <option value="<?= $value->staff_id; ?>">
                              <?= $value->staff_name; ?>
                            </option>
                          <?php endforeach ?>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-8">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label>Start Date</label>
                            <input type="text" class="form-control date" id="start_date" name="start_date">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label>End Date</label>
                            <input type="text" class="form-control date" id="end_date" name="end_date">
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-1">
                      <button type="submit" class="btn btn-warning btn-sm btn-block" style="margin-top: 2rem" name="findCheck" value="sdgvjg"> Find </button>
                    </div>
                    </div>
                  </form>
                <div class="col-md-12">

<!-- 
         <div class="form-group">
          <label for="sel1">Show Per Page</label>
          <select class="form-control" id="selPage" width="10%" style="width:8%;" selected>
            <option value="10">10</option>
            <option value="25">25</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </select>
        </div>
 -->
            
            <?php 

            // echo '<pre>';
            // print_r($workReportAll);
            // exit();
             ?>


                  <div class="table-responsive">
                    <table class="work-report table table-hover table-striped table-bordered" id="na_datatable">
                      <thead>
                        <tr>
                          <th>Sl no</th>
                          <th>Machine</th>
                          <th>Staff</th>
                          <th>Beam</th>
                          <th>Date</th>
                          <th width="13%">Manage</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php 
                        // if($start == 1)
                        // $i=1; 

                        ?>
                      <?php if(count($workReportAll) > 0): ?>
                        <?php foreach ($workReportAll as $key => $value): ?>
                          <tr>
                            <!-- <td><?php echo $key+1; ?></td> -->
                            <td><?php echo $sno++ ?></td>
                            <td><a href="<?php echo base_url();?>admin/machine" target="_blank"><?php echo $this->name->getMachineByMachineId($value->allocated_work_machines)->machine_model; ?></a></td>
                            <td><a href="<?php echo base_url();?>admin/staff" target="_blank"><?php echo $this->name->get_staff_by_id($value->allocated_work_staff)->staff_name; ?></a></td>
                            <td>
                              
                              <a href="<?php echo base_url();?>admin/beam-created" target="_blank">
                                ( <?= ($value->allocated_work_beam!=0)?$this->name->beamDetailsByBeamId($value->allocated_work_beam)->beamC_weight.' Kg':'' ?>  ) <?= ($value->allocated_work_beam!=0)?$this->name->beamDetailsByBeamId($value->allocated_work_beam)->beamC_name:'' ?>  - <?php echo date('d/m/Y, h:i a', strtotime(($value->allocated_work_beam!=0)?$this->name->beamDetailsByBeamId($value->allocated_work_beam)->beamC_time:'')); ?>
                              </a>

                            </td>
                            <td><?php echo date('d/m/Y, h:i a', strtotime($value->allocated_work_current_date)); ?></td>
                            <?php 
                                  $staff_id      = $this->uri->segment(3);
                                  $start_date    = $this->uri->segment(4);
                                  $end_date      = $this->uri->segment(5);
                                  $page          = $this->uri->segment(6);
                             ?>
                            <td class="text-center">
                              <button class="btn btn-warning btn-sm view" data-macid="<?php echo $value->allocated_work_machines; ?>" data-id="<?php echo $value->allocated_work_id ?>"> <i class="fa fa-eye"></i> </button>
                               <a href="<?php echo base_url();?>admin/edit-work/<?php echo $value->allocated_work_id ?>" class="btn btn-info btn-sm"> <i class="fa fa-edit"></i> </a> 
                              <a href="<?php echo base_url();?>Admin/DeleteAllocatedWork/<?php echo $value->allocated_work_id; ?>/<?php echo $value->allocated_work_beam; ?>/<?php echo $staff_id.'/'.$start_date.'/'.$end_date.'/'.$page; ?>" class="btn btn-danger btn-sm"> <i class="fa fa-trash"></i> </a> 
                            </td>
                          </tr>


                          <div id="ViewWorkDetails--<?php echo $value->allocated_work_id; ?>" class="modal fade" role="dialog">
                            <div class="modal-dialog modal-lg">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h4 class="modal-title">Work Details</h4>
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <div class="modal-body">
                                  <div class="row">
                                    <div class="col-md-3">
                                      <h6 class="font-weight-bold">Shift Time: </h6>
                                    </div>
                                    <div class="col-md-9">
                                      <h6>
                                        <?php if ($value->allocated_work_shift_type === 'day'): ?>
                                        <span class="badge badge-warning"> Day </span></h6>
                                        <?php endif ?>
                                        <?php if ($value->allocated_work_shift_type === 'night'): ?>
                                        <span class="badge badge-dark"> Night </span></h6>
                                        <?php endif ?>
                                    </div>
                                  </div>
                                  <div class="row">
                                    <div class="col-md-3">
                                      <h6 class="font-weight-bold">Operator: </h6>
                                    </div>
                                    <div class="col-md-9">
                                      <h6>
                                        <a href="<?php echo base_url();?>admin/staff" target="_blank"><?php echo $this->name->get_staff_by_id($value->allocated_work_staff)->staff_name; ?></a>
                                      </h6>
                                    </div>
                                  </div>
                                  <div class="row">
                                    <div class="col-md-3">
                                      <h6 class="font-weight-bold">Machine: </h6>
                                    </div>
                                    <div class="col-md-9">
                                      <h6>
                                        <a href="<?php echo base_url();?>admin/machine" target="_blank"><?php echo $this->name->getMachineByMachineId($value->allocated_work_machines)->machine_model; ?></a>
                                      </h6>
                                    </div>
                                  </div>
                                  <div class="row">
                                    <div class="col-md-3">
                                      <h6 class="font-weight-bold">Beam: </h6>
                                    </div>
                                    <div class="col-md-9">
                                      <h6>
                                        <a href="<?php echo base_url();?>admin/beam-created" target="_blank">
                                          ( <?php echo $this->name->beamDetailsByBeamId($value->allocated_work_beam)->beamC_weight; ?>  Kg ) <?php echo $this->name->beamDetailsByBeamId($value->allocated_work_beam)->beamC_name; ?> - <?php echo date('d/m/Y, h:i a', strtotime($this->name->beamDetailsByBeamId($value->allocated_work_beam)->beamC_time)); ?>
                                        </a>
                                      </h6>
                                    </div>
                                  </div>
                                  <div class="row">
                                    <div class="col-md-3">
                                      <h6 class="font-weight-bold">Meters used: </h6>
                                    </div>
                                    <div class="col-md-9">
                                      <h6><?php echo $value->allocated_work_meters_used; ?> m</h6>
                                    </div>
                                  </div>
                                  <div class="row">
                                    <div class="col-md-3">
                                      <h6 class="font-weight-bold">Balance Taana: </h6>
                                    </div>
                                    <div class="col-md-9">
                                      <h6 class="bal-taana--<?php echo $value->allocated_work_id; ?>"></h6>
                                    </div>
                                  </div>
                                  <div class="row">
                                    <div class="col-md-3">
                                      <h6 class="font-weight-bold">Raw materials used: </h6>
                                    </div>
                                    <div class="col-md-9">
                                      <h6><?php echo $this->name->getRawMaterialsUsedinWaork($value->allocated_work_id); ?> kg</h6>
                                    </div>
                                  </div>
                                  <div class="row">
                                    <div class="col-md-3">
                                      <h6 class="font-weight-bold">Wastage: </h6>
                                    </div>
                                    <div class="col-md-9">
                                      <h6><?php echo $value->allocated_work_wastage; ?> kg</h6>
                                    </div>
                                  </div>
                                  <hr>
                                  <h5>Output</h5>

                                  <div class="row">
                                    <?php foreach ($this->name->getAllRollsFromWorkId($value->allocated_work_id) as $keys => $values): ?>
                                      <div class="col-md-12">
                                        <div class="card">
                                          <div class="card-header" style="background: beige;">
                                            <h6 class="font-weight-bold">
                                              <?php echo $values->new_roll_typef; ?> &emsp; ( Date : <?php echo date('d M, Y  h:i a', strtotime($values->new_roll_created_date)); ?>)
                                            </h6>
                                          </div>
                                          <div class="card-body">
                                            <div class="row">
                                              <div class="col-md-6">
                                                <div class="row">
                                                  <div class="col-md-5">
                                                    <h6 class="font-weight-bold">Roll Name</h6>
                                                  </div>
                                                  <div class="col-md-7">
                                                    <?php echo $values->new_roll_name; ?>
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="col-md-6">
                                                <div class="row">
                                                  <div class="col-md-5">
                                                    <h6 class="font-weight-bold">Roll Type</h6>
                                                  </div>
                                                  <div class="col-md-7">
                                                    <?php echo $this->name->getRollTypeDetalisbyRollId($values->new_roll_type)->roll_types_name; ?>
                                                  </div>
                                                </div>
                                              </div>
                                              <?php if (!empty($values->new_roll_length)): ?>
                                                <div class="col-md-6">
                                                  <div class="row">
                                                    <div class="col-md-5">
                                                      <h6 class="font-weight-bold">Roll Length (<sub>sq</sub><sup>2</sup><sub>m</sub>)</h6>
                                                    </div>
                                                    <div class="col-md-7">
                                                      <?php echo $values->new_roll_length; ?>
                                                    </div>
                                                  </div>
                                                </div>
                                              <?php endif ?>
                                              <div class="col-md-6">
                                                <div class="row">
                                                  <div class="col-md-5">
                                                    <h6 class="font-weight-bold">Roll Weight (kg)</h6>
                                                  </div>
                                                  <div class="col-md-7">
                                                    <?php echo $values->new_roll_weight; ?>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    <?php endforeach ?>
                                  </div>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        <?php endforeach ?>
                      <?php else: ?>
                        <tr>
                          <td class="text-center" colspan="10">No Data Found.</td>    
                        </tr>

                     <?php endif; ?> 


                      </tbody>
                    </table>

                    <!-- <ul class="pagination">
                      <?php $link = str_split($links); ?>
                      <?php foreach ($link as $key => $value):?>
                       <li><?php echo $value; ?></li>
                     <?php endforeach; ?>
                    </ul> -->

                  </div>

                </div>
                
                   
                
              </div><!-- /.card-body -->

            </div>
            <!-- /.nav-tabs-custom -->

          </div>
          <!-- /.col-md-6 -->

        </div>
        
      <?php if(count($workReportAll) > 0): ?>
          <?php echo $pagination; ?>
      <?php endif; ?>

       
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
</body>
</html>

<script>


  $('#selPage').click(function(){
      // $selwork = $(this).val();

      //     $.ajax({
      //       url: '<?php echo base_url();?>Admin/CheckWeatherBeamAlreadyPresentInMachines',
      //       type: 'POST',
      //       dataType: 'json',
      //       data: {param1: machine},
      //     })

  });


  var table = $('na_datatable').DataTable( {
    "processing": true,
    "serverSide": true,
    "ajax": "<?=base_url('admin/datatable_json')?>",
    "order": [[4,'desc']],
    "columnDefs": [

    { "targets": 0, "name": "allocated_work_id", 'searchable':true, 'orderable':true},
    { "targets": 1, "name": "allocated_work_shift_type", 'searchable':true, 'orderable':true},
    { "targets": 2, "name": "allocated_work_staff", 'searchable':true, 'orderable':true},
    { "targets": 3, "name": "allocated_work_machines", 'searchable':true, 'orderable':true},
    { "targets": 4, "name": "allocated_work_beam", 'searchable':false, 'orderable':false},
    { "targets": 5, "name": "allocated_work_meters_used", 'searchable':true, 'orderable':true},
   
    ]
  });





  $(function() {

    $('.date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });

    $('.findworkreport').submit(function(event) {
      event.preventDefault()
      var staff_id = $('#staff_id').find(":selected").val();
      var start_date = $('#start_date').val();
      start_date = start_date.replace("/", "-");
      start_date = start_date.replace("/", "-");
      var end_date = $('#end_date').val();
      end_date = end_date.replace("/", "-");
      end_date = end_date.replace("/", "-");
      window.location.href = '<?= base_url();?>Admin/work_report/'+staff_id+'/'+start_date+'/'+end_date+'/1';
    });

    // $('.work-report').DataTable();

    $('.view').unbind().click(function(event) {
      event.preventDefault()
      var value = $(this).attr('data-id')
      var machine = $(this).attr('data-macid');
      // alert(value);
      BalanceTaana(value,machine);

    });

  });

  function BalanceTaana(value,machine) {
    $.ajax({
      url: '<?php echo base_url();?>Admin/CheckWeatherBeamAlreadyPresentInMachines',
      type: 'POST',
      dataType: 'json',
      data: {param1: machine},
    })
    .done((result) => {
      console.log(result);
      // $('#Beam').html('<option value="" style="display: none;"></option>')
      $('.bal-taana--'+value+'').html('')
      if (result.status === 'NoBeamInMachine') {
        // $.map(result.beams_which_r_not_used, function(elem, index) {
        //   $('#Beam').append(`<option value="${elem.beamC_id}">{ ${elem.beamC_weight} kg ) ${elem.beamC_name} - ${moment(elem.beamC_time).format('Do MMMM YYYY, h:mm:ss a')}</option>`)
        // })
      } else if (result.status === 'BeamInMachineExhausted') {
        // $.map(result.beams_which_r_not_used, function(elem, index) {
        //   $('#Beam').append(`<option value="${elem.beamC_id}">{ ${elem.beamC_weight} kg ) ${elem.beamC_name} - ${moment(elem.beamC_time).format('Do MMMM YYYY, h:mm:ss a')}</option>`)
        // })
      } else{
        // $('#Beam').append(`<option value="${result.beam_id}" selected="" readonly="">{ ${result.beam_details.beamC_weight} kg ) ${result.beam_details.beamC_name} - ${moment(result.beam_details.beamC_time).format('Do MMMM YYYY, h:mm:ss a')}</option>`)
        $('.bal-taana--'+value+'').html(`<div class="badge badge-warning"><span style="color:green">${result.BeamLeft} meters</span></div>`)

      }
      $('#ViewWorkDetails--'+value+'').modal('show')
    })
    .fail(function(jqXHR,exception) {
      console.log(jqXHR.responseText);
    })
  }
</script>

