<!DOCTYPE html>
<html>
<?php $title = "Beam Report";
$nav_page = 10020;
include 'admin_assets/include/header.php';
?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
<!-- jQuery -->
<style type="text/css">
  .select2-container--default .select2-selection--single .select2-selection__rendered {
      color: #444;
      line-height: 24px;
  }
  .select2-container .select2-selection--single {
      height: 38px;
  }
  .select2-container--default .select2-selection--single .select2-selection__arrow {
      height: 35px;
  }
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }

}
</style>


<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Beam Report</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Beam Report</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                
                 <form class="work-form-dummy" action="<?php echo base_url();?>Admim/beam-report-data" method="post">

                    <div class="col-md-6">
                      <div class="form-group beamClass">
                        <label for="">Select Beam</label>
                        <select name="Beam" id="Beam" class="form-control" required="" selected>
                          <option value="" style="display: none;"></option>
                              <?php foreach($all_beam_created as $key => $value): ?>
                              <option value="<?php echo $value->beamC_id ;?>"><?php echo '( '.$value->beamC_weight.' kg ) '. $value->beamC_name. ' - ' .date('jS F Y h:m:s a', strtotime($value->beamC_time)) ;?></option>
                              <?php endforeach; ?>
                        </select>
                      </div>
                    </div>
                 
                  </form>
              </div>
            </div>
          </div>
        </div>
 
        <div class="row" id="resulkt">
          <div class="col-md-12">
            <div class="card">
               <div class="card-body ">
                <div class="table-responsive ">
                  <table id="beamTable" class="table table-bordered beamReport table-striped table-hover table-sm">
                    <thead>
                      <tr>
                      <th>Roll Work id</th>
                      <th>Staff Name</th>
                      <th>Machine Model</th>
                      <th>Meters Used Beam</th>
                      <th>Raw materials used</th>
                      <th>Wastage</th>
                      <th>Roll Typef</th>
                      <th>Roll Type</th>
                      <th>Roll Length (m)</th>
                      <th>Roll Weight (kg)</th>
                      <th>Roll Name</th>
                      <th>No. of Rolls </th>
                      <th>Date</th>
                      </tr>
                    </thead>
                    <tbody id="append_table_here">
                      
                    </tbody>
                    <tfoot id="append_table_foot_here">
                      
                    </tfoot>
                  </table>
                </div>
               </div>
               
               <div class="card-footer">
               </div>
             </div>
          </div>
        </div>


      </div><!-- /.container-fluid -->
    </div>
<!-- /.content -->


</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php' ?>

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>


<script>
  $(function(){
    $('#resulkt').hide()

    // $('#beamTable').DataTable();
    $('#Beam').select2({
        placeholder: "Select Beam",
    });

  })

$('#Beam').on('change', function() {

  var Beam =  this.value;

      $.ajax({
        url: "<?php echo base_url("admin/beam-report-data");?>",
        type: "POST",
        data: {beam:Beam},
        dataType:'json',
        cache: false,
        success: function(dataResult){
         console.log(dataResult);
         $('#resulkt').show('slow/400/fast');
         $('#append_table_here').html(dataResult.tbody)
         $('#append_table_foot_here').html(dataResult.tfoot)
         $('#beamTable').DataTable();
        }
      });
});


</script>
</body>
</html>
