<!DOCTYPE html>
<html>
<?php $title = "Beam";
$nav_page = 9992;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }

}
</style>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
          <div class="offset-md-2 col-md-8 text-center">
            <div class="card mx-auto">
              <div class="card-body" style="-webkit-box-shadow: 0px 0px 0px 5px #A0A0A0, inset 0px 10px 27px -8px #141414, inset 0px -10px 27px -8px #A31925, 5px 5px 15px 5px rgba(0,0,0,0);
    box-shadow: 0px 0px 0px 5px #a0a0a038, inset 0px 10px 27px -8px #1414141f, inset 0px -10px 27px -8px #a319254a, 5px 5px 15px 5px rgba(0,0,0,0);}">
                <span style="font-size: 24px;font-style: oblique;">Raw Materials left</span><span style="font-size: 25px;font-style: oblique;color: green;font-variant: 600"> : <?php echo $this->name->get_raw_materiats_left(); ?> kg</span> 
              </div>
            </div>
          </div>
        </div>
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Beam</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Beam</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        
        <div class="row">
          <div class="col-md-4">
            <form id="add_raw_form" action="<?php echo base_url();?>Admin/Insert_Beam" method="POST">
              <div class="card">
                <div class="card-header">
                  <h4 class="modal-title">Add Beam </h4>
                </div>
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-12 text-center">
                      <?php echo $this->session->flashdata('msg'); ?>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="weight">Weight (kg)</label>
                    <input type="number" name="weight" id="weight" class="form-control" required="">
                    <em class="text-danger"><?php echo form_error('weight'); ?></em>
                  </div>
                  <div class="form-group">
                    <label for="length">Length (meters)</label>
                    <input type="number" name="length" id="length" class="form-control" required="">
                    <em class="text-danger"><?php echo form_error('length'); ?></em>
                  </div>
                  <div class="form-group">
                    <label for="wastage">Wastage (kg)</label>
                    <input type="number" name="wastage" id="wastage" class="form-control" required="" value="0.00" step="any">
                    <em class="text-danger"><?php echo form_error('wastage'); ?></em>
                  </div>
                  <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" id="name" class="form-control">
                    <em class="text-danger"><?php echo form_error('name'); ?></em>
                  </div>
                </div>
                <div class="card-footer">
                  <button class="btn btn-outline-success csubmit" type="submit">Submit</button>
                </div>
              </div>
            </form>
          </div>
          <div class="col-md-8">

            <div class="card">
              <div class="card-body">
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th>Sl no.</th>
                        <th>Weight (kg)</th>
                        <th>Length (meters)</th>
                        <th>Wastage (kg)</th>
                        <th>Name</th>
                        <th>Status</th>
                        <th>Beam Left (meters)</th>
                        <th>Time</th>
                        <!-- <th>Manage</th> -->
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($res as $key => $value): ?>
                        <tr>
                          <td><?php echo $key+1; ?></td>
                          <td><?php echo $value->beam_weight; ?></td>
                          <td><?php echo $value->beam_length; ?></td>
                          <td><?php echo $value->beam_wastage; ?></td>
                          <td><?php echo $value->beam_name; ?></td>
                          <td><?php if ($value->beam_used_status === '1') { ?>
                            <span class="badge badge-danger">Used</span>
                          <?php }else{ ?>
                            <span class="badge badge-success">Not Used</span>
                          <?php } ?>
                          </td>
                          <td><?php echo $value->beam_length_red; ?></td>
                          <td><?php echo date('h:i a, d-M-Y', strtotime($value->beam_time)); ?></td>
                        </tr>
                      <?php endforeach ?>
                    </tbody>

            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Add Staff -->

</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->


<div id="Confirm_raw" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Confirm Raw Materials</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <form action="<?php echo base_url();?>Admin/Insert_raw_materials" method="POST">
        <div class="modal-body">
          <div class="form-group">
            <label for="weight">Weight (kg)</label>
            <input type="number" name="weight" id="cweight" class="form-control" readonly="">
          </div>
          <div class="form-group">
            <label for="length">Length (meters)</label>
            <input type="number" name="length" id="clength" class="form-control" readonly="">
          </div>
          <div class="form-group">
            <label for="wastage">Wastage (kg)</label>
            <input type="number" name="wastage" id="cwastage" class="form-control">
          </div>
          <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" id="cname" class="form-control" readonly="">
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-outline-success confirms" type="button">Submit</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Reset</button>
        </div>
      </form>
    </div>

  </div>
</div>

</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php'; ?>
<script>
  $(function() {
    $('.csubmit').click(function(event) {
      event.preventDefault()
      if ($('#weight').val().trim() === '') {
        alert('Weight cannot be empty')
        return false;
      }else if($('#length').val().trim() === ''){
        alert('Length cannot be empty')
        return false;
      }else if($('#wastage').val().trim() === ''){
        alert('Wastage cannot be empty')
        return false;
      }else if($('#name').val().trim() === ''){
        alert('Name cannot be empty')
        return false;
      }else{
        $('#cweight').val($('#weight').val())
        $('#cname').val($('#name').val())
        $('#clength').val($('#length').val())
        $('#cwastage').val($('#wastage').val())
        $('#Confirm_raw').modal('show')
      }
      
    });

    $('.confirms').click(function(event) {
      $('#add_raw_form').submit()
    });

    $('input[name="dop"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxYear: parseInt(moment().format('YYYY'),10)
    });
  });
</script>


</body>
</html>
