<!DOCTYPE html>
<html>
<?php $title = "Add Rolls";
  $nav_page = 55;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php include 'admin_assets/include/navbar.php'; ?>
  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Add Rolls</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Add Rolls</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item">Rolls</li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6">
                    <form action="<?php echo base_url();?>Admin/AddRollsName" method="POST">
                      <div class="form-group">
                        <label for="">Add Roll Type</label>
                        <input type="text" class="form-control" name="roll_type" required="">
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <button type="submit" class="btn btn-success btn-sm">Submit</button>
                        </div>
                      </div>
                    </form>
                  </div>

                  <div class="col-md-6">
                    <div class="table-responsive">
                      <table class="table table-bordered table-striped table-hover">
                        <thead>
                          <tr>
                            <th>Sl no</th>
                            <th>Roll Name</th>
                            <th>Manage</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php foreach ($all_rolls as $key => $value): ?>
                            <tr>
                              <td><?php echo $key+1; ?></td>
                              <td><?php echo $value->roll_types_name; ?></td>
                              <td class="text-center">
                                <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editRolls<?php echo $key; ?>"><i class="fa fa-edit"></i></button>
                                <!-- <a href="<?php echo base_url();?>Admin/DeleteRolls" onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a> -->
                              </td>
                            </tr>

                            <div id="editRolls<?php echo $key; ?>" class="modal fade" role="dialog">
                              <div class="modal-dialog">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h4 class="modal-title">Edit Rolls</h4>.
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  </div>
                                  <form action="<?php echo base_url();?>Admin/EditNewRolls" method="POST">
                                    <div class="modal-body">
                                      <div class="form-group">
                                        <label for="">Add Roll Type</label>
                                        <input type="text" class="form-control" value="<?php echo $value->roll_types_name; ?>" name="roll_type" required="">
                                        <input type="hidden" name="roll_id" value="<?php echo $value->roll_types_id; ?>">
                                      </div>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                          <?php endforeach ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
</body>
</html>

