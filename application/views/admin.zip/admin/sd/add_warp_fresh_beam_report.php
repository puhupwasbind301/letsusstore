<!DOCTYPE html>
<html>
<?php $title = "Warping Fresh Beam Report";
$nav_page = 10050;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }

}
</style>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Manage Fresh Beams Report</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Manage Fresh Beams Report</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->

    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <div class="card">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-12 mb-3">
                    <?php echo $this->session->flashdata('val_error'); ?>
                  </div>
                </div>

                <div class="table-responsive">
                  <table id="examplec1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th style="width: 5%">Sl no.</th>
                        <th>Raw Material Type</th>
                        <th>Raw Material Type of Type</th>
                        <th>Machine name</th>
                        <th>Beam Name</th>
                        <th>Beam weight (Kg)</th>
                        <th>Beam length (m)</th>
                        <th>Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach($beam_fresh_detail as $key => $value): ?>
                      <tr>
                        <td><?= ++$key; ?></td>
                        <td><?= $value->inward_type ; ?></td>
                        <td><?= $value->inward_type_of_type ; ?></td>
                        <td><?= $value->mac_name ; ?></td>
                        <td><?= $value->beamC_name ; ?></td>
                        <td><?= $value->beamC_weight ; ?></td>
                        <td><?= $value->beamC_length ; ?></td>
                        <td><?= $value->time ; ?></td>
                     
                      </tr>
                    <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                          <th>Sl no.</th>
                          <th>Raw Material Type</th>
                          <th>Used Status</th>
                          <th>Machine name</th>
                          <th>Beam Name</th>
                          <th>Beam weight (Kg)</th>
                          <th>Beam length (m)</th>
                          <th>Date</th>
                        </tr>
                    </tfoot>

            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Add Staff -->

</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->

</div>



<?php include 'admin_assets/include/footer.php'; ?>
<script>
  $(function() {



    $('input[name="dop"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxYear: parseInt(moment().format('YYYY'),10)
    });
  });

  $(document).ready(function() {
      // Setup - add a text input to each footer cell
      $('#examplec1 tfoot th').each( function () {
          var title = $(this).text();
          $(this).html( '<input class="form-control" type="text" placeholder="Search '+title+'" />' );
      } );
   
      // DataTable
      var table = $('#examplec1').DataTable({
          initComplete: function () {
              // Apply the search
              this.api().columns().every( function () {
                  var that = this;
   
                  $( 'input', this.footer() ).on( 'keyup change clear', function () {
                      if ( that.search() !== this.value ) {
                          that
                              .search( this.value )
                              .draw();
                      }
                  } );
              } );
          }
      });
   
  } );
</script>


</body>
</html>
