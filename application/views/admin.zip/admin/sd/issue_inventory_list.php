<!DOCTYPE html>
<html>
<?php $title = "Inventory Issued List";
  $nav_page = 10;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
 <?php include 'admin_assets/include/navbar.php'; ?>

  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Inventory Issued List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url()?>">Home</a></li>
              <li class="breadcrumb-item">Inventory</li>
              <li class="breadcrumb-item active">Inventory Issued List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

     <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <div class="card">
              <div class="card-header">
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>Item</th>
                        <th>Inventory Category</th>
                        <th>Issued to</th>
                        <th>Quantity</th>
                        <th>Manage</th>
                      </tr>
                    </thead>

                    <tbody>
                      <?php foreach($data as $key => $val): ?>
                        <tr>
                          <td><?= ++$key?></td>
                          <td><?= $val->item_inventory?></td>
                          <td><?= $val->inventory_category?></td>
                          <td><?= $val->staff_name?></td>
                          <td><?= $val->stck_quantity?></td>
                          <td class="text-center"><a href="#" data-toggle="modal" data-target="#modalview-lg<?= $val->stckissue_id?>"><i class="fa fa-eye text-info" title="View"></i></a>&emsp;|&emsp;<a href="#" data-toggle="modal" data-target="#modal-sm<?= $val->stckissue_id?>"><i class="fa fa-trash text-danger" title="Delete"></i></a></td>
                        </tr>

                         <!-- View Item -->
                  <div class="modal fade" id="modalview-lg<?= $val->stckissue_id?>">
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">View Issued Inventory Details</h4>

                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                            <div class="row p-2">
                              <div class="col-md-6">
                                <div class="row">
                                  <div class="col-md-4"><label class="font-weight-bold">Issued to:</label></div>
                                  <div class="col-md-8"><?= $val->staff_name?></div>
                                </div>
                              </div>
                              <div class="col-md-6">
                                <div class="row">
                                  <div class="col-md-4"><label class="font-weight-bold">Inventory Category:</label></div>
                                  <div class="col-md-8"><?= $val->inventory_category?></div>
                                </div>
                              </div>
                            </div>
                            <div class="row p-2">
                              <div class="col-md-6">
                                <div class="row">
                                  <div class="col-md-4"><label class="font-weight-bold">Item:</label></div>
                                  <div class="col-md-8"><?= $val->item_inventory?></div>
                                </div>
                              </div>
                              <div class="col-md-6">
                                <div class="row">
                                  <div class="col-md-4"><label class="font-weight-bold">Quantity:</label></div>
                                  <div class="col-md-8"><?= $val->stck_quantity?></div>
                                </div>
                              </div>
                            </div>

                            <div class="row p-2">
                              <div class="col-md-6">
                                <div class="row">
                                  <div class="col-md-4"><label class="font-weight-bold">MRP:</label></div>
                                  <div class="col-md-8"><?= $val->item_mrp?></div>
                                </div>
                              </div>
                              <div class="col-md-6">
                                <div class="row">
                                  <div class="col-md-4"><label class="font-weight-bold">Total:</label></div>
                                  <div class="col-md-8"><?= $val->stck_total?></div>
                                </div>
                              </div>
                            </div>

                            <div class="row p-2">
                              <div class="col-md-6">
                                <div class="row">
                                  <div class="col-md-4"><label class="font-weight-bold">Discount:</label></div>
                                  <div class="col-md-8"><?= $val->stck_discount?></div>
                                </div>
                              </div>
                              <div class="col-md-6">
                                <div class="row">
                                  <div class="col-md-4"><label class="font-weight-bold">Remarks:</label></div>
                                  <div class="col-md-8"><?= $val->stck_remarks?></div>
                                </div>
                              </div>
                            </div>

                            <div class="row p-2">
                              <div class="col-md-6">
                                <div class="row">
                                  <div class="col-md-4"><label class="font-weight-bold">Issued On:</label></div>
                                  <div class="col-md-8"><?= date('d M, Y',strtotime($val->stck_created_at))?></div>
                                </div>
                              </div>
                              
                            </div>
                          
                        </div>

                        </div>
                        <!-- /.modal-content -->
                      </div>
                      <!-- /.modal-dialog -->
                      </div>

                      <!-- Delete Purchase Order -->
                  <div class="modal fade" id="modal-sm<?= $val->stckissue_id?>">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">Delete Issued Inventory Item</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <form action="<?= base_url()?>admin/delete-issued-inventory" method="post"> 
                          <div class="modal-body">
                            <input type="hidden" name="issuedid" value="<?= $val->stckissue_id?>">
                            <p>Are you sure, you want to delete this?</p>
                          </div>
                          <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Yes</button>
                          </div>
                        </form>
                      </div>
                      <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                  </div>
                  <!-- /.modal -->
                      <?php endforeach; ?>
                      
                    </tbody>

            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Add Staff -->
    <div class="modal fade" id="modal-lg">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Add Machine</h4>

            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <!-- form start -->
            <form  id="ajaxform1" method="post">
              <div class="card-body">
                <div id="messageForm"></div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="model">Model</label>
                      <input type="text" class="form-control" id="model" name="model" placeholder="Model" required="" >

                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="title">Title</label>
                      <input type="text" class="form-control" id="title" name="title" placeholder="Title" >

                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="dop">Date of Purchase</label>
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="far fa-calendar-alt"></i>
                        </span><input type="text" name="dop" id="dop" class="form-control" >

                      </div>

                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="amount">Purchase Amount</label>
                      <input type="number" class="form-control" id="amount" name="amount" placeholder="Purchase Amount" >

                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                   <div class="form-group">
                    <label for="doj">Select Type</label>
                    <select class="form-control" name="type" id="stype">
                      <option value="">---Select Type---</option>
                      <option value="1">Automatic</option>
                      <option value="2">Manual</option>
                    </select>

                  </div>
                </div>

              </div>

              <div class="row electype d-none" id="Electric">
                <div class="col-md-6">
                 <div class="form-group">
                  <label for="">Consumption</label>
                  <select class="form-control" name="consumption">
                    <option value="">---Select Consumption Type---</option>
                    <option value="1">Kilowatt (kW)</option>
                    <option value="2">Litre (l)</option>
                  </select>

                </div>
              </div>

              <div class="col-md-6">
               <div class="form-group">
                <label for="unit">Unit <small>(per hour)</small></label>
                <input type="number" id="unit" name="unit" class="form-control" step="any">

              </div>
            </div>

          </div>

          <div class="form-group">
            <label for="desc">Description</label>
            <textarea class="form-control" name="desc"  rows="3"></textarea>
          </div>

        </div>


        <!-- /.card-body -->

        <div class="card-footer">
          <button type="submit" class="btn btn-primary float-right">Submit</button>
        </div>
      </form>
    </div>

  </div>
  <!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
</body>
</html>
