<!DOCTYPE html>
<html>
<?php $title = "Coating";
  $nav_page = 40;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
 <?php include 'admin_assets/include/navbar.php'; ?>

  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Coating</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url() ?>">Home</a></li>
              <li class="breadcrumb-item active">Coating</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <div class="card">
      <div class="card-header">
        <button type="button" class="btn btn-info float-right" data-toggle="modal" data-target="#modal-lg">Add Roll</button>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>#</th>
                <th>Roll Name</th>
                <th>Roll Weight (before Coating)</th>
                <th>Roll Length (Given)</th>
                <th>Roll Weight (After Coating)</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($coatroll as $key => $val): ?>
              <tr>
                <td><?= ++$key ?></td>
                <td><?= $val->coating_roll_name ?></td>
                <td><?= $val->coating_roll_weight ?></td>
                <td><?= $val->coating_roll_length ?></td>
                <td>
                  <?php if($val->coating_roll_weight_after_coating != ""){ ?>
                  
                    <b>Roll Weight:</b> <?= $val->coating_roll_weight_after_coating ?>
                    <br>
                    <b>Chemical:</b> <?= $val->coating_chemical ?>
                    <br>
                    <b>Color:</b> <?= $val->coating_color ?>
                  <?php } else{ ?>
                  <a href="#" data-toggle="modal" data-target="#modalover-lg<?= $val->coating_id ?>"><i class="fa fa-plus text-success"></i></a>
                <?php } ?>
                </td>
                <td><?= date('d-m-Y', strtotime($val->coating_updated)) ?></td>
              </tr>


              <!-- add roll after coating -->
                    <div class="modal fade" id="modalover-lg<?= $val->coating_id ?>">
                      <div class="modal-dialog modaledit-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Add Roll Detail after Coating (<?= $val->coating_roll_name ?>)</h4>
                            <div class="msgworkafter"></div>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <!-- form start -->
                            <form action="" class="roll-after-coating" method="post">
                              <div class="card-body">
                                  
                                <div class="form-group">
                                  <label class="form-label">Roll Weight (in Kgs)</label>
                                  <input type="number" name="roll_weight_after" class="form-control" step="any">
                                  <input type="hidden" name="crollid" value="<?= $val->coating_id ?>" step="any">
                                </div>
                                <div class="form-group">
                                  <label class="form-label">Chemical Added (in Kgs)</label>
                                  <input type="number" name="chemical" class="form-control" step="any">
                                </div>
                                <div class="form-group">
                                  <label class="form-label">Color Added (in Kgs)</label>
                                  <input type="number" name="color" class="form-control" step="any">
                                </div>

                              </div>


                           <!-- /.card-body -->

                           <div class="card-footer">
                            <button type="submit" class="btn btn-primary float-right">Submit</button>
                          </div>
                        </form>
                      </div>

                    </div>
                    <!-- /.modal-content -->
                  </div>
                  <!-- /.modal-dialog -->
                </div>

              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Add Roll for coating -->
<div class="modal fade" id="modal-lg">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add Roll</h4>
        <div id="msg"></div>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- form start -->
        <form action="#" id="add_roll_coating" method="post">
          <div class="card-body">
            <div class="form-group">
              <label for="rollid" class="form-label">Select Roll</label>
              <select class="form-control" name="rollid" id="rollid">
                <option value="">---Select Roll---</option>
                <?php foreach($roll as $key => $val): ?>
                <option value="<?= $val->roll_id ?>"><?= $val->roll_name ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group row">
              <div class="col-md-6">
                <label>Roll Weight</label>
                <input type="number" class="form-control" id="rweight" name="rweight" step="any">
              </div>
              <div class="col-md-6">
                <label>Roll Length</label>
                <input type="number" class="form-control" id="rlength" name="rlength">
                <input type="hidden" name="rname" id="rname">
              </div>
              
            </div>
          </div>
      <!-- /.card-body -->
      <div class="card-footer">
        <button type="submit" class="btn btn-primary float-right">Submit</button>
      </div>
    </form>
  </div>

</div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
  <script type="text/javascript">
    
    $( "#rollid" ).change(function(){

      let rollid = $(this).val();

      $.ajax({

       type       : 'POST',
       url        : '<?php echo base_url() ?>admin/get-roll-detail',
       dataType   : 'json',
       data       : {'rid' : rollid},
       success    : function(result) {
         
         
         var rlength = result.roll_length
         var rweight = result.roll_weight
         var rname = result.roll_name

         $('#rlength').val(rlength);
         $('#rweight').val(rweight);
         $('#rname').val(rname);

       },error: function(jqXHR, exception) {

         console.log(jqXHR.responseText);
       }

     });
  })
  

  $('#add_roll_coating').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/add-coating-roll", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })  

  $('.roll-after-coating').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/add-roll-after-coating", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  }) 

  </script>
</body>
</html>
