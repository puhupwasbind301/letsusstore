<!DOCTYPE html>
<html>
<?php $title = "Purchase Order";
  $nav_page = 7;
  include 'admin_assets/include/header.php';
 ?>
 <style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg, .modal-lg{
    max-width: 400px;
  }

}

@media (min-width: 640px) {
  .modaledit-lg, .modalview-lg, .modal-lg{
    max-width: 400px;
  }

}
</style>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
 <?php include 'admin_assets/include/navbar.php'; ?>

  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Purchase Order</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Inventory</a></li>
              <li class="breadcrumb-item "><a href="<?= base_url()?>admin/create-vendor">Vendor</a></li>
              <li class="breadcrumb-item active">Purchase Order</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            
            <div class="card">
              <div class="card-header">
                <h4>Purchase Order of (<?= $data->vendor_name?>)</h4>
                <button type="button" class="btn btn-info float-right" data-toggle="modal" data-target="#modal-lg"><i class="fa fa-plus"></i></button>
              </div>

              <div class="card-body">
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>Category</th>
                        <th>Date</th>
                        <th>Total</th>
                        <th>Paid</th>
                        <th>Add Item</th>
                        <th>Manage</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach($purchase as $key => $val): ?>
                      <tr>
                        <td><?= ++$key?></td>
                        <td><?= $val->vpo_category?></td>
                        <td><?= date('d M y',strtotime($val->vpo_date))?></td>
                        <td><?php $total = $this->name->getTotalItemPurchaseOrder($val->vpo_id); 
                        if($total != 0){

                          echo $total;
                        }?>
                        <!-- <?php if(!empty($val->item_quantity)){

                          $total = $val->item_quantity*$val->item_rate;
                          $sub = $val->item_free*$val->item_rate;

                          $total = $total-$sub;
                          $total = $total-$val->item_discount;

                          echo $total;
                        } ?> --></td>
                        <td></td>
                        <td class="text-center"><a href="<?= base_url()?>admin/item-manage/<?= $val->vpo_id?>"><i class="fa fa-plus text-success"></i></a></td>
                        <td class="text-center"><a href="#" data-toggle="modal" data-target="#modal-sm<?= $val->vpo_id?>"><i class="fa fa-trash text-danger" title="Delete"></i></a></td>
                      </tr>

                       <!-- Delete Purchase Order -->
                  <div class="modal fade" id="modal-sm<?= $val->vpo_id?>">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">Delete Purchase Order</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <form action="<?= base_url()?>admin/delete-purchase-order" method="post"> 
                          <div class="modal-body">
                            <input type="hidden" name="po_id" value="<?= $val->vpo_id?>">
                            <p>Are you sure, you want to delete this?</p>
                          </div>
                          <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Yes</button>
                          </div>
                        </form>
                      </div>
                      <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                  </div>
                  <!-- /.modal -->
                    <?php endforeach; ?>
                    </tbody>
                   

            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Add Staff -->
    <div class="modal fade" id="modal-lg">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Add Purchase Order</h4>

            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <!-- form start -->
            <form  id="ajaxform1" method="post">
              <div class="card-body">
                <div id="messageForm"></div>
                <input type="hidden" name="vendorid" value="<?= $this->uri->segment(3);?>">
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="model">Category</label>
                      <input type="text" class="form-control" id="model" name="category" placeholder="Category" >

                    </div>
                  </div>
                
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="pdate">Date</label>
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="far fa-calendar-alt"></i>
                        </span><input type="text" name="pdate" id="pdate" class="form-control" >

                      </div>

                    </div>
                  </div>
          
                </div>
        </div>

        <!-- /.card-body -->

        <div class="card-footer">
          <button type="submit" class="btn btn-primary float-right">Submit</button>
        </div>
      </form>
    </div>

  </div>
  <!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
  <script>
  $(function() {
    $('input[name="pdate"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxYear: parseInt(moment().format('YYYY'),10)
    });
  });
</script>

<script type="text/javascript">
  $(function() {
    $('#ajaxform1').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/insert-purchase-order", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>
</body>
</html>
