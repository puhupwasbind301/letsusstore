<!DOCTYPE html>
<html>
<?php $title = "Beams Created";
$nav_page = 10010;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }

}
</style>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Manage Beams Created</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Manage Beams Created</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->

    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <div class="card">
              <div class="card-body">
                <div class="row">
                  <div class="col-md-12 mb-3">
                    <?php echo $this->session->flashdata('val_error'); ?>
                  </div>
                </div>
                <div class="table-responsive">
                  <table id="examplec1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th style="width: 5%">Sl no.</th>
                        <th>Machine name</th>
                        <th>Beam Name</th>
                        <th>Beam weight (Kg)</th>
                        <th>Beam length (m)</th>
                        <th>Date</th>
                        <th>Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($all_beams as $key => $value): ?>

                      <tr>
                        <td style="width: 5%"><?php echo $key+1; ?></td>
                        <td><?php echo $this->name->get_machine_name_by_id($value->beamC_machine_id)->mac_name; ?></td>
                        <td><?php echo $value->beamC_name; ?></td>
                        <td><?php echo $value->beamC_weight; ?></td>
                        <td><?php echo $value->beamC_length; ?></td>
                        <td><?php echo date('d-m-Y, h:i a', strtotime($value->beamC_time)); ?></td>
      <td align="center"><a href="<?= base_url() ?><?= 'admin/delete-beam-created/' ?><?= $value->beamC_id.'/'.$value->beamC_machine_id.'/'.$value->beamC_weight ?>" ><i class="fa fa-trash text-danger" title="Delete"></i></a></td>
                      </tr>

                      <?php endforeach ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Sl no.</th>
                            <th>Machine name</th>
                            <th>Beam Name</th>
                            <th>Beam weight (Kg)</th>
                            <th>Beam length (m)</th>
                            <th>Date</th>
                        </tr>
                    </tfoot>

            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Add Staff -->

</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->

</div>



<?php include 'admin_assets/include/footer.php'; ?>
<script>
  $(function() {



    $('input[name="dop"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxYear: parseInt(moment().format('YYYY'),10)
    });
  });

  $(document).ready(function() {
      // Setup - add a text input to each footer cell
      $('#examplec1 tfoot th').each( function () {
          var title = $(this).text();
          $(this).html( '<input class="form-control" type="text" placeholder="Search '+title+'" />' );
      } );
   
      // DataTable
      var table = $('#examplec1').DataTable({
          initComplete: function () {
              // Apply the search
              this.api().columns().every( function () {
                  var that = this;
   
                  $( 'input', this.footer() ).on( 'keyup change clear', function () {
                      if ( that.search() !== this.value ) {
                          that
                              .search( this.value )
                              .draw();
                      }
                  } );
              } );
          }
      });
   
  } );
</script>


</body>
</html>
