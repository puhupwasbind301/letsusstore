<!DOCTYPE html>
<html>
<?php $title = "Workers Report";
$nav_page = 56;
include 'admin_assets/include/header.php';
?>

<style>
  .table-condensed thead tr:nth-child(2) {
  display: none;
}
.table-condensed tbody {
  display: none;
}

</style>

<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Staff Report</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url()?>admin">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Manufacturing</a></li>
              <li class="breadcrumb-item active">Staff Reports</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <div class="card">
      <div class="card-header">

      </div>
      <div class="card-body">



         <div class="row">
             <form action="" method="get" class=" col-sm-12 work-report-staff-form">
             <!-- <form action="<?php //echo base_url(); ?>admin/get-staff-report" method="get" class=" col-sm-12 work-report-staff-form"> -->
         <div class="d-flex">

          <div class="col-sm-4 ">
            <div class="form-group">
              <label>Select Staff</label>
              <select class="form-control" name="staff" id="staff" selected>
                <option value="">---Select Staff---</option>
                <?php foreach($staff as $key => $val): ?>
                  <option value="<?= $val->staff_id?>"><?= $val->staff_name?></option>
                <?php endforeach; ?>
              </select>
              <small id="staffnot" class="text-danger"></small>
            </div>
          </div>

          <div class="col-sm-4">
            <div class="form-group ">
              <label for="date">Date</label>
                <div class="d-flex">
                <!-- <label for="staffmonth">Month</label> -->
                <select class="form-control " name="staffmonth" id="staffmonth" selected>
                  <option value="">Month</option>
                  <option value="01">January</option>
                  <option value="02">Febuary</option>
                  <option value="03">March</option>
                  <option value="04">April</option>
                  <option value="05">May</option>
                  <option value="06">June</option>
                  <option value="07">July</option>
                  <option value="08">August</option>
                  <option value="09">September</option>
                  <option value="10">October</option>
                  <option value="11">November</option>
                  <option value="12">December</option>
                </select>
                <!-- <label for="staffyear">Year</label> -->
                <select class="form-control " name="staffyear" id="staffyear" selected>
                  <option value="">Year</option>
                   <?php for($i = date('Y');$i>=1970;$i--): ?>
                    <option value="<?= $i ?>"><?= $i ?></option>
                  <?php endfor; ?>
                </select>
                </div>
              <small id="frstdate" class="text-danger"></small>
            </div>
          </div>

          <div class="col-sm-4 ">
            <label for=""></label>
            <div class="form-group pt-2">
            <button type="submit"  class="btn btn-primary float-sm-left" id="getstaff">Get</button>
            </div>
          </div>
        </div>    
       
        </form>
        </div>
 <?php //echo phpinfo(); ?>

<?php if(!empty($staffData)){ ?>
      <div class="card staffcard">
        
  <div class="card-header d-flex ">
    <p id="Wname" class="px-2"><b style="font-size: x-large;">Worker Name :    </b></p> <span style="font-size: x-large;"> <?php echo $workerName; ?> </span> <b>&emsp;</b>
    <p id="Wmonth" class="px-2"><b style="font-size: x-large;">Month  :    </b></p> <span style="font-size: x-large;"> <?php echo $month; ?> </span><b>&emsp;</b>
   
     <p id="Wyear" class="px-2"><b style="font-size: x-large;">Year   :    </b></p> <span style="font-size: x-large;"> <?php echo $year; ?></span>
  </div>

  <div class="card-body">

            <div class="form-group">
              <label for="dfdate">Staff Data</label>
              <h5 class="text-muted"> <?php echo date('d M, Y', strtotime($staffData['dateS'])); ?> - <?php echo date('d M, Y', strtotime($staffData['dateE'])); ?></h5>
              
              <div class="input-group-prepend">
                <p>Allocated Beam Names  : </p> 
                  <h5 class="pb-2 pl-2"> 
                    <?= $staffData['beamNameStr'] ?>
                  </h5>
              </div>   

            <div class="input-group-prepend">
                <p>Beam Length Total  : </p> 
                <h5 class="pb-2 pl-2"> 
                  <?= $staffData['totalbeam_Length']." m" ?>
                </h5>
            </div>   
              
            <div class="input-group-prepend">
                <p>Allocated Meter excesses BeamL Total  : </p> 
                <h5 class="pb-2 pl-2"> 
                  <?= $staffData['metersExcBeamL']." m" ?>
                </h5>
              </div>  

             <div class="input-group-prepend" style="flex-direction: column;">
                <p>Raw materials used : </p> 
                
                <p class="pb-2 pl-2"> 
                   Total Weight Used:  <?= $staffData['raw_material_used_weight']." kg"; ?>
                   
                </p>
                <p>
                   Type Used: <?= $staffData['rawMaterialsUsedType']; ?>
                </p>
              </div>  
        
         
              <div class="input-group-prepend">
                <p>Allocated New Manufacturing Machine  : </p> 
                <h5 class="pb-2 pl-2"> 
                  <?= $staffData['resultMachineName'] ?>
                </h5>
              </div>

              <div class="input-group-prepend">
                <p>Wastage : </p> 
                <h5 class="pb-2 pl-2"> 
                  <?= $staffData['wastage']." kg" ?>
                </h5>
              </div>


              <!-- <div class="input-group-prepend">
                <p>Total Rolls Created : </p> 
                <h5 class="pb-2 pl-2"> 
                  <?= $staffData['allocatedRolls'] ?>
                </h5>
              </div> -->

              <div class="">
                <p>New Rolls Created According to Allocated Work Id  : </p> 
                <!-- <h5 class="pb-2 pl-2">  -->
                  <table id="beamTable" class="table table-bordered table-sm table-striped table-hover" >
                    <thead>
                      <tr>
                        <th>Roll_id</th>
                        <th>New Roll Typef</th>
                        <th>New Roll Type</th>
                        <th>New Roll Length</th>
                        <th>Roll Name</th>
                        <th>Roll_Weight</th>
                        <th>Roll_Created Date</th>
                      </tr>
                    </thead>
                    
                    <tbody>
                      <?php foreach($staffData['resultRoll'] as $key => $value): ?>
                    
                      <tr>
                        <td><?= "Roll_id - ".$value['new_roll_id'] ; ?></td>
                        <td><?= $value['new_roll_typef'] ; ?></td>
                        <td><?= $value['new_roll_type'] ; ?></td>
                        <td><?php if($value['new_roll_typef'] == 'unfinished'){ echo '' ; } else{ echo  $value['new_roll_length']." <sub>sq</sub><sup>2</sup><sub>m</sub>" ; }  ?></td>
                        <td><?= $value['new_roll_name'] ; ?></td>
                        <td><?= $value['new_roll_weight']." kg" ; ?></td>
                        <td><?= $value['new_roll_created_date'] ; ?></td>
                      </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>


              </div>

          
           </div>
         </div>
        <div class="card-footer">Staff Worker Deatails Based On Their Name,Month and Year</div>
      </div>

           <?php }else{   ?>
            <div class="row">
              <div class="col-md-12">
                <div class="card mt-5">
                  <div class="card-header">
                    <h4 class="text-center text-danger">No data found</h4>
                  </div>
                </div>
              </div>
            </div>
           <?php } ?>

      <br><br>

    </div>
  </div>



</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php'; ?>

<script type="text/javascript">
  $(function() { 

    $('#beamTable').DataTable();

    $('.work-report-staff-form').submit(function(event) {
      event.preventDefault();
      var dataArray = $(this).serializeArray();


          dataObj = {};

          console.log(dataArray);
          // return false;
          
          $(dataArray).each(function(i, field){
            dataObj[field.name] = field.value;
            
          });
          var staff_id = dataObj['staff'];
          var month= dataObj['staffmonth'];
          var year = dataObj['staffyear'];

          if(staff_id != '' && month != '' && year != ''){
          window.location = "<?php echo base_url();?>admin/get-staff-report/"+staff_id+"/"+month+"/"+year+"";
          } else {
            $('#frstdate').html('Feilds Empty');
          }
    });

  });
</script>
<script>
  $(function() {
    // $('.daterangep').daterangepicker({
    //   singleDatePicker: true,
    //   showDropdowns: true,
    //   minYear: 1901,
    //   maxDate: new Date(),
    //   maxYear: parseInt(moment().format('YYYY'),10)
    // });

  });
</script>




</body>
</html>
