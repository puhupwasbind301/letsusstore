<!DOCTYPE html>
<html>
<?php $title = "Finished Goods";
$nav_page = 12;
include 'admin_assets/include/header.php';
?>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Finished Goods</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url()?>admin">Home</a></li>
              <li class="breadcrumb-item active">Finished Goods</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <div class="card">
              <div class="card-header">

                <button type="button" class="btn btn-info float-right" data-toggle="modal" data-target="#modal-lg">Add&nbsp;<i class="fa fa-plus"></i></button>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>Finished Goods Name</th>
                        <th>Manage</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach($data as $key => $value): ?>
                        <tr>
                          <td><?= ++$key?></td>
                          <td><?= $value->goods_name?></td>
                          <td class="text-center"><a href="#" data-toggle="modal" data-target="#modaledit-lg<?= $value->goods_id?>"><i class="fa fa-edit text-success"></i></a>&emsp;|&emsp;<a href="#" data-toggle="modal" data-target="#modal-sm<?= $value->goods_id?>"><i class="fa fa-trash text-danger"></i></a></td>
                        </tr>

                        <!-- Edit Finished Goods -->
                        <div class="modal fade" id="modaledit-lg<?= $value->goods_id?>">
                          <div class="modal-dialog modaledit-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h4 class="modal-title">Edit Goods</h4>
                                <div id="messageForm1"></div>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <!-- form start -->
                                <form action="" class="finishedup" method="post">
                                  <div class="card-body">
                                    <div id="msgwork1"></div>
                                    <div class="row form-group">
                                     <div class="col-md-12">
                                       <label for="goods">Finished Goods</label>
                                       <input type="text" name="goods" class="form-control" value="<?= $value->goods_name?>">
                                     </div> 
                                   </div>
                                 </div>
                                 <!-- /.card-body -->
                                 <div class="card-footer">
                                  <button type="submit" class="btn btn-primary float-right">Submit</button>
                                </div>
                              </form>
                            </div>

                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>

                      <!-- Delete Goods Name -->
                      <div class="modal fade" id="modal-sm<?= $value->goods_id?>">
                        <div class="modal-dialog modal-sm">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Delete Goods</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <form action="<?= base_url()?>admin/delete-goods" method="post"> 
                              <div class="modal-body">
                                <input type="hidden" name="gdid" value="<?= $value->goods_id?>">
                                <p>Are you sure, you want to delete this?</p>
                              </div>
                              <div class="modal-footer justify-content-between">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Yes</button>
                              </div>
                            </form>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <!-- /.modal -->
                    <?php endforeach; ?>
                  </tbody>

                </table>
              </div>
            </div>
          </div>
        </div>
        <!-- Insert Allocated Work -->
        <div class="modal fade" id="modal-lg">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h4 class="modal-title">Add Finished Goods</h4>
                <div id="msg"></div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <!-- form start -->
                <form action="" id="addfinishedgoods" method="post">
                  <div class="card-body">
                    <div id="msgwork"></div>

                    <div class="row form-group">
                     <div class="col-md-12">
                       <label for="goods">Finished Goods</label>
                       <input type="text" name="goods" class="form-control" required="">
                     </div> 
                   </div>
                 </div>

                 <!-- /.card-body -->


                 <div class="card-footer">
                  <button type="submit" class="btn btn-primary float-right">Submit</button>
                </div>
              </form>
            </div>

          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content -->


</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php'; ?>
<script type="text/javascript">
  $(function() {
    $('#addfinishedgoods').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/insert-finished-goods", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          $('#msgwork').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>

<script type="text/javascript">
  $(function() {
    $('.finishedup').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/update-finished-goods", data).then(function(result) {


        if(result){
          window.location.reload()
        }
        else{
          $('#msgwork').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>
</body>
</html>
