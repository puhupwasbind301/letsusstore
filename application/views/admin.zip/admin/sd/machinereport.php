<!DOCTYPE html>
<html>
<?php $title = "Machine Report";
  $nav_page = 58;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
 <?php include 'admin_assets/include/navbar.php'; ?>

  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Machine Report</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Manufacturing</a></li>
              <li class="breadcrumb-item active">Machine Report</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <div class="card">
      <div class="card-header">
          
      </div>
      <div class="card-body">
        <!-- <div class="row d-print-none">
          <div class="col-sm-4">
            <div class="form-group">
              <label>Get Report by</label>
              <select class="form-control" id="report">
               <option value="">---Select---</option>
               <option value="1">by Machine</option>
               <option value="2">by Date</option>
             </select>
           </div> 
         </div>
       </div> -->
       <div id="show1" class="d-print-none">
         <div class="row">
          <div class="col-sm-4">
            <div class="form-group">
              <label>Select Machine</label>
              <select class="form-control" name="machine" id="machine">
                <option value="">---Select Machine---</option>
                <?php foreach($machine as $key => $val): ?>
                  <option value="<?= $val->machine_id?>"><?= $val->machine_model?></option>
                <?php endforeach; ?>
              </select>
              <small id="staffnot" class="text-danger"></small>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="form-group">
              <label for="fdate">Beam Installation Date</label>
              <select name="beamid" id="beamdate" class="form-control">
                

              </select>
              
            </div>
          </div>
          <div class="col-sm-4">
            <div class="form-group">
              <!-- <label for="sdate">Second Date</label>
              <div class="input-group-prepend">
                <span class="input-group-text">
                  <i class="far fa-calendar-alt"></i>
                </span><input type="text" name="sdate" id="sdate" class="form-control daterangep">
              </div>
            </div> -->
          </div>
          <div class="col-sm-12">
            <button type="button" class="btn btn-primary float-sm-right" id="getmachine">Get</button>
          </div>
        </div>
      </div>
      
      <div id="show2" style="display: none;" class="d-print-none">      
        <div class="row">
          
          <div class="col-sm-4">
            <div class="form-group">
              <label for="dfdate">First Date</label>
              <div class="input-group-prepend">
                <span class="input-group-text">
                  <i class="far fa-calendar-alt"></i>
                </span><input type="text" name="dfdate" id="dfdate" class="form-control daterangep">
              </div>
              <small id="dfrstdate" class="text-danger"></small>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="form-group">
              <label for="dsdate">Second Date</label>
              <div class="input-group-prepend">
                <span class="input-group-text">
                  <i class="far fa-calendar-alt"></i>
                </span><input type="text" name="dsdate" id="dsdate" class="form-control daterangep">
              </div>
            </div>
          </div>
          <div class="col-sm-12">
            <button type="button" class="btn btn-primary float-sm-right" id="getwork">Get</button>
          </div>

        </div>
      </div>
      </div>

      <br><br>
      <div class="table-responsive">
        <table class="table table-bordered table-striped">
          <thead class="thead-light">
            <tr>
              <th>Machine</th>
              <th>Beam Weight Initial</th>
              <th>Cone Given (in Kg)</th>
              <th>Beam Length Initial (in Meter)</th>
              <th>Total No of Rolls Produce</th>
              <th>Total Roll Length (in meter)</th>
              <th>Total Weight of Roll</th>
            </tr>
          </thead>
          <tbody id="machinereport">

          </tbody>
        </table>
      </div>
      
  </div>

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>

  <script type="text/javascript">
  $(function() { 
    $('#report').change(function(){

     let vals = $(this).val();

     if(vals === '1'){

      $('#show1').show();
      $('#show2').hide();

    }
    else if(vals === '2'){

      $('#show2').show();
      $('#show1').hide();  
    }
    else{


    }
  });
  });
</script>
  <script>
  $(function() {
    $('.daterangep').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });

  });
</script>

<script type="text/javascript">
  $(document).ready(function(){

    $('#machine').click(function(){

      var machine = $('#machine').val();

      $.ajax({

       type       : 'POST',
       url        : '<?php echo base_url() ?>Machineajax/getmachineBeamDate',
       dataType   : 'json',
       data       : {'machine':machine},
       beforeSend : function() {

        $('#beamdate').html('');
      },
       success    : function(data) {

      
        $.map(data, function(ele,i){

          $('#beamdate').append(`<option value='${ele.beam_id}'>${ele.bim_time}</option>`);

        })

        $("#mytable1").DataTable();
        

      },error: function(jqXHR, exception) {

        console.log(jqXHR.responseText);
      }

    });
      


 });

$("#mytable1").DataTable();
  });
</script>
  <script type="text/javascript">
  $(document).ready(function(){

    $('#getmachine').click(function(){

      var machine = $('#machine').val();
      var bid = $('#beamdate').val();
  

      if(machine === ""){

       $('#staffnot').html('Machine is not selected');
     }
     
    else{

       

     $.ajax({

       type       : 'POST',
       url        : '<?php echo base_url() ?>admin/get-machine-work-reports',
       dataType   : 'json',
       data       : {'machine':machine, 'bid':bid},
       beforeSend : function() {

        $('#workdata').html('');
      },
       success    : function(data) {

        $('#machinereport').html('')
        
        let totalcone = 0;
        let totalroll = 0;
        let machinename = 0;
        let beamweight = 0;
        let beamlength = 0;
        let totalrolllen = 0;
        let totalRollWeight = 0;
        
         $.map(data, function(ele,i){

           machinename = ele.machine_model;
           beamweight = parseFloat(ele.beam_weight);
           totalcone += parseFloat(ele.work_used_cone_weight);
           beamlength = parseFloat(ele.beam_length);
            totalroll += parseInt(ele.work_no_of_roll_weight);
            totalrolllen += parseFloat(ele.work_no_of_roll_weight)*100;
            totalRollWeight += parseFloat(ele.work_roll_weight);

         })

         $('#machinereport').append(`<tr>
          <td>${machinename}</td>
          <td>${beamweight}</td>
          <td>${totalcone}</td>
          <td>${beamlength}</td>
          <td>${totalroll}</td>
          <td>${totalrolllen}</td>
          <td>${totalRollWeight}</td>
          </tr>`);

      
        

      },error: function(jqXHR, exception) {

        console.log(jqXHR.responseText);
      }

    });

   }

 });


  });
</script>


  
</body>
</html>
