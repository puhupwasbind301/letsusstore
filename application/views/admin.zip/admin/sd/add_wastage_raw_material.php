<!DOCTYPE html>
<html>
<?php $title = "Wastage Raw Materials";
  $nav_page = 10012;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php include 'admin_assets/include/navbar.php'; ?>
  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Add Wastage Raw Materials</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>Admin">Home</a></li>
              <li class="breadcrumb-item active">Add Wastage Raw Materials</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item">Inward</li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">

                  <form class="px-5" action="" method="POST">
                    <div class="row px-5">
                      <div class="col-12">
                        <div class="row">
                          <div class="col-md-12">
                            <div class="row" >
                              <div class="col-md-6">
                                <div class="form-group">
                                  <label for="">Wastage Raw Material Type</label>
                                  <select name="raw_material_type" id="raw_material_type" class="form-control" required="">
                                    <option selected="" style="display: none;">Select Raw Material Type</option>
                                    <option value="Yarn">Yarn</option>
                                    <option value="Roing">Roving</option>
                                    <option value="Chemicals">Chemicals</option>
                                    <option value="Chemicals">Gas Cylinder</option>
                                  </select>
                                  <!-- <em><?php echo form_error('raw_material_type'); ?></em> -->
                                </div>
                              </div>
                              <div class="col-md-6 " id="custom_type" style="display: none">
                                <div class="form-group">
                                  <label for="">Yarn Type</label>
                                  <select name="raw_custom_type" id="raw_custom_type" class="form-control" required="">
                                    <option selected="" style="display: none;">Select Yarn Type</option>
                                    
                                  </select>
                                  <!-- <em><?php echo form_error('raw_material_type'); ?></em> -->
                                </div>
                              </div>
                              <div class="col-md-6">
                                <div class="form-group">
                                  <label for="">Select Date</label>
                                  <input type="text" class="form-control date" name="date">
                                </div>
                              </div>
                              
                              <div class="row" id="append-here">
                                
                              </div>
                            </div>
                          </div>
                          
                          <div class="col-md-12 text-center my-5">
                            <button class="btn btn-outline-success" type="submit">Submit</button>
                          </div>
                          <div class="col-md-12">
                             <?php echo $this->session->flashdata('val_error'); ?>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
</body>
</html>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>


<script>
  $(function(){

    $('.date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxDate: new Date(),
      maxYear: parseInt(moment().format('YYYY'),10)
    });



    $('#raw_material_type').unbind().change(function(event) {
      event.preventDefault()
      let value = $(this).val()
      if (value === 'Yarn') {
              $.ajax({
        url: '<?php echo base_url();?>admin/get-inward-type-of-type',
        type: 'POST',
        dataType: 'json',
        data: {raw_material_type: value},
        beforeSend: function() {
        $('#raw_custom_type').html('');
        },
      })
      .done(function(data) {
        console.log(data);
        $.each(data, function(key, value) {
            console.log(value.inward_type);
            $('#raw_custom_type').append(`<option value="${value.inward_type_of_type}">${value.inward_type_of_type}</option>`);
        });

           $('#custom_type').show();

      })
      .fail(function() {
        console.log("error");
      })
      .always(function() {
        console.log("complete");
      });
        $('#append-here').html(`
     
                            <div class="col-md-6">
                            <div class="form-group">
                              <label for="">No of cartons</label>
                              <input type="number" min="1" name="no_of_cartons" class="form-control" required="">
                            </div>
                          </div>
               
                          
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="">Total Weight (KG)</label>
                              <input type="number" min="1" name="weight" class="form-control" required="">
                            </div>
                          </div>`)
      }else if(value === 'Roing') {
        $('#custom_type').hide();
        $('#append-here').html(`<div class="col-md-6">
                            <div class="form-group">
                              <label for="">Roing type</label>
                              <input type="text" name="raw_custom_type" class="form-control" id="raw_custom_type" required="">
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="">Total Weight (KG)</label>
                              <input type="number" min="1" name="weight" class="form-control" required="">
                            </div>
                          </div>`)

      }else if(value === 'Chemicals') {
        $('#custom_type').hide();
        $('#append-here').html(`<div class="col-md-6">
                            <div class="form-group">
                              <label for="">Chemicals type</label>
                              <input type="text" name="raw_custom_type" class="form-control" id="raw_custom_type" required="">
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="">Total Weight (KG)</label>
                              <input type="number" name="weight" min="1" class="form-control" required="">
                            </div>
                          </div>`)
         }
    });
  })
</script>

