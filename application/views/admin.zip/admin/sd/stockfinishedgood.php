<!DOCTYPE html>
<html>
<?php $title = "Finished Goods Stock";
  $nav_page = 13;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
 <?php include 'admin_assets/include/navbar.php'; ?>

  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Finished Goods Stock</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Inventory</a></li>
              <li class="breadcrumb-item active">Finished Goods Stock</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <div class="card">
              <div class="card-header">

              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>Finished Goods</th>
                        <th>Finished Goods Qty</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php foreach($data as $key => $val): ?>
                    <tr>
                      <td><?= ++$key?></td>
                      <td><?= $val->goods_name?></td>
                      <td><?= $val->qty?></td>
                    </tr>
                    <?php endforeach; ?>       
                  </tbody>

                </table>
              </div>
            </div>
          </div>
        </div>
      
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content -->

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
</body>
</html>
