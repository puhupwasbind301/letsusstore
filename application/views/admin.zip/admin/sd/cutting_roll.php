<!DOCTYPE html>
<html>
<?php $title = "Cutting Roll";
  $nav_page = 50;
  include 'admin_assets/include/header.php';
 ?>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
 <?php include 'admin_assets/include/navbar.php'; ?>

  <?php include 'admin_assets/include/sidebar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Cutting Roll (<?= $roll->cutting_roll_name ?>)</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Cutting Roll</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    
    <div class="card">
      <div class="card-header">
        <div class="float-left">
          <b>Weight Left: <?= $roll->cutting_weight_deduct ?> kg</b>
          <br>
          <b>Length Left: <?= $roll->cutting_length_deduct ?> m</b>
        </div>
        <?php if($roll->cutting_length_deduct >= 1){ ?>
        <button type="button" class="btn btn-info float-right" data-toggle="modal" data-target="#modal-lg">Insert Sheet Cut</button>
      <?php } ?>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>#</th>
                <th>Sheet Weight (in Kgs)</th>
                <th>Sheet Length (in meters)</th>
                <th>Wastage (in Kgs)</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($sheet as $k => $sh): ?>
              <tr>
                <td><?= ++$k ?></td>
                <td><?= $sh->fcr_weight ?></td>
                <td><?= $sh->fcr_length ?></td>
                <td><?= $sh->fcr_wastage ?></td>
                <td><?= date('d-m-Y',strtotime($sh->fcr_timestamp)) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Add Roll for Cutting  -->
<div class="modal fade" id="modal-lg">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add Sheet Cut</h4>
        <div id="msg"></div>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- form start -->
        <form action="" id="add_cutting_roll" method="post">
          <div class="card-body">
            <div class="form-group">
              <label class="form-label">Sheet Weight (in Kgs)</label>
              <input type="number" name="sheetweight" class="form-control" required="" max="<?= $roll->cutting_weight_deduct ?>" step="any">
            </div>
            <div class="form-group">
              <label class="form-label">Sheet Length (in meters)</label>
              <input type="number" name="sheetlength" class="form-control" required="" max="<?= $roll->cutting_length_deduct ?>" step="any">
            </div>
            <div class="form-group">
              <label class="form-label">Sheet Wastage (in Kgs)</label>
              <input type="number" name="sheetwastage" class="form-control" value="0.00" step="any">
              <input type="hidden" name="cutrollid" value="<?= $roll->cutting_id?>">
              <input type="hidden" name="coatrollid" value="<?= $roll->cutting_coating_roll_id?>">
              <input type="hidden" name="rollname" value="<?= $roll->cutting_roll_name ?>">
            </div>
            
          </div>
      <!-- /.card-body -->
      <div class="card-footer">
        <button type="submit" class="btn btn-primary float-right">Submit</button>
      </div>
    </form>
  </div>

</div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>

    
  </div>
  <!-- /.content-wrapper -->

  <?php include 'admin_assets/include/footer.php'; ?>
  <script type="text/javascript">
    $('#add_cutting_roll').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0))

      ajax(url+"admin/add-sheet-from-roll-cut", data).then(function(result) {


        if(result.result){
          window.location.reload()
        }
        else{
          $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
        // $('#mobileror').html(result);
      }
      // window.location.reload()
      

    }).catch(function(e) {


      console.log(e)

    })

  })  
  </script>
</body>
</html>
