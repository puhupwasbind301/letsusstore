<!DOCTYPE html>
<html>
<?php $title = "Machine List";
$nav_page = 4;
include 'admin_assets/include/header.php';
?>
<style type="text/css">
 @media (min-width: 992px) {
  .modaledit-lg, .modalview-lg{
    max-width: 800px;
  }

}
</style>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Machines</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Machines</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <div class="card">
              <div class="card-header">

                <button type="button" class="btn btn-info float-right" data-toggle="modal" data-target="#modal-lg">Add Machine</button>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>Model</th>
                        <th>Title</th>
                        <!-- <th>Add Beam</th> -->
                        <th>Manage</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach($data as $key => $val): ?>
                        <tr>
                          <td><?= ++$key?></td>
                          <td><?= $val->machine_model?></td>
                          <td><?= $val->machine_title?></td>
                          <td class="text-center"><a href="#" data-toggle="modal" data-target="#modalview-lg<?= $val->machine_id?>"><i class="fa fa-eye text-info" title="View"></i></a>&emsp;|&emsp;<a href="#"  data-toggle="modal" data-target="#modaledit-lg<?= $val->machine_id?>"><i class="fa fa-edit text-success" title="Edit"></i></a>&emsp;|&emsp;<a href="#" data-toggle="modal" data-target="#modaldelete<?= $val->machine_id?>"><i class="fa fa-trash text-danger" title="Delete"></i></a> </td>
                        </tr>

                        <!-- View Machine Info -->
                        <div class="modal fade" id="modalview-lg<?= $val->machine_id?>">
                          <div class="modal-dialog modalview-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h4 class="modal-title">Machine Detail</h4>
                                <div id="msg"></div>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <!-- form start -->
                                <div class="row p-2">
                                  <div class="col-md-3">
                                    <b>Model</b>
                                  </div>
                                  <div class="col-md-9"><?= $val->machine_model  ?></div>
                                </div>
                                <div class="row p-2">
                                  <div class="col-md-3">
                                    <b>Title</b>
                                  </div>
                                  <div class="col-md-9"><?= $val->machine_title  ?></div>
                                </div>
                                <div class="row p-2">
                                  <div class="col-md-3">
                                    <b>Date of Purchase</b>
                                  </div>
                                  <div class="col-md-9"><?= date('d M Y',strtotime($val->machine_dop))  ?></div>
                                </div>
                                <div class="row p-2">
                                  <div class="col-md-3">
                                    <b>Type</b>
                                  </div>
                                  <div class="col-md-9"><?php if($val->machine_type == "1"){ echo "Automatic";}
                                  else if($val->machine_type == "2"){

                                    echo "Manual";
                                  }  ?></div>
                                </div>
                                <?php if($val->machine_type == "1"){ ?>
                                  <div class="row p-2">
                                    <div class="col-md-3">
                                      <b>Consumption</b>
                                    </div>
                                    <div class="col-md-9"><?php if($val->machine_consumption_type == '1'){
                                      echo "Kilowatt (kW)";
                                    }
                                    else if($val->machine_consumption_type == '2'){

                                      echo "Litre (l)";
                                    }   ?></div>
                                  </div>
                                  <div class="row p-2">
                                    <div class="col-md-3">
                                      <b>Unit<small> (per hour)</small></b>
                                    </div>
                                    <div class="col-md-9"><?= $val->machine_unit  ?></div>
                                  </div>
                                <?php } ?>
                                <div class="row p-2">
                                  <div class="col-md-3">
                                    <b>Purchase Amount</b>
                                  </div>
                                  <div class="col-md-9"><?= $val->machine_amount  ?></div>
                                </div>
                                <div class="row p-2">
                                  <div class="col-md-3">
                                    <b>Description</b>
                                  </div>
                                  <div class="col-md-9"><?= $val->machine_dec  ?></div>
                                </div>
                              </div>

                            </div>
                            <!-- /.modal-content -->
                          </div>
                          <!-- /.modal-dialog -->
                        </div>

                        <!-- Edit Machine Detail -->
                        <div class="modal fade" id="modaledit-lg<?= $val->machine_id?>">
                          <div class="modal-dialog modaledit-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h4 class="modal-title">Edit Machine</h4>
                                <div id="messageForm1"></div>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <!-- form start -->
                                <form action="" class="ajaxform2" method="post">
                                  <div class="card-body">
                                    <input type="hidden" name="id" value="<?= $val->machine_id ?>">
                                    <div class="row">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label for="model">Model</label>
                                          <input type="text" class="form-control" id="model" name="model" placeholder="Model" required="" value="<?= $val->machine_model?>" required="">

                                        </div>
                                      </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label for="title">Title</label>
                                          <input type="text" class="form-control" id="title" name="title" placeholder="Title" value="<?= $val->machine_title?>" required="">

                                        </div>
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label for="dop">Date of Purchase</label>
                                          <div class="input-group-prepend">
                                            <span class="input-group-text">
                                              <i class="far fa-calendar-alt"></i>
                                            </span><input type="text" name="dop" id="dop" class="form-control" value="<?= date('m d y',strtotime($val->machine_dop))?>" required="">

                                          </div>

                                        </div>
                                      </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label for="amount">Purchase Amount</label>
                                          <input type="number" class="form-control" id="amount" name="amount" placeholder="Purchase Amount" value="<?= $val->machine_amount?>" required="">

                                        </div>
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-6">
                                       <div class="form-group">
                                        <label for="doj">Select Type</label>
                                        <select class="form-control" name="type" required="" id="editstype">
                                          <option value="1" <?php if($val->machine_type == 1){ echo "selected";}?>>Automatic</option>
                                          <option value="2" <?php if($val->machine_type == 2){ echo "selected";}?>>Manual</option>
                                        </select>

                                      </div>
                                    </div>

                                  </div>

                                  <div class="row editelectype <?php if($val->machine_type == 1){ echo "";} else { echo "d-none";} ?>">
                                    <div class="col-md-6">
                                     <div class="form-group">
                                      <label for="">Consumption</label>
                                      <select class="form-control" name="consumption">
                                        <option value="1" <?php if($val->machine_consumption_type == 1){ echo "selected";} ?>>Kilowatt (kW)</option>
                                        <option value="2" <?php if($val->machine_consumption_type == 2){ echo "selected";} ?>>Litre (l)</option>
                                      </select>

                                    </div>
                                  </div>

                                  <div class="col-md-6">
                                   <div class="form-group">
                                    <label for="unit">Unit <small>(per hour)</small></label>
                                    <input type="number" id="unit" name="unit" class="form-control" value="<?= $val->machine_unit?>" step="any">

                                  </div>
                                </div>

                              </div>

                              <div class="form-group">
                                <label for="desc">Description</label>
                                <textarea class="form-control" name="desc"  rows="3" required=""><?= $val->machine_dec?></textarea>
                              </div>

                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                              <button type="submit" class="btn btn-primary float-right">Submit</button>
                            </div>
                          </form>
                        </div>

                      </div>
                      <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                  </div>

                  <!-- Delete Staff -->
                  <div class="modal fade" id="modaldelete<?= $val->machine_id?>">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">Delete Machines</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <form action="<?= base_url()?>Admin/delete_wraping_machine" method="post">
                          <div class="modal-body">
                            <input type="hidden" name="mid" value="<?= $val->machine_id?>">
                            <p>Are you sure, you want to delete this?</p>
                          </div>
                          <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Yes</button>
                          </div>
                        </form>
                      </div>
                      <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                  </div>
                  <!-- /.modal -->


                <?php endforeach; ?>
              </tbody>

            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- Add Staff -->
    <div class="modal fade" id="modal-lg">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Add Machine</h4>

            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <!-- form start -->
            <form  id="ajaxform1" method="post">
              <div class="card-body">
                <div id="messageForm"></div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="model">Model</label>
                      <input type="text" class="form-control" id="model" name="model" placeholder="Model" required="" >

                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="title">Title</label>
                      <input type="text" class="form-control" id="title" name="title" placeholder="Title" >

                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="dop">Date of Purchase</label>
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="far fa-calendar-alt"></i>
                        </span><input type="text" name="dop" id="dop" class="form-control" >

                      </div>

                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="amount">Purchase Amount</label>
                      <input type="number" class="form-control" id="amount" name="amount" placeholder="Purchase Amount" >

                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                   <div class="form-group">
                    <label for="doj">Select Type</label>
                    <select class="form-control" name="type" id="stype">
                      <option value="">---Select Type---</option>
                      <option value="1">Automatic</option>
                      <option value="2">Manual</option>
                    </select>

                  </div>
                </div>

              </div>

              <div class="row electype d-none" id="Electric">
                <div class="col-md-6">
                 <div class="form-group">
                  <label for="">Consumption</label>
                  <select class="form-control" name="consumption">
                    <option value="">---Select Consumption Type---</option>
                    <option value="1">Kilowatt (kW)</option>
                    <option value="2">Litre (l)</option>
                  </select>

                </div>
              </div>

              <div class="col-md-6">
               <div class="form-group">
                <label for="unit">Unit <small>(per hour)</small></label>
                <input type="number" id="unit" name="unit" class="form-control" step="any">

              </div>
            </div>

          </div>

          <div class="form-group">
            <label for="desc">Description</label>
            <textarea class="form-control" name="desc"  rows="3"></textarea>
          </div>

        </div>


        <!-- /.card-body -->

        <div class="card-footer">
          <button type="submit" class="btn btn-primary float-right">Submit</button>
        </div>
      </form>
    </div>

  </div>
  <!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
</div>
<!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->

</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php'; ?>
<script>
  $(function() {
    $('input[name="dop"]').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxYear: parseInt(moment().format('YYYY'),10)
    });
  });
</script>
<script type="text/javascript">
  $(function() {
    $('#ajaxform1').on('submit' , function (e) {
      e.preventDefault();
      const data = $(this).serializeArray()
      $.ajax({
        url: '<?php echo base_url();?>admin/insert-machine',
        type: 'POST',
        dataType: 'json',
        data: data,
      })
      .done(function(result) {
        console.log(result);
        if(result.result){
                  window.location.reload()
                }
                else{
                  $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
                // $('#mobileror').html(result);
              }
      })
      .fail(function(jqXHR,exception) {
        console.log(jqXHR.responseText);
      })




    //   let url = $('meta[name=url]').attr("content");
    //   let data = new FormData($(this).get(0))

    //   ajax(url+"admin/insert-machine", data).then(function(result) {


    //     if(result.result){
    //       window.location.reload()
    //     }
    //     else{
    //       $('#messageForm').html('<div class="alert alert-danger">'+result.msg+'</div>');
    //     // $('#mobileror').html(result);
    //   }
    //   // window.location.reload()
      

    // }).catch(function(e) {


    //   console.log(e)

    // })

  })
  })

</script>

<script type="text/javascript">
  $(function() {
    $('.ajaxform2').on('submit' , function (e) {
      e.preventDefault();

      let url = $('meta[name=url]').attr("content");
      let data = new FormData($(this).get(0));

      console.log(data);

      ajax(url+"admin/update-machine", data).then(function(result) {
        if(result.result){

         window.location.reload()
       }
       else{
        window.location.reload()

      }
      
      

    }).catch(function(e) {


      console.log(e)

    })

  })
  })

</script>
<script type="text/javascript">
 $(function() {
  $('#stype').change(function(){
    if($(this).val()==='1'){
      $('.electype').removeClass('d-none')
    }else{
      $('.electype').addClass('d-none')
    }

  });

  $('#editstype').change(function(){
    if($(this).val()==='1'){
      $('.editelectype').removeClass('d-none')
    }else{
      $('.editelectype').addClass('d-none')
    }

  });
});
</script>
</body>
</html>
