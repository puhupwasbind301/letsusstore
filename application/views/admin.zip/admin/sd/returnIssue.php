<!DOCTYPE html>
<html>
<?php $title = "Inventory Return";
$nav_page = 11;
include 'admin_assets/include/header.php';
?>
<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
   <?php include 'admin_assets/include/navbar.php'; ?>

   <?php include 'admin_assets/include/sidebar.php'; ?>

   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Inventory Return</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?= base_url()?>">Home</a></li>
              <li class="breadcrumb-item">Inventory</li>
              <li class="breadcrumb-item active">Inventory Return</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <form id="ajaxform1" method="post" autocomplete="off">
              <div class="card">
                <div class="card-header">

                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="stfid">Return by</label>
                        <select class="form-control" name="stfid" id="stfid">
                          <option value="">---Select Staff Member---</option>
                          <?php foreach($staff as $key => $v): ?>
                            <option value="<?= $v->staff_id?>"><?= $v->staff_name?></option>
                          <?php endforeach; ?>
                        </select>
                      </div>
                    </div>
                   <!-- <div class="col-md-4">
                      <div class="form-group">
                        <label for="invcat">Inventory Category</label>
                        <select class="form-control" name="invcat" id="invcat">
                          <option value="">---Select Inventory Category---</option>
                          <?php foreach($cat as $key1 => $vl): ?>
                            <option value="<?= $vl->inventory_cat_id?>"><?= $vl->inventory_category?></option>
                          <?php endforeach; ?>
                        </select>
                      </div>
                    </div> -->
                     <!-- <div class="col-md-4">
                      <div class="form-group">
                        <label for="item">Item</label>
                        <select id="item" class="form-control" name="item">

                        </select>
                      </div>
                    </div> -->

                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <button class="btn btn-primary float-right" type="button" id="showItem">Show</button>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                 <div class="row p-2">
                  <div class="col-md-12 table-responsive">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>Item</th>
                          <th>Item Type</th>
                          <th>Taken Quantity</th>
                          <th>Issued Date</th>
                          <th>Returned Quantity</th>
                          <th>Used Quantity</th>
                          <th>Wastage Quantity</th>
                          <th>Return Date</th>
                          <th>Check</th>
                        </tr>
                      </thead>
                      <tbody id="itemde">

                      </tbody>
                    </table>
                  </div>
                </div>

                <div class="row p-2 d-none" id="spot1">
                  <div class="col-md-4">
                    <label for="remarks">Select Goods Category</label>
                    <select name="goods" class="form-control" id="goodscat">
                      <option value="">---Select Goods Category---</option>
                      <?php foreach($goods as $key => $val): ?>
                        <option value="<?= $val->goods_id?>"><?= $val->goods_name?></option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                  <div class="col-md-4">
                    <label for="goodsqty">Finished Goods Quantity</label>
                    <input type="number" name="goodsqty" id="goodsqty" class="form-control">
                  </div>
                  <div class="col-md-4">
                    <label for="remarks">Remarks</label>
                    <input type="text" name="retremarks" id="remarks" class="form-control">
                  </div>

                </div>
                <div class="row p-2">
                  <div class="col-md-12">
                    <button class="btn btn-primary float-right" type="button" id="makepayment">Save</button>
                  </div>
                </div>
              </div>
              

            </div>
          </form>
        </div>

      </div>
      <!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content -->


</div>
<!-- /.content-wrapper -->

<?php include 'admin_assets/include/footer.php'; ?>

<script type="text/javascript">
  $( function() {
    $( "#stfid" ).change(function(){


      var id = $(this).val();

      $.ajax({

       type       : 'POST',
       url        : '<?php echo base_url() ?>Machineajax/getInventoryCatbyStaffId',
       dataType   : 'json',
       data       : {'id': id},
       success    : function(result) {

          // console.log(result);
          // return false;
          
          var select = '';
          select += '<option value="">---Select Inventory Category---</option>';
          $.each(result, function(result, val) {

           select += '<option value="'+val['stck_inventory_cat_id']+'">'+val['inventory_category']+'</option>';
         });

          $('#invcat').html(select);

          


        },error: function(jqXHR, exception) {
          console.log('bye');
          console.log(jqXHR.responseText);
        }

      });

    })


  });

</script>

<script type="text/javascript">
  $( function() {
    $( "#invcat" ).change(function(){


      var id = $(this).val();

      $.ajax({

       type       : 'POST',
       url        : '<?php echo base_url() ?>Machineajax/getItemByInventoryCatById',
       dataType   : 'json',
       data       : {'id': id},
       success    : function(result) {

          // console.log(result);
          // return false;
          
          var select = '';
          select += '<option value="">---Select Item---</option>';
          $.each(result, function(result, val) {

           select += '<option value="'+val['stck_item_id']+'">'+val['item_inventory']+'</option>';
         });

          $('#item').html(select);

          


        },error: function(jqXHR, exception) {
          console.log('bye');
          console.log(jqXHR.responseText);
        }

      });

    })


  });

</script>
<script type="text/javascript">
  function checkAvailble(str , str1 , evnt){

    if(parseInt(str) > parseInt(str1)){

      alert("You can't return more than Taken Quantity");
      $(evnt).val("0");
    }
  }
</script>
<script type="text/javascript">
  function checkUsed(str , str1 , evnt){

    if(parseInt(str) > parseInt(str1)){

      alert("You can't Use more than Taken Quantity");
      $(evnt).val("0");
    }
  }
</script>
<script type="text/javascript">
  function checkWaste(str , str1 , evnt){

    if(parseInt(str) > parseInt(str1)){

      alert("You can't Use more than Taken Quantity");
      $(evnt).val("0");
    }
  }
</script>
<script type="text/javascript">
 $(document).ready(function(){
  $('#showItem').click(function(){

    var staff = $('#stfid').val();
    var inventorycat = $('#invcat').val();
    var item = $('#item').val();

    if(staff === ""){

      alert("Staff is not selected!");
      return false;
    }
    else if(inventorycat === ""){

      alert("Inventory Category not Selected!");
      return false;
    }
    else if(item === ""){

      alert("Item is not selected!");
      return false;
    }
    else{

      $.ajax({

       type       : 'POST',
       url        : '<?php echo base_url() ?>Machineajax/getIssuedItem',
       dataType   : 'json',
       data       : {'staff': staff},
       beforeSend : function() {

        $('#itemde').html('');
      },
      success    : function(datas) {
        if(datas.length == 0){
          $('#itemde').append(`<tr>
            <td colspan="9" class="text-center">
              No Data Found
            </td>
             </tr>`);

        }
        else{

        $.map(datas, function(data,index) {

          var date = new Date(data.stck_created_at);
          var month = date.getMonth() + 1;
          var dated = ((date.getDate()+'').length > 1 ? date.getDate(): "0" + date.getDate()) + "-"+ ((month+'').length > 1 ? month : "0" + month)+ "-" + date.getFullYear();

          $('#itemde').append(`<tr>
            <td>
            <input type="hidden" value="${data.stckissue_id}" name="stckiss[]">
            ${data.item_inventory}
            </td>
            <td><input type="hidden" value="${data.item_type}">
            ${data.item_type == 1 ? 'Consumable': 'Non-consumable'}
            </td>
            <td class="d-none">
            <input type="hidden" value="${data.stck_item_id}" name="itemid[]">
            </td>
            <td>
            <input type="hidden" value="${data.stck_quantity}" name="tqty[]">
            ${data.stck_quantity}
            </td>
            <td><input type="hidden" value="${dated}"> ${dated}
            </td>
            <td>
            <input type="number" name="rqty[]" onkeyup="checkAvailble(value ,  ${data.stck_quantity}, this)" value="0" class="form-control">
             </td>
             <td>
             <input type="number" class="form-control" name="used[]" onkeyup="checkUsed(value ,  ${data.stck_quantity}, this)" value="0">
             </td>
             <td>
             <input type="number" class="form-control" name="wastage[]"  onkeyup="checkWaste(value ,  ${data.stck_quantity}, this)" value="0">
             </td>
             <td>
             <input type="text" class="form-control pdatef" name="pdate[]">
             </td>
             <td class="text-center">
             <input type="checkbox" name="returncheck[]" value="1">
             </td>
             </tr>`);

//             $('#itemde').append('<tr><td><input type="hidden" value="'+data.stckissue_id+'" name="stckiss[]">' + data.item_inventory + '</td><td id="itype"><input type="hidden" value="'+data.item_type+'" name="itemtype[]">' + if (data.item_type == 1) {
//   document.getElementById("demo").innerHTML = "Good day!";
// }data.item_inventory + '</td><td class="d-none"><input type="hidden" value="'+data.stck_item_id+'" name="itemid[]"></td><td><input type="hidden" value="'+data.stck_quantity+'" name="tqty[]">' + data.stck_quantity + '</td><td>'+dated+'</td><td><input type="number" name="rqty[]" onkeyup="checkAvailble(value ,  '+ data.stck_quantity + ' , this)" value="0" class="form-control"> </td><td><input type="text" class="form-control pdatef" name="pdate[]"></td><td class="text-center"><input type="checkbox" name="returncheck[]" value="1"></td></tr>');

          $('.pdatef').daterangepicker({
            singleDatePicker: true,
            showDropdowns: true,
            minYear: 1901,
            maxDate: new Date(),
            maxYear: parseInt(moment().format('YYYY'),10)
          });


        })

         $("#spot1").removeClass("d-none");


        clickMe()
}
      },error: function(jqXHR, exception) {
        console.log('bye');
        console.log(jqXHR.responseText);
      }

    });

    }

  });

  
});
</script>
<script type="text/javascript">
  $(function() {

  });
</script>

<script type="text/javascript">
  function clickMe() {
    $('#makepayment').click(function () {

      var check = 0 ;

      var qtycheck = 0;

      var inventoryissue = [];

      $('#itemde tr').each(function (row, tr) {
        if ($(this).find(":checkbox").prop("checked")) {
          var issuedid = $(tr).find('td:eq(0) input').val();
          let item = $(tr).find('td:eq(1) input').val();
          var itemid = $(tr).find('td:eq(2) input').val();
          var totalqty = parseInt($(tr).find('td:eq(3) input').val());
          let issdate = $(tr).find('td:eq(4) input').val();
          var retqty = parseInt($(tr).find('td:eq(5) input').val());
          let usedqty = parseInt($(tr).find('td:eq(6) input').val());
          let waste = parseInt($(tr).find('td:eq(7) input').val());
          var retdate = $(tr).find('td:eq(8) input').val();
          let remarks = $('#remarks').val();
          let fgoods = $('#goodsqty').val();
          let goodscat = $('#goodscat').val();

          if(retqty < 0){

            alert('zero or less');
            check = "1";
            qtycheck = 0;
            return false;
          }

          else if(retqty > totalqty){

            alert('return quantity');
            check = "1";
            qtycheck = 0;
            return false;
          }
          else {

            var datas = {
              'issuedid' : issuedid,
              'tqty': totalqty,
              'rqty': retqty,
              'itemid': itemid,
              'retdate' : retdate,
              'idate' : issdate,
              'wastage' : waste,
              'used' : usedqty,
              'itype' : item,
              'remarks': remarks,
              'goodcat': goodscat,
              'fgoodqty': fgoods,  

            };
            qtycheck = 1;
            inventoryissue.push(datas);
          }
          check = "1";
        }
      });


      if(check) {

        if (qtycheck) {

         $.ajax({
                        type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
                        url: '<?= base_url();?>Admin/returnInventoryInsert', // the url where we want to POST
                        data: {'ItemInfo': inventoryissue}, // our data object
                        dataType  : 'json', // what type of data do we expect back from the server
                        success: function(data) {
                          if(data.result) {
                            window.location.reload()
                          } else {
                            console.log(data);
                           

                          }
                          
                        },
                        error: function (jqXHR) {
                            console.log(jqXHR.responseText); // Optional
                          }
                        });

       }
     }
     else{

      alert('Please checked & try again !!');
      return false;
    }

  });
  }

</script>
</body>
</html>
